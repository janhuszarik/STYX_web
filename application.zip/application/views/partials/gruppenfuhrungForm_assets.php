<link rel="stylesheet" href="<?= base_url('assets/css/gruppenfuhrung_form.css') ?>">
<script src="<?= base_url('assets/js/gruppenfuhrung_form.js') ?>" defer></script>

