<link rel="stylesheet" href="<?= base_url('assets/css/betriebsfuhrungen_view.css') ?>">
