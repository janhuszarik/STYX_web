<link rel="stylesheet" href="<?= base_url('assets/css/article_view.css') ?>">
<script src="<?= base_url('assets/js/article_view.js') ?>" defer></script>

