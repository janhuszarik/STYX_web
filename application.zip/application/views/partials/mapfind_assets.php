<link rel="stylesheet" href="<?= base_url('assets/css/mapfind_view.css') ?>">

