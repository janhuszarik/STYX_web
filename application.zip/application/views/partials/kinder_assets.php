<link rel="stylesheet" href="<?= base_url('assets/css/kinder_view.css') ?>">

