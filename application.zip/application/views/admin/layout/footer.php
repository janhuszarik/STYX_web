<script src="<?=BASE_URL?>adm/assets/vendor/jquery/jquery.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/popper/umd/popper.min.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/common/common.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/nanoscroller/nanoscroller.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/magnific-popup/jquery.magnific-popup.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>

<script src="<?=BASE_URL?>adm/assets/vendor/jquery-ui/jquery-ui.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/jqueryui-touch-punch/jquery.ui.touch-punch.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/select2/js/select2.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/bootstrap-multiselect/js/bootstrap-multiselect.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/jquery-maskedinput/jquery.maskedinput.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/fuelux/js/spinner.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/dropzone/dropzone.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/bootstrap-markdown/js/markdown.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/bootstrap-markdown/js/to-markdown.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/bootstrap-markdown/js/bootstrap-markdown.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/summernote/summernote-bs4.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/bootstrap-maxlength/bootstrap-maxlength.js"></script>
<script src="<?=BASE_URL?>adm/assets/vendor/ios7-switch/ios7-switch.js"></script>

<script src="<?=BASE_URL?>adm/assets/js/theme.js"></script>
<script src="<?=BASE_URL?>adm/assets/js/custom.js"></script>
<script src="<?=BASE_URL?>adm/assets/js/theme.init.js"></script>
<script src="<?=BASE_URL?>adm/assets/js/examples/examples.advanced.form.js"></script>

