<?php

require_once('head.php');
require_once('menu.php');
$this->load->view($page);
require_once('footer.php');