<?php
    /**
     * Project REMISE.at.
     * User: Jan Huszarik
     * Copyright: REMISE | STYX.at
     * Date: 01.07.2024
     * Time: 07:00
     * mail: jan.huszarik@styx.at
     */
