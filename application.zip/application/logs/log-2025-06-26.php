<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 26.06.2025 11:13:44 --> Config Class Initialized
INFO - 26.06.2025 11:13:44 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:13:44 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:13:44 --> Utf8 Class Initialized
INFO - 26.06.2025 11:13:44 --> URI Class Initialized
INFO - 26.06.2025 11:13:44 --> Router Class Initialized
INFO - 26.06.2025 11:13:44 --> Output Class Initialized
INFO - 26.06.2025 11:13:44 --> Security Class Initialized
DEBUG - 26.06.2025 11:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:13:44 --> Input Class Initialized
INFO - 26.06.2025 11:13:44 --> Language Class Initialized
INFO - 26.06.2025 11:13:44 --> Loader Class Initialized
INFO - 26.06.2025 11:13:44 --> Helper loaded: app_helper
INFO - 26.06.2025 11:13:44 --> Helper loaded: language_helper
INFO - 26.06.2025 11:13:44 --> Helper loaded: text_helper
INFO - 26.06.2025 11:13:44 --> Helper loaded: string_helper
INFO - 26.06.2025 11:13:44 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:13:44 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:13:44 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:13:44 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:13:44 --> Email Class Initialized
INFO - 26.06.2025 11:13:44 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:13:44 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:13:44 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:13:44 --> Helper loaded: date_helper
INFO - 26.06.2025 11:13:44 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:13:44 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:13:44 --> Helper loaded: form_helper
INFO - 26.06.2025 11:13:44 --> Form Validation Class Initialized
INFO - 26.06.2025 11:13:44 --> Upload Class Initialized
INFO - 26.06.2025 11:13:44 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:13:44 --> Pagination Class Initialized
INFO - 26.06.2025 11:13:44 --> Controller Class Initialized
INFO - 26.06.2025 11:13:44 --> Model "Article_model" initialized
INFO - 26.06.2025 11:13:44 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:13:44 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:13:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:13:44 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => 
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:13:44 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/herr_styx5.jpg
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:13:44 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => 
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => uploads/articles/sections/herr_styx5.jpg
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:13:44 --> Using existing image: 
DEBUG - 26.06.2025 11:13:44 --> Updated is_main for other articles in category 89
DEBUG - 26.06.2025 11:13:44 --> Database save successful for article ID: 46
DEBUG - 26.06.2025 11:13:44 --> Processing section image upload for index 0: herr_styx.jpg
INFO - 26.06.2025 11:13:44 --> Image Lib Class Initialized
DEBUG - 26.06.2025 11:13:44 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:13:44 --> Section image uploaded successfully for index 0: original=uploads/articles/sections/ueber-styx_section_0.jpg, thumb=uploads/articles/sections/ueber-styx_section_0_thumb.jpg
DEBUG - 26.06.2025 11:13:44 --> Inserting section 0: Array
(
    [article_id] => 46
    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
    [image] => uploads/articles/sections/ueber-styx_section_0.jpg
    [thumb_image] => uploads/articles/sections/ueber-styx_section_0_thumb.jpg
    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
    [button_name] => lokfff
    [subpage] => 
    [external_url] => 
    [order] => 0
)

INFO - 26.06.2025 11:13:45 --> Config Class Initialized
INFO - 26.06.2025 11:13:45 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:13:45 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:13:45 --> Utf8 Class Initialized
INFO - 26.06.2025 11:13:45 --> URI Class Initialized
INFO - 26.06.2025 11:13:45 --> Router Class Initialized
INFO - 26.06.2025 11:13:45 --> Output Class Initialized
INFO - 26.06.2025 11:13:45 --> Security Class Initialized
DEBUG - 26.06.2025 11:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:13:45 --> Input Class Initialized
INFO - 26.06.2025 11:13:45 --> Language Class Initialized
INFO - 26.06.2025 11:13:45 --> Loader Class Initialized
INFO - 26.06.2025 11:13:45 --> Helper loaded: app_helper
INFO - 26.06.2025 11:13:45 --> Helper loaded: language_helper
INFO - 26.06.2025 11:13:45 --> Helper loaded: text_helper
INFO - 26.06.2025 11:13:45 --> Helper loaded: string_helper
INFO - 26.06.2025 11:13:45 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:13:45 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:13:45 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:13:45 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:13:45 --> Email Class Initialized
INFO - 26.06.2025 11:13:45 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:13:45 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:13:45 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:13:45 --> Helper loaded: date_helper
INFO - 26.06.2025 11:13:45 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:13:45 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:13:45 --> Helper loaded: form_helper
INFO - 26.06.2025 11:13:45 --> Form Validation Class Initialized
INFO - 26.06.2025 11:13:45 --> Upload Class Initialized
INFO - 26.06.2025 11:13:45 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:13:45 --> Pagination Class Initialized
INFO - 26.06.2025 11:13:45 --> Controller Class Initialized
INFO - 26.06.2025 11:13:45 --> Model "Article_model" initialized
INFO - 26.06.2025 11:13:45 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:13:45 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:13:45 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:13:45 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:13:45 --> Final output sent to browser
DEBUG - 26.06.2025 11:13:45 --> Total execution time: 0.4038
INFO - 26.06.2025 11:13:47 --> Config Class Initialized
INFO - 26.06.2025 11:13:47 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:13:47 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:13:47 --> Utf8 Class Initialized
INFO - 26.06.2025 11:13:47 --> URI Class Initialized
INFO - 26.06.2025 11:13:47 --> Router Class Initialized
INFO - 26.06.2025 11:13:47 --> Output Class Initialized
INFO - 26.06.2025 11:13:47 --> Security Class Initialized
DEBUG - 26.06.2025 11:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:13:47 --> Input Class Initialized
INFO - 26.06.2025 11:13:47 --> Language Class Initialized
INFO - 26.06.2025 11:13:47 --> Loader Class Initialized
INFO - 26.06.2025 11:13:47 --> Helper loaded: app_helper
INFO - 26.06.2025 11:13:47 --> Helper loaded: language_helper
INFO - 26.06.2025 11:13:47 --> Helper loaded: text_helper
INFO - 26.06.2025 11:13:47 --> Helper loaded: string_helper
INFO - 26.06.2025 11:13:47 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:13:47 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:13:47 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:13:47 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:13:47 --> Email Class Initialized
INFO - 26.06.2025 11:13:47 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:13:47 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:13:47 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:13:47 --> Helper loaded: date_helper
INFO - 26.06.2025 11:13:47 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:13:47 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:13:47 --> Helper loaded: form_helper
INFO - 26.06.2025 11:13:47 --> Form Validation Class Initialized
INFO - 26.06.2025 11:13:47 --> Upload Class Initialized
INFO - 26.06.2025 11:13:47 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:13:47 --> Pagination Class Initialized
INFO - 26.06.2025 11:13:47 --> Controller Class Initialized
INFO - 26.06.2025 11:13:47 --> Model "Article_model" initialized
INFO - 26.06.2025 11:13:47 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:13:47 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:13:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:13:47 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 934
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
            [thumb_image] => uploads/articles/sections/ueber-styx_section_0_thumb.jpg
        )

)

INFO - 26.06.2025 11:13:47 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:13:47 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:13:47 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:13:47 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:13:47 --> Final output sent to browser
DEBUG - 26.06.2025 11:13:47 --> Total execution time: 0.4744
INFO - 26.06.2025 11:14:18 --> Config Class Initialized
INFO - 26.06.2025 11:14:18 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:14:18 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:14:18 --> Utf8 Class Initialized
INFO - 26.06.2025 11:14:18 --> URI Class Initialized
INFO - 26.06.2025 11:14:18 --> Router Class Initialized
INFO - 26.06.2025 11:14:18 --> Output Class Initialized
INFO - 26.06.2025 11:14:18 --> Security Class Initialized
DEBUG - 26.06.2025 11:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:14:18 --> Input Class Initialized
INFO - 26.06.2025 11:14:18 --> Language Class Initialized
INFO - 26.06.2025 11:14:18 --> Loader Class Initialized
INFO - 26.06.2025 11:14:18 --> Helper loaded: app_helper
INFO - 26.06.2025 11:14:18 --> Helper loaded: language_helper
INFO - 26.06.2025 11:14:18 --> Helper loaded: text_helper
INFO - 26.06.2025 11:14:18 --> Helper loaded: string_helper
INFO - 26.06.2025 11:14:18 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:14:18 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:14:18 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:14:18 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:14:18 --> Email Class Initialized
INFO - 26.06.2025 11:14:18 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:14:18 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:14:18 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:14:18 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:14:18 --> Helper loaded: date_helper
INFO - 26.06.2025 11:14:18 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:14:18 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:14:18 --> Helper loaded: form_helper
INFO - 26.06.2025 11:14:18 --> Form Validation Class Initialized
INFO - 26.06.2025 11:14:18 --> Upload Class Initialized
INFO - 26.06.2025 11:14:18 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:14:18 --> Pagination Class Initialized
INFO - 26.06.2025 11:14:18 --> Controller Class Initialized
INFO - 26.06.2025 11:14:18 --> Model "Article_model" initialized
INFO - 26.06.2025 11:14:18 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:14:18 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:14:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:14:18 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 934
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
            [thumb_image] => uploads/articles/sections/ueber-styx_section_0_thumb.jpg
        )

)

INFO - 26.06.2025 11:14:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:14:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:14:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:14:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:14:18 --> Final output sent to browser
DEBUG - 26.06.2025 11:14:18 --> Total execution time: 0.4690
INFO - 26.06.2025 11:14:18 --> Config Class Initialized
INFO - 26.06.2025 11:14:18 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:14:18 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:14:18 --> Utf8 Class Initialized
INFO - 26.06.2025 11:14:18 --> URI Class Initialized
INFO - 26.06.2025 11:14:18 --> Router Class Initialized
INFO - 26.06.2025 11:14:18 --> Output Class Initialized
INFO - 26.06.2025 11:14:18 --> Security Class Initialized
DEBUG - 26.06.2025 11:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:14:18 --> Input Class Initialized
INFO - 26.06.2025 11:14:18 --> Language Class Initialized
INFO - 26.06.2025 11:14:18 --> Loader Class Initialized
INFO - 26.06.2025 11:14:18 --> Helper loaded: app_helper
INFO - 26.06.2025 11:14:18 --> Helper loaded: language_helper
INFO - 26.06.2025 11:14:18 --> Helper loaded: text_helper
INFO - 26.06.2025 11:14:18 --> Helper loaded: string_helper
INFO - 26.06.2025 11:14:18 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:14:18 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:14:18 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:14:18 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:14:18 --> Email Class Initialized
INFO - 26.06.2025 11:14:18 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:14:18 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:14:18 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:14:18 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:14:18 --> Helper loaded: date_helper
INFO - 26.06.2025 11:14:18 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:14:18 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:14:18 --> Helper loaded: form_helper
INFO - 26.06.2025 11:14:18 --> Form Validation Class Initialized
INFO - 26.06.2025 11:14:18 --> Upload Class Initialized
INFO - 26.06.2025 11:14:18 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:14:18 --> Pagination Class Initialized
INFO - 26.06.2025 11:14:18 --> Controller Class Initialized
INFO - 26.06.2025 11:14:18 --> Model "App_model" initialized
INFO - 26.06.2025 11:14:18 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:14:19 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/ueber-styx_section_0.jpg
ERROR - 26.06.2025 11:14:19 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:14:19 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:14:19 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:14:19 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:14:19 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:14:19 --> Final output sent to browser
DEBUG - 26.06.2025 11:14:19 --> Total execution time: 0.4918
INFO - 26.06.2025 11:14:24 --> Config Class Initialized
INFO - 26.06.2025 11:14:24 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:14:24 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:14:24 --> Utf8 Class Initialized
INFO - 26.06.2025 11:14:24 --> URI Class Initialized
INFO - 26.06.2025 11:14:24 --> Router Class Initialized
INFO - 26.06.2025 11:14:24 --> Output Class Initialized
INFO - 26.06.2025 11:14:24 --> Security Class Initialized
DEBUG - 26.06.2025 11:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:14:24 --> Input Class Initialized
INFO - 26.06.2025 11:14:24 --> Language Class Initialized
INFO - 26.06.2025 11:14:24 --> Loader Class Initialized
INFO - 26.06.2025 11:14:24 --> Helper loaded: app_helper
INFO - 26.06.2025 11:14:24 --> Helper loaded: language_helper
INFO - 26.06.2025 11:14:24 --> Helper loaded: text_helper
INFO - 26.06.2025 11:14:24 --> Helper loaded: string_helper
INFO - 26.06.2025 11:14:24 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:14:24 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:14:24 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:14:25 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:14:25 --> Email Class Initialized
INFO - 26.06.2025 11:14:25 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:14:25 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:14:25 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:14:25 --> Helper loaded: date_helper
INFO - 26.06.2025 11:14:25 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:14:25 --> Helper loaded: form_helper
INFO - 26.06.2025 11:14:25 --> Form Validation Class Initialized
INFO - 26.06.2025 11:14:25 --> Upload Class Initialized
INFO - 26.06.2025 11:14:25 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:14:25 --> Pagination Class Initialized
INFO - 26.06.2025 11:14:25 --> Controller Class Initialized
INFO - 26.06.2025 11:14:25 --> Model "Article_model" initialized
INFO - 26.06.2025 11:14:25 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:14:25 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:14:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:14:25 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:14:25 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/herr_styx.jpg
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:14:25 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => uploads/articles/sections/herr_styx.jpg
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:14:25 --> Using existing image: 
DEBUG - 26.06.2025 11:14:25 --> Updated is_main for other articles in category 89
DEBUG - 26.06.2025 11:14:25 --> Database save successful for article ID: 46
DEBUG - 26.06.2025 11:14:25 --> Processing section image upload for index 0: herr_styx.jpg
INFO - 26.06.2025 11:14:25 --> Image Lib Class Initialized
DEBUG - 26.06.2025 11:14:25 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:14:25 --> Section image uploaded successfully for index 0: original=uploads/articles/sections/ueber-styx_section_0.jpg, thumb=uploads/articles/sections/ueber-styx_section_0_thumb.jpg
DEBUG - 26.06.2025 11:14:25 --> Inserting section 0: Array
(
    [article_id] => 46
    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
    [image] => uploads/articles/sections/ueber-styx_section_0.jpg
    [thumb_image] => uploads/articles/sections/ueber-styx_section_0_thumb.jpg
    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
    [button_name] => lokfff
    [subpage] => 
    [external_url] => 
    [order] => 0
)

INFO - 26.06.2025 11:14:25 --> Config Class Initialized
INFO - 26.06.2025 11:14:25 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:14:25 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:14:25 --> Utf8 Class Initialized
INFO - 26.06.2025 11:14:25 --> URI Class Initialized
INFO - 26.06.2025 11:14:25 --> Router Class Initialized
INFO - 26.06.2025 11:14:25 --> Output Class Initialized
INFO - 26.06.2025 11:14:25 --> Security Class Initialized
DEBUG - 26.06.2025 11:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:14:25 --> Input Class Initialized
INFO - 26.06.2025 11:14:25 --> Language Class Initialized
INFO - 26.06.2025 11:14:25 --> Loader Class Initialized
INFO - 26.06.2025 11:14:25 --> Helper loaded: app_helper
INFO - 26.06.2025 11:14:25 --> Helper loaded: language_helper
INFO - 26.06.2025 11:14:25 --> Helper loaded: text_helper
INFO - 26.06.2025 11:14:25 --> Helper loaded: string_helper
INFO - 26.06.2025 11:14:25 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:14:25 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:14:25 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:14:25 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:14:25 --> Email Class Initialized
INFO - 26.06.2025 11:14:25 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:14:25 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:14:25 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:14:25 --> Helper loaded: date_helper
INFO - 26.06.2025 11:14:25 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:14:25 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:14:25 --> Helper loaded: form_helper
INFO - 26.06.2025 11:14:25 --> Form Validation Class Initialized
INFO - 26.06.2025 11:14:25 --> Upload Class Initialized
INFO - 26.06.2025 11:14:25 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:14:25 --> Pagination Class Initialized
INFO - 26.06.2025 11:14:25 --> Controller Class Initialized
INFO - 26.06.2025 11:14:25 --> Model "Article_model" initialized
INFO - 26.06.2025 11:14:25 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:14:25 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:14:26 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:14:26 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:14:26 --> Final output sent to browser
DEBUG - 26.06.2025 11:14:26 --> Total execution time: 0.3832
INFO - 26.06.2025 11:16:05 --> Config Class Initialized
INFO - 26.06.2025 11:16:05 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:16:05 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:16:05 --> Utf8 Class Initialized
INFO - 26.06.2025 11:16:05 --> URI Class Initialized
INFO - 26.06.2025 11:16:05 --> Router Class Initialized
INFO - 26.06.2025 11:16:05 --> Output Class Initialized
INFO - 26.06.2025 11:16:05 --> Security Class Initialized
DEBUG - 26.06.2025 11:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:16:05 --> Input Class Initialized
INFO - 26.06.2025 11:16:05 --> Language Class Initialized
INFO - 26.06.2025 11:16:05 --> Loader Class Initialized
INFO - 26.06.2025 11:16:05 --> Helper loaded: app_helper
INFO - 26.06.2025 11:16:05 --> Helper loaded: language_helper
INFO - 26.06.2025 11:16:05 --> Helper loaded: text_helper
INFO - 26.06.2025 11:16:05 --> Helper loaded: string_helper
INFO - 26.06.2025 11:16:05 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:16:05 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:16:05 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:16:05 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:16:05 --> Email Class Initialized
INFO - 26.06.2025 11:16:05 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:16:05 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:16:05 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:05 --> Helper loaded: date_helper
INFO - 26.06.2025 11:16:05 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:16:05 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:05 --> Helper loaded: form_helper
INFO - 26.06.2025 11:16:05 --> Form Validation Class Initialized
INFO - 26.06.2025 11:16:05 --> Upload Class Initialized
INFO - 26.06.2025 11:16:05 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:16:05 --> Pagination Class Initialized
INFO - 26.06.2025 11:16:05 --> Controller Class Initialized
INFO - 26.06.2025 11:16:05 --> Model "Article_model" initialized
INFO - 26.06.2025 11:16:05 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:16:05 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:16:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:16:05 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 935
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
            [thumb_image] => uploads/articles/sections/ueber-styx_section_0_thumb.jpg
        )

)

INFO - 26.06.2025 11:16:05 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:16:05 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:16:05 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:16:05 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:16:05 --> Final output sent to browser
DEBUG - 26.06.2025 11:16:05 --> Total execution time: 0.4949
INFO - 26.06.2025 11:16:10 --> Config Class Initialized
INFO - 26.06.2025 11:16:10 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:16:10 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:16:10 --> Utf8 Class Initialized
INFO - 26.06.2025 11:16:10 --> URI Class Initialized
INFO - 26.06.2025 11:16:10 --> Router Class Initialized
INFO - 26.06.2025 11:16:10 --> Output Class Initialized
INFO - 26.06.2025 11:16:10 --> Security Class Initialized
DEBUG - 26.06.2025 11:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:16:10 --> Input Class Initialized
INFO - 26.06.2025 11:16:10 --> Language Class Initialized
INFO - 26.06.2025 11:16:10 --> Loader Class Initialized
INFO - 26.06.2025 11:16:10 --> Helper loaded: app_helper
INFO - 26.06.2025 11:16:10 --> Helper loaded: language_helper
INFO - 26.06.2025 11:16:10 --> Helper loaded: text_helper
INFO - 26.06.2025 11:16:10 --> Helper loaded: string_helper
INFO - 26.06.2025 11:16:10 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:16:10 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:16:10 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:16:10 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:16:10 --> Email Class Initialized
INFO - 26.06.2025 11:16:10 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:16:10 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:16:10 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:16:10 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:10 --> Helper loaded: date_helper
INFO - 26.06.2025 11:16:10 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:16:10 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:10 --> Helper loaded: form_helper
INFO - 26.06.2025 11:16:10 --> Form Validation Class Initialized
INFO - 26.06.2025 11:16:10 --> Upload Class Initialized
INFO - 26.06.2025 11:16:10 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:16:10 --> Pagination Class Initialized
INFO - 26.06.2025 11:16:10 --> Controller Class Initialized
INFO - 26.06.2025 11:16:10 --> Model "Article_model" initialized
INFO - 26.06.2025 11:16:10 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:16:10 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:16:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:16:10 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 935
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
            [thumb_image] => uploads/articles/sections/ueber-styx_section_0_thumb.jpg
        )

)

INFO - 26.06.2025 11:16:10 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:16:10 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:16:10 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:16:10 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:16:10 --> Final output sent to browser
DEBUG - 26.06.2025 11:16:10 --> Total execution time: 0.4750
INFO - 26.06.2025 11:16:13 --> Config Class Initialized
INFO - 26.06.2025 11:16:13 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:16:13 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:16:13 --> Utf8 Class Initialized
INFO - 26.06.2025 11:16:13 --> URI Class Initialized
INFO - 26.06.2025 11:16:13 --> Router Class Initialized
INFO - 26.06.2025 11:16:13 --> Output Class Initialized
INFO - 26.06.2025 11:16:13 --> Security Class Initialized
DEBUG - 26.06.2025 11:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:16:13 --> Input Class Initialized
INFO - 26.06.2025 11:16:13 --> Language Class Initialized
INFO - 26.06.2025 11:16:13 --> Loader Class Initialized
INFO - 26.06.2025 11:16:13 --> Helper loaded: app_helper
INFO - 26.06.2025 11:16:13 --> Helper loaded: language_helper
INFO - 26.06.2025 11:16:13 --> Helper loaded: text_helper
INFO - 26.06.2025 11:16:13 --> Helper loaded: string_helper
INFO - 26.06.2025 11:16:13 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:16:13 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:16:13 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:16:14 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:16:14 --> Email Class Initialized
INFO - 26.06.2025 11:16:14 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:16:14 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:16:14 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:14 --> Helper loaded: date_helper
INFO - 26.06.2025 11:16:14 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:14 --> Helper loaded: form_helper
INFO - 26.06.2025 11:16:14 --> Form Validation Class Initialized
INFO - 26.06.2025 11:16:14 --> Upload Class Initialized
INFO - 26.06.2025 11:16:14 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:16:14 --> Pagination Class Initialized
INFO - 26.06.2025 11:16:14 --> Controller Class Initialized
INFO - 26.06.2025 11:16:14 --> Model "Article_model" initialized
INFO - 26.06.2025 11:16:14 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:16:14 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:16:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:16:14 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 935
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
            [thumb_image] => uploads/articles/sections/ueber-styx_section_0_thumb.jpg
        )

)

INFO - 26.06.2025 11:16:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:16:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:16:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:16:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:16:14 --> Final output sent to browser
DEBUG - 26.06.2025 11:16:14 --> Total execution time: 0.4738
INFO - 26.06.2025 11:16:17 --> Config Class Initialized
INFO - 26.06.2025 11:16:17 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:16:17 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:16:17 --> Utf8 Class Initialized
INFO - 26.06.2025 11:16:17 --> URI Class Initialized
INFO - 26.06.2025 11:16:17 --> Router Class Initialized
INFO - 26.06.2025 11:16:17 --> Output Class Initialized
INFO - 26.06.2025 11:16:17 --> Security Class Initialized
DEBUG - 26.06.2025 11:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:16:17 --> Input Class Initialized
INFO - 26.06.2025 11:16:17 --> Language Class Initialized
INFO - 26.06.2025 11:16:17 --> Loader Class Initialized
INFO - 26.06.2025 11:16:17 --> Helper loaded: app_helper
INFO - 26.06.2025 11:16:17 --> Helper loaded: language_helper
INFO - 26.06.2025 11:16:17 --> Helper loaded: text_helper
INFO - 26.06.2025 11:16:17 --> Helper loaded: string_helper
INFO - 26.06.2025 11:16:17 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:16:17 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:16:17 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:16:17 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:16:17 --> Email Class Initialized
INFO - 26.06.2025 11:16:17 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:16:17 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:16:17 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:17 --> Helper loaded: date_helper
INFO - 26.06.2025 11:16:17 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:16:17 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:17 --> Helper loaded: form_helper
INFO - 26.06.2025 11:16:17 --> Form Validation Class Initialized
INFO - 26.06.2025 11:16:17 --> Upload Class Initialized
INFO - 26.06.2025 11:16:17 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:16:17 --> Pagination Class Initialized
INFO - 26.06.2025 11:16:17 --> Controller Class Initialized
INFO - 26.06.2025 11:16:17 --> Model "Article_model" initialized
INFO - 26.06.2025 11:16:17 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:16:17 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:16:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:16:17 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 935
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
            [thumb_image] => uploads/articles/sections/ueber-styx_section_0_thumb.jpg
        )

)

INFO - 26.06.2025 11:16:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:16:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:16:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:16:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:16:18 --> Final output sent to browser
DEBUG - 26.06.2025 11:16:18 --> Total execution time: 0.4711
INFO - 26.06.2025 11:16:18 --> Config Class Initialized
INFO - 26.06.2025 11:16:18 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:16:18 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:16:18 --> Utf8 Class Initialized
INFO - 26.06.2025 11:16:18 --> URI Class Initialized
INFO - 26.06.2025 11:16:18 --> Router Class Initialized
INFO - 26.06.2025 11:16:18 --> Output Class Initialized
INFO - 26.06.2025 11:16:18 --> Security Class Initialized
DEBUG - 26.06.2025 11:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:16:18 --> Input Class Initialized
INFO - 26.06.2025 11:16:18 --> Language Class Initialized
INFO - 26.06.2025 11:16:18 --> Loader Class Initialized
INFO - 26.06.2025 11:16:18 --> Helper loaded: app_helper
INFO - 26.06.2025 11:16:18 --> Helper loaded: language_helper
INFO - 26.06.2025 11:16:18 --> Helper loaded: text_helper
INFO - 26.06.2025 11:16:18 --> Helper loaded: string_helper
INFO - 26.06.2025 11:16:18 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:16:18 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:16:18 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:16:18 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:16:18 --> Email Class Initialized
INFO - 26.06.2025 11:16:18 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:16:18 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:16:18 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:18 --> Helper loaded: date_helper
INFO - 26.06.2025 11:16:18 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:16:18 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:18 --> Helper loaded: form_helper
INFO - 26.06.2025 11:16:18 --> Form Validation Class Initialized
INFO - 26.06.2025 11:16:18 --> Upload Class Initialized
INFO - 26.06.2025 11:16:18 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:16:18 --> Pagination Class Initialized
INFO - 26.06.2025 11:16:18 --> Controller Class Initialized
INFO - 26.06.2025 11:16:18 --> Model "App_model" initialized
INFO - 26.06.2025 11:16:18 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:16:18 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/ueber-styx_section_0.jpg
ERROR - 26.06.2025 11:16:18 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:16:18 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:16:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:16:18 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:16:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:16:18 --> Final output sent to browser
DEBUG - 26.06.2025 11:16:18 --> Total execution time: 0.4871
INFO - 26.06.2025 11:16:22 --> Config Class Initialized
INFO - 26.06.2025 11:16:22 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:16:22 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:16:22 --> Utf8 Class Initialized
INFO - 26.06.2025 11:16:22 --> URI Class Initialized
INFO - 26.06.2025 11:16:22 --> Router Class Initialized
INFO - 26.06.2025 11:16:22 --> Output Class Initialized
INFO - 26.06.2025 11:16:22 --> Security Class Initialized
DEBUG - 26.06.2025 11:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:16:22 --> Input Class Initialized
INFO - 26.06.2025 11:16:22 --> Language Class Initialized
INFO - 26.06.2025 11:16:22 --> Loader Class Initialized
INFO - 26.06.2025 11:16:22 --> Helper loaded: app_helper
INFO - 26.06.2025 11:16:22 --> Helper loaded: language_helper
INFO - 26.06.2025 11:16:22 --> Helper loaded: text_helper
INFO - 26.06.2025 11:16:22 --> Helper loaded: string_helper
INFO - 26.06.2025 11:16:22 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:16:22 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:16:22 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:16:23 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:16:23 --> Email Class Initialized
INFO - 26.06.2025 11:16:23 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:16:23 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:16:23 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:23 --> Helper loaded: date_helper
INFO - 26.06.2025 11:16:23 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:23 --> Helper loaded: form_helper
INFO - 26.06.2025 11:16:23 --> Form Validation Class Initialized
INFO - 26.06.2025 11:16:23 --> Upload Class Initialized
INFO - 26.06.2025 11:16:23 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:16:23 --> Pagination Class Initialized
INFO - 26.06.2025 11:16:23 --> Controller Class Initialized
INFO - 26.06.2025 11:16:23 --> Model "Article_model" initialized
INFO - 26.06.2025 11:16:23 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:16:23 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:16:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:16:23 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:16:23 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/herr_styx.jpg
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:16:23 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => uploads/articles/sections/herr_styx.jpg
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:16:23 --> Using existing image: 
DEBUG - 26.06.2025 11:16:23 --> Updated is_main for other articles in category 89
DEBUG - 26.06.2025 11:16:23 --> Database save successful for article ID: 46
DEBUG - 26.06.2025 11:16:23 --> Processing section image upload for index 0: herr_styx.jpg
INFO - 26.06.2025 11:16:23 --> Image Lib Class Initialized
DEBUG - 26.06.2025 11:16:23 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:16:23 --> Section image uploaded successfully for index 0: original=uploads/articles/sections/ueber-styx_section_0.jpg, thumb=uploads/articles/sections/ueber-styx_section_0_thumb.jpg
DEBUG - 26.06.2025 11:16:23 --> Inserting section 0: Array
(
    [article_id] => 46
    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
    [image] => uploads/articles/sections/ueber-styx_section_0.jpg
    [thumb_image] => uploads/articles/sections/ueber-styx_section_0_thumb.jpg
    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
    [button_name] => lokfff
    [subpage] => 
    [external_url] => 
    [order] => 0
)

INFO - 26.06.2025 11:16:23 --> Config Class Initialized
INFO - 26.06.2025 11:16:23 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:16:23 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:16:23 --> Utf8 Class Initialized
INFO - 26.06.2025 11:16:23 --> URI Class Initialized
INFO - 26.06.2025 11:16:23 --> Router Class Initialized
INFO - 26.06.2025 11:16:23 --> Output Class Initialized
INFO - 26.06.2025 11:16:23 --> Security Class Initialized
DEBUG - 26.06.2025 11:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:16:23 --> Input Class Initialized
INFO - 26.06.2025 11:16:23 --> Language Class Initialized
INFO - 26.06.2025 11:16:23 --> Loader Class Initialized
INFO - 26.06.2025 11:16:23 --> Helper loaded: app_helper
INFO - 26.06.2025 11:16:23 --> Helper loaded: language_helper
INFO - 26.06.2025 11:16:23 --> Helper loaded: text_helper
INFO - 26.06.2025 11:16:23 --> Helper loaded: string_helper
INFO - 26.06.2025 11:16:23 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:16:23 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:16:23 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:16:23 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:16:23 --> Email Class Initialized
INFO - 26.06.2025 11:16:23 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:16:23 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:16:23 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:23 --> Helper loaded: date_helper
INFO - 26.06.2025 11:16:23 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:16:23 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:23 --> Helper loaded: form_helper
INFO - 26.06.2025 11:16:23 --> Form Validation Class Initialized
INFO - 26.06.2025 11:16:23 --> Upload Class Initialized
INFO - 26.06.2025 11:16:23 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:16:23 --> Pagination Class Initialized
INFO - 26.06.2025 11:16:23 --> Controller Class Initialized
INFO - 26.06.2025 11:16:23 --> Model "Article_model" initialized
INFO - 26.06.2025 11:16:23 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:16:23 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:16:23 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:16:23 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:16:23 --> Final output sent to browser
DEBUG - 26.06.2025 11:16:23 --> Total execution time: 0.3795
INFO - 26.06.2025 11:19:30 --> Config Class Initialized
INFO - 26.06.2025 11:19:30 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:19:30 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:19:30 --> Utf8 Class Initialized
INFO - 26.06.2025 11:19:30 --> URI Class Initialized
INFO - 26.06.2025 11:19:30 --> Router Class Initialized
INFO - 26.06.2025 11:19:30 --> Output Class Initialized
INFO - 26.06.2025 11:19:30 --> Security Class Initialized
DEBUG - 26.06.2025 11:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:19:30 --> Input Class Initialized
INFO - 26.06.2025 11:19:30 --> Language Class Initialized
INFO - 26.06.2025 11:19:30 --> Loader Class Initialized
INFO - 26.06.2025 11:19:30 --> Helper loaded: app_helper
INFO - 26.06.2025 11:19:30 --> Helper loaded: language_helper
INFO - 26.06.2025 11:19:30 --> Helper loaded: text_helper
INFO - 26.06.2025 11:19:30 --> Helper loaded: string_helper
INFO - 26.06.2025 11:19:30 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:19:30 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:19:30 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:19:30 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:19:30 --> Email Class Initialized
INFO - 26.06.2025 11:19:30 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:19:30 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:19:30 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:19:30 --> Helper loaded: date_helper
INFO - 26.06.2025 11:19:30 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:19:30 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:19:30 --> Helper loaded: form_helper
INFO - 26.06.2025 11:19:30 --> Form Validation Class Initialized
INFO - 26.06.2025 11:19:30 --> Upload Class Initialized
INFO - 26.06.2025 11:19:30 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:19:30 --> Pagination Class Initialized
INFO - 26.06.2025 11:19:30 --> Controller Class Initialized
INFO - 26.06.2025 11:19:30 --> Model "Article_model" initialized
INFO - 26.06.2025 11:19:30 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:19:30 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:19:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:19:30 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 936
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
            [thumb_image] => uploads/articles/sections/ueber-styx_section_0_thumb.jpg
        )

)

INFO - 26.06.2025 11:19:30 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:19:30 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:19:30 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:19:30 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:19:30 --> Final output sent to browser
DEBUG - 26.06.2025 11:19:30 --> Total execution time: 0.5396
INFO - 26.06.2025 11:19:30 --> Config Class Initialized
INFO - 26.06.2025 11:19:30 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:19:30 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:19:30 --> Utf8 Class Initialized
INFO - 26.06.2025 11:19:30 --> URI Class Initialized
INFO - 26.06.2025 11:19:30 --> Router Class Initialized
INFO - 26.06.2025 11:19:30 --> Output Class Initialized
INFO - 26.06.2025 11:19:30 --> Security Class Initialized
DEBUG - 26.06.2025 11:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:19:30 --> Input Class Initialized
INFO - 26.06.2025 11:19:30 --> Language Class Initialized
INFO - 26.06.2025 11:19:30 --> Loader Class Initialized
INFO - 26.06.2025 11:19:30 --> Helper loaded: app_helper
INFO - 26.06.2025 11:19:30 --> Helper loaded: language_helper
INFO - 26.06.2025 11:19:30 --> Helper loaded: text_helper
INFO - 26.06.2025 11:19:30 --> Helper loaded: string_helper
INFO - 26.06.2025 11:19:30 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:19:30 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:19:30 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:19:31 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:19:31 --> Email Class Initialized
INFO - 26.06.2025 11:19:31 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:19:31 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:19:31 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:19:31 --> Helper loaded: date_helper
INFO - 26.06.2025 11:19:31 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:19:31 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:19:31 --> Helper loaded: form_helper
INFO - 26.06.2025 11:19:31 --> Form Validation Class Initialized
INFO - 26.06.2025 11:19:31 --> Upload Class Initialized
INFO - 26.06.2025 11:19:31 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:19:31 --> Pagination Class Initialized
INFO - 26.06.2025 11:19:31 --> Controller Class Initialized
INFO - 26.06.2025 11:19:31 --> Model "App_model" initialized
INFO - 26.06.2025 11:19:31 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:19:31 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/ueber-styx_section_0.jpg
ERROR - 26.06.2025 11:19:31 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:19:31 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:19:31 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:19:31 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:19:31 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:19:31 --> Final output sent to browser
DEBUG - 26.06.2025 11:19:31 --> Total execution time: 0.4727
INFO - 26.06.2025 11:19:37 --> Config Class Initialized
INFO - 26.06.2025 11:19:37 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:19:37 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:19:37 --> Utf8 Class Initialized
INFO - 26.06.2025 11:19:37 --> URI Class Initialized
INFO - 26.06.2025 11:19:37 --> Router Class Initialized
INFO - 26.06.2025 11:19:37 --> Output Class Initialized
INFO - 26.06.2025 11:19:37 --> Security Class Initialized
DEBUG - 26.06.2025 11:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:19:37 --> Input Class Initialized
INFO - 26.06.2025 11:19:37 --> Language Class Initialized
INFO - 26.06.2025 11:19:37 --> Loader Class Initialized
INFO - 26.06.2025 11:19:37 --> Helper loaded: app_helper
INFO - 26.06.2025 11:19:37 --> Helper loaded: language_helper
INFO - 26.06.2025 11:19:37 --> Helper loaded: text_helper
INFO - 26.06.2025 11:19:37 --> Helper loaded: string_helper
INFO - 26.06.2025 11:19:37 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:19:37 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:19:37 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:19:37 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:19:37 --> Email Class Initialized
INFO - 26.06.2025 11:19:37 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:19:37 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:19:37 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:19:37 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:19:37 --> Helper loaded: date_helper
INFO - 26.06.2025 11:19:37 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:19:37 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:19:37 --> Helper loaded: form_helper
INFO - 26.06.2025 11:19:37 --> Form Validation Class Initialized
INFO - 26.06.2025 11:19:37 --> Upload Class Initialized
INFO - 26.06.2025 11:19:37 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:19:37 --> Pagination Class Initialized
INFO - 26.06.2025 11:19:37 --> Controller Class Initialized
INFO - 26.06.2025 11:19:37 --> Model "Article_model" initialized
INFO - 26.06.2025 11:19:37 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:19:37 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:19:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:19:37 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:19:37 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/herr_styx.jpg
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:19:37 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => uploads/articles/sections/herr_styx.jpg
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:19:37 --> Using existing image: 
DEBUG - 26.06.2025 11:19:37 --> Updated is_main for other articles in category 89
DEBUG - 26.06.2025 11:19:37 --> Database save successful for article ID: 46
DEBUG - 26.06.2025 11:19:37 --> Processing section image upload for index 0: herr_styx.jpg
INFO - 26.06.2025 11:19:37 --> Image Lib Class Initialized
DEBUG - 26.06.2025 11:19:37 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:19:37 --> Section image uploaded successfully for index 0: original=uploads/articles/sections/ueber-styx_section_0_1750936777.jpg, thumb=uploads/articles/sections/ueber-styx_section_0_1750936777_thumb.jpg
DEBUG - 26.06.2025 11:19:37 --> Inserting section 0: Array
(
    [article_id] => 46
    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
    [image] => uploads/articles/sections/ueber-styx_section_0_1750936777.jpg
    [thumb_image] => uploads/articles/sections/ueber-styx_section_0_1750936777_thumb.jpg
    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
    [button_name] => lokfff
    [subpage] => 
    [external_url] => 
    [order] => 0
)

INFO - 26.06.2025 11:19:37 --> Config Class Initialized
INFO - 26.06.2025 11:19:37 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:19:37 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:19:37 --> Utf8 Class Initialized
INFO - 26.06.2025 11:19:37 --> URI Class Initialized
INFO - 26.06.2025 11:19:37 --> Router Class Initialized
INFO - 26.06.2025 11:19:37 --> Output Class Initialized
INFO - 26.06.2025 11:19:37 --> Security Class Initialized
DEBUG - 26.06.2025 11:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:19:37 --> Input Class Initialized
INFO - 26.06.2025 11:19:37 --> Language Class Initialized
INFO - 26.06.2025 11:19:37 --> Loader Class Initialized
INFO - 26.06.2025 11:19:37 --> Helper loaded: app_helper
INFO - 26.06.2025 11:19:37 --> Helper loaded: language_helper
INFO - 26.06.2025 11:19:37 --> Helper loaded: text_helper
INFO - 26.06.2025 11:19:37 --> Helper loaded: string_helper
INFO - 26.06.2025 11:19:37 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:19:37 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:19:37 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:19:38 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:19:38 --> Email Class Initialized
INFO - 26.06.2025 11:19:38 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:19:38 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:19:38 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:19:38 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:19:38 --> Helper loaded: date_helper
INFO - 26.06.2025 11:19:38 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:19:38 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:19:38 --> Helper loaded: form_helper
INFO - 26.06.2025 11:19:38 --> Form Validation Class Initialized
INFO - 26.06.2025 11:19:38 --> Upload Class Initialized
INFO - 26.06.2025 11:19:38 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:19:38 --> Pagination Class Initialized
INFO - 26.06.2025 11:19:38 --> Controller Class Initialized
INFO - 26.06.2025 11:19:38 --> Model "Article_model" initialized
INFO - 26.06.2025 11:19:38 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:19:38 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:19:38 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:19:38 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:19:38 --> Final output sent to browser
DEBUG - 26.06.2025 11:19:38 --> Total execution time: 0.3923
INFO - 26.06.2025 11:21:39 --> Config Class Initialized
INFO - 26.06.2025 11:21:39 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:21:39 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:21:39 --> Utf8 Class Initialized
INFO - 26.06.2025 11:21:39 --> URI Class Initialized
INFO - 26.06.2025 11:21:40 --> Router Class Initialized
INFO - 26.06.2025 11:21:40 --> Output Class Initialized
INFO - 26.06.2025 11:21:40 --> Security Class Initialized
DEBUG - 26.06.2025 11:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:21:40 --> Input Class Initialized
INFO - 26.06.2025 11:21:40 --> Language Class Initialized
INFO - 26.06.2025 11:21:40 --> Loader Class Initialized
INFO - 26.06.2025 11:21:40 --> Helper loaded: app_helper
INFO - 26.06.2025 11:21:40 --> Helper loaded: language_helper
INFO - 26.06.2025 11:21:40 --> Helper loaded: text_helper
INFO - 26.06.2025 11:21:40 --> Helper loaded: string_helper
INFO - 26.06.2025 11:21:40 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:21:40 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:21:40 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:21:40 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:21:40 --> Email Class Initialized
INFO - 26.06.2025 11:21:40 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:21:40 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:21:40 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:21:40 --> Helper loaded: date_helper
INFO - 26.06.2025 11:21:40 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:21:40 --> Helper loaded: form_helper
INFO - 26.06.2025 11:21:40 --> Form Validation Class Initialized
INFO - 26.06.2025 11:21:40 --> Upload Class Initialized
INFO - 26.06.2025 11:21:40 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:21:40 --> Pagination Class Initialized
INFO - 26.06.2025 11:21:40 --> Controller Class Initialized
INFO - 26.06.2025 11:21:40 --> Model "Article_model" initialized
INFO - 26.06.2025 11:21:40 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:21:40 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:21:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:21:40 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 937
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0_1750936777.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
            [thumb_image] => uploads/articles/sections/ueber-styx_section_0_1750936777_thumb.jpg
        )

)

INFO - 26.06.2025 11:21:40 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:21:40 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:21:40 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:21:40 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:21:40 --> Final output sent to browser
DEBUG - 26.06.2025 11:21:40 --> Total execution time: 0.4854
INFO - 26.06.2025 11:21:40 --> Config Class Initialized
INFO - 26.06.2025 11:21:40 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:21:40 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:21:40 --> Utf8 Class Initialized
INFO - 26.06.2025 11:21:40 --> URI Class Initialized
INFO - 26.06.2025 11:21:40 --> Router Class Initialized
INFO - 26.06.2025 11:21:40 --> Output Class Initialized
INFO - 26.06.2025 11:21:40 --> Security Class Initialized
DEBUG - 26.06.2025 11:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:21:40 --> Input Class Initialized
INFO - 26.06.2025 11:21:40 --> Language Class Initialized
INFO - 26.06.2025 11:21:40 --> Loader Class Initialized
INFO - 26.06.2025 11:21:40 --> Helper loaded: app_helper
INFO - 26.06.2025 11:21:40 --> Helper loaded: language_helper
INFO - 26.06.2025 11:21:40 --> Helper loaded: text_helper
INFO - 26.06.2025 11:21:40 --> Helper loaded: string_helper
INFO - 26.06.2025 11:21:40 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:21:40 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:21:40 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:21:40 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:21:40 --> Email Class Initialized
INFO - 26.06.2025 11:21:40 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:21:40 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:21:40 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:21:40 --> Helper loaded: date_helper
INFO - 26.06.2025 11:21:40 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:21:40 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:21:40 --> Helper loaded: form_helper
INFO - 26.06.2025 11:21:40 --> Form Validation Class Initialized
INFO - 26.06.2025 11:21:40 --> Upload Class Initialized
INFO - 26.06.2025 11:21:40 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:21:40 --> Pagination Class Initialized
INFO - 26.06.2025 11:21:40 --> Controller Class Initialized
INFO - 26.06.2025 11:21:40 --> Model "App_model" initialized
INFO - 26.06.2025 11:21:40 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:21:40 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/ueber-styx_section_0_1750936777.jpg
ERROR - 26.06.2025 11:21:40 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:21:40 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:21:41 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:21:41 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:21:41 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:21:41 --> Final output sent to browser
DEBUG - 26.06.2025 11:21:41 --> Total execution time: 0.4647
INFO - 26.06.2025 11:21:46 --> Config Class Initialized
INFO - 26.06.2025 11:21:46 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:21:46 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:21:46 --> Utf8 Class Initialized
INFO - 26.06.2025 11:21:46 --> URI Class Initialized
INFO - 26.06.2025 11:21:46 --> Router Class Initialized
INFO - 26.06.2025 11:21:46 --> Output Class Initialized
INFO - 26.06.2025 11:21:46 --> Security Class Initialized
DEBUG - 26.06.2025 11:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:21:46 --> Input Class Initialized
INFO - 26.06.2025 11:21:46 --> Language Class Initialized
INFO - 26.06.2025 11:21:46 --> Loader Class Initialized
INFO - 26.06.2025 11:21:46 --> Helper loaded: app_helper
INFO - 26.06.2025 11:21:46 --> Helper loaded: language_helper
INFO - 26.06.2025 11:21:46 --> Helper loaded: text_helper
INFO - 26.06.2025 11:21:46 --> Helper loaded: string_helper
INFO - 26.06.2025 11:21:46 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:21:46 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:21:46 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:21:46 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:21:46 --> Email Class Initialized
INFO - 26.06.2025 11:21:46 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:21:46 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:21:46 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:21:46 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:21:46 --> Helper loaded: date_helper
INFO - 26.06.2025 11:21:46 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:21:46 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:21:46 --> Helper loaded: form_helper
INFO - 26.06.2025 11:21:46 --> Form Validation Class Initialized
INFO - 26.06.2025 11:21:46 --> Upload Class Initialized
INFO - 26.06.2025 11:21:46 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:21:46 --> Pagination Class Initialized
INFO - 26.06.2025 11:21:46 --> Controller Class Initialized
INFO - 26.06.2025 11:21:46 --> Model "Article_model" initialized
INFO - 26.06.2025 11:21:46 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:21:46 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:21:46 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:21:46 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0_1750936777.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:21:46 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/herr_styx.jpg
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:21:46 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0_1750936777.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => uploads/articles/sections/herr_styx.jpg
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:21:46 --> Using existing image: 
DEBUG - 26.06.2025 11:21:46 --> Updated is_main for other articles in category 89
DEBUG - 26.06.2025 11:21:46 --> Database save successful for article ID: 46
DEBUG - 26.06.2025 11:21:47 --> Processing section image upload for index 0: herr_styx.jpg
INFO - 26.06.2025 11:21:47 --> Image Lib Class Initialized
DEBUG - 26.06.2025 11:21:47 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:21:47 --> Section image uploaded successfully for index 0: original=uploads/articles/sections/ueber-styx_section_0.jpg, thumb=uploads/articles/sections/ueber-styx_section_0_thumb.jpg
DEBUG - 26.06.2025 11:21:47 --> Inserting section 0: Array
(
    [article_id] => 46
    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
    [image] => uploads/articles/sections/ueber-styx_section_0.jpg
    [thumb_image] => uploads/articles/sections/ueber-styx_section_0_thumb.jpg
    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
    [button_name] => lokfff
    [subpage] => 
    [external_url] => 
    [order] => 0
)

INFO - 26.06.2025 11:21:47 --> Config Class Initialized
INFO - 26.06.2025 11:21:47 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:21:47 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:21:47 --> Utf8 Class Initialized
INFO - 26.06.2025 11:21:47 --> URI Class Initialized
INFO - 26.06.2025 11:21:47 --> Router Class Initialized
INFO - 26.06.2025 11:21:47 --> Output Class Initialized
INFO - 26.06.2025 11:21:47 --> Security Class Initialized
DEBUG - 26.06.2025 11:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:21:47 --> Input Class Initialized
INFO - 26.06.2025 11:21:47 --> Language Class Initialized
INFO - 26.06.2025 11:21:47 --> Loader Class Initialized
INFO - 26.06.2025 11:21:47 --> Helper loaded: app_helper
INFO - 26.06.2025 11:21:47 --> Helper loaded: language_helper
INFO - 26.06.2025 11:21:47 --> Helper loaded: text_helper
INFO - 26.06.2025 11:21:47 --> Helper loaded: string_helper
INFO - 26.06.2025 11:21:47 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:21:47 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:21:47 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:21:47 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:21:47 --> Email Class Initialized
INFO - 26.06.2025 11:21:47 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:21:47 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:21:47 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:21:47 --> Helper loaded: date_helper
INFO - 26.06.2025 11:21:47 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:21:47 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:21:47 --> Helper loaded: form_helper
INFO - 26.06.2025 11:21:47 --> Form Validation Class Initialized
INFO - 26.06.2025 11:21:47 --> Upload Class Initialized
INFO - 26.06.2025 11:21:47 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:21:47 --> Pagination Class Initialized
INFO - 26.06.2025 11:21:47 --> Controller Class Initialized
INFO - 26.06.2025 11:21:47 --> Model "Article_model" initialized
INFO - 26.06.2025 11:21:47 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:21:47 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:21:47 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:21:47 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:21:47 --> Final output sent to browser
DEBUG - 26.06.2025 11:21:47 --> Total execution time: 0.3980
INFO - 26.06.2025 11:23:56 --> Config Class Initialized
INFO - 26.06.2025 11:23:56 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:23:56 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:23:56 --> Utf8 Class Initialized
INFO - 26.06.2025 11:23:56 --> URI Class Initialized
INFO - 26.06.2025 11:23:56 --> Router Class Initialized
INFO - 26.06.2025 11:23:56 --> Output Class Initialized
INFO - 26.06.2025 11:23:56 --> Security Class Initialized
DEBUG - 26.06.2025 11:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:23:56 --> Input Class Initialized
INFO - 26.06.2025 11:23:56 --> Language Class Initialized
INFO - 26.06.2025 11:23:56 --> Loader Class Initialized
INFO - 26.06.2025 11:23:56 --> Helper loaded: app_helper
INFO - 26.06.2025 11:23:56 --> Helper loaded: language_helper
INFO - 26.06.2025 11:23:56 --> Helper loaded: text_helper
INFO - 26.06.2025 11:23:56 --> Helper loaded: string_helper
INFO - 26.06.2025 11:23:56 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:23:56 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:23:56 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:23:57 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:23:57 --> Email Class Initialized
INFO - 26.06.2025 11:23:57 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:23:57 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:23:57 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:23:57 --> Helper loaded: date_helper
INFO - 26.06.2025 11:23:57 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:23:57 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:23:57 --> Helper loaded: form_helper
INFO - 26.06.2025 11:23:57 --> Form Validation Class Initialized
INFO - 26.06.2025 11:23:57 --> Upload Class Initialized
INFO - 26.06.2025 11:23:57 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:23:57 --> Pagination Class Initialized
INFO - 26.06.2025 11:23:57 --> Controller Class Initialized
INFO - 26.06.2025 11:23:57 --> Model "Article_model" initialized
INFO - 26.06.2025 11:23:57 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:23:57 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:23:57 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:23:57 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:23:57 --> Final output sent to browser
DEBUG - 26.06.2025 11:23:57 --> Total execution time: 0.4076
INFO - 26.06.2025 11:23:58 --> Config Class Initialized
INFO - 26.06.2025 11:23:58 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:23:58 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:23:58 --> Utf8 Class Initialized
INFO - 26.06.2025 11:23:58 --> URI Class Initialized
INFO - 26.06.2025 11:23:58 --> Router Class Initialized
INFO - 26.06.2025 11:23:58 --> Output Class Initialized
INFO - 26.06.2025 11:23:58 --> Security Class Initialized
DEBUG - 26.06.2025 11:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:23:58 --> Input Class Initialized
INFO - 26.06.2025 11:23:58 --> Language Class Initialized
INFO - 26.06.2025 11:23:58 --> Loader Class Initialized
INFO - 26.06.2025 11:23:58 --> Helper loaded: app_helper
INFO - 26.06.2025 11:23:58 --> Helper loaded: language_helper
INFO - 26.06.2025 11:23:58 --> Helper loaded: text_helper
INFO - 26.06.2025 11:23:58 --> Helper loaded: string_helper
INFO - 26.06.2025 11:23:58 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:23:58 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:23:58 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:23:58 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:23:58 --> Email Class Initialized
INFO - 26.06.2025 11:23:58 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:23:58 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:23:58 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:23:58 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:23:58 --> Helper loaded: date_helper
INFO - 26.06.2025 11:23:58 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:23:58 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:23:58 --> Helper loaded: form_helper
INFO - 26.06.2025 11:23:58 --> Form Validation Class Initialized
INFO - 26.06.2025 11:23:58 --> Upload Class Initialized
INFO - 26.06.2025 11:23:58 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:23:58 --> Pagination Class Initialized
INFO - 26.06.2025 11:23:58 --> Controller Class Initialized
INFO - 26.06.2025 11:23:58 --> Model "Article_model" initialized
INFO - 26.06.2025 11:23:58 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:23:58 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:23:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:23:58 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 938
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
            [thumb_image] => uploads/articles/sections/ueber-styx_section_0_thumb.jpg
        )

)

INFO - 26.06.2025 11:23:58 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:23:58 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:23:58 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:23:58 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:23:58 --> Final output sent to browser
DEBUG - 26.06.2025 11:23:58 --> Total execution time: 0.4629
INFO - 26.06.2025 11:23:58 --> Config Class Initialized
INFO - 26.06.2025 11:23:58 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:23:58 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:23:58 --> Utf8 Class Initialized
INFO - 26.06.2025 11:23:58 --> URI Class Initialized
INFO - 26.06.2025 11:23:58 --> Router Class Initialized
INFO - 26.06.2025 11:23:58 --> Output Class Initialized
INFO - 26.06.2025 11:23:58 --> Security Class Initialized
DEBUG - 26.06.2025 11:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:23:58 --> Input Class Initialized
INFO - 26.06.2025 11:23:58 --> Language Class Initialized
INFO - 26.06.2025 11:23:58 --> Loader Class Initialized
INFO - 26.06.2025 11:23:58 --> Helper loaded: app_helper
INFO - 26.06.2025 11:23:58 --> Helper loaded: language_helper
INFO - 26.06.2025 11:23:58 --> Helper loaded: text_helper
INFO - 26.06.2025 11:23:58 --> Helper loaded: string_helper
INFO - 26.06.2025 11:23:58 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:23:58 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:23:58 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:23:59 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:23:59 --> Email Class Initialized
INFO - 26.06.2025 11:23:59 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:23:59 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:23:59 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:23:59 --> Helper loaded: date_helper
INFO - 26.06.2025 11:23:59 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:23:59 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:23:59 --> Helper loaded: form_helper
INFO - 26.06.2025 11:23:59 --> Form Validation Class Initialized
INFO - 26.06.2025 11:23:59 --> Upload Class Initialized
INFO - 26.06.2025 11:23:59 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:23:59 --> Pagination Class Initialized
INFO - 26.06.2025 11:23:59 --> Controller Class Initialized
INFO - 26.06.2025 11:23:59 --> Model "App_model" initialized
INFO - 26.06.2025 11:23:59 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:23:59 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/ueber-styx_section_0.jpg
ERROR - 26.06.2025 11:23:59 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:23:59 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:23:59 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:23:59 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:23:59 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:23:59 --> Final output sent to browser
DEBUG - 26.06.2025 11:23:59 --> Total execution time: 0.4704
INFO - 26.06.2025 11:24:04 --> Config Class Initialized
INFO - 26.06.2025 11:24:04 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:24:04 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:24:04 --> Utf8 Class Initialized
INFO - 26.06.2025 11:24:04 --> URI Class Initialized
INFO - 26.06.2025 11:24:04 --> Router Class Initialized
INFO - 26.06.2025 11:24:04 --> Output Class Initialized
INFO - 26.06.2025 11:24:04 --> Security Class Initialized
DEBUG - 26.06.2025 11:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:24:04 --> Input Class Initialized
INFO - 26.06.2025 11:24:04 --> Language Class Initialized
INFO - 26.06.2025 11:24:04 --> Loader Class Initialized
INFO - 26.06.2025 11:24:04 --> Helper loaded: app_helper
INFO - 26.06.2025 11:24:04 --> Helper loaded: language_helper
INFO - 26.06.2025 11:24:04 --> Helper loaded: text_helper
INFO - 26.06.2025 11:24:04 --> Helper loaded: string_helper
INFO - 26.06.2025 11:24:04 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:24:04 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:24:04 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:24:04 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:24:04 --> Email Class Initialized
INFO - 26.06.2025 11:24:04 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:24:04 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:24:04 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:24:04 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:24:04 --> Helper loaded: date_helper
INFO - 26.06.2025 11:24:04 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:24:04 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:24:04 --> Helper loaded: form_helper
INFO - 26.06.2025 11:24:04 --> Form Validation Class Initialized
INFO - 26.06.2025 11:24:04 --> Upload Class Initialized
INFO - 26.06.2025 11:24:04 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:24:04 --> Pagination Class Initialized
INFO - 26.06.2025 11:24:04 --> Controller Class Initialized
INFO - 26.06.2025 11:24:04 --> Model "Article_model" initialized
INFO - 26.06.2025 11:24:04 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:24:05 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:24:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:24:05 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:24:05 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/herr_styx.jpg
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:24:05 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => uploads/articles/sections/herr_styx.jpg
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:24:05 --> Using existing image: 
DEBUG - 26.06.2025 11:24:05 --> Updated is_main for other articles in category 89
DEBUG - 26.06.2025 11:24:05 --> Database save successful for article ID: 46
DEBUG - 26.06.2025 11:24:05 --> Processing section image upload for index 0: herr_styx.jpg
INFO - 26.06.2025 11:24:05 --> Image Lib Class Initialized
ERROR - 26.06.2025 11:24:05 --> Severity: error --> Exception: file_exists(): Argument #1 ($filename) must be of type string, array given C:\Users\assist15\Desktop\project\STYX_web\application\models\Article_model.php 339
INFO - 26.06.2025 11:24:11 --> Config Class Initialized
INFO - 26.06.2025 11:24:11 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:24:11 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:24:11 --> Utf8 Class Initialized
INFO - 26.06.2025 11:24:11 --> URI Class Initialized
INFO - 26.06.2025 11:24:11 --> Router Class Initialized
INFO - 26.06.2025 11:24:11 --> Output Class Initialized
INFO - 26.06.2025 11:24:11 --> Security Class Initialized
DEBUG - 26.06.2025 11:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:24:11 --> Input Class Initialized
INFO - 26.06.2025 11:24:11 --> Language Class Initialized
INFO - 26.06.2025 11:24:11 --> Loader Class Initialized
INFO - 26.06.2025 11:24:11 --> Helper loaded: app_helper
INFO - 26.06.2025 11:24:11 --> Helper loaded: language_helper
INFO - 26.06.2025 11:24:11 --> Helper loaded: text_helper
INFO - 26.06.2025 11:24:11 --> Helper loaded: string_helper
INFO - 26.06.2025 11:24:11 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:24:11 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:24:11 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:24:11 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:24:11 --> Email Class Initialized
INFO - 26.06.2025 11:24:11 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:24:11 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:24:11 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:24:11 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:24:11 --> Helper loaded: date_helper
INFO - 26.06.2025 11:24:11 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:24:11 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:24:11 --> Helper loaded: form_helper
INFO - 26.06.2025 11:24:11 --> Form Validation Class Initialized
INFO - 26.06.2025 11:24:11 --> Upload Class Initialized
INFO - 26.06.2025 11:24:11 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:24:11 --> Pagination Class Initialized
INFO - 26.06.2025 11:24:11 --> Controller Class Initialized
INFO - 26.06.2025 11:24:11 --> Model "Article_model" initialized
INFO - 26.06.2025 11:24:11 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:24:11 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:24:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:24:11 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:24:11 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/herr_styx1.jpg
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:24:11 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => uploads/articles/sections/herr_styx1.jpg
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:24:11 --> Using existing image: 
DEBUG - 26.06.2025 11:24:11 --> Updated is_main for other articles in category 89
DEBUG - 26.06.2025 11:24:11 --> Database save successful for article ID: 46
DEBUG - 26.06.2025 11:24:11 --> Processing section image upload for index 0: herr_styx.jpg
INFO - 26.06.2025 11:24:11 --> Image Lib Class Initialized
ERROR - 26.06.2025 11:24:11 --> Severity: error --> Exception: file_exists(): Argument #1 ($filename) must be of type string, array given C:\Users\assist15\Desktop\project\STYX_web\application\models\Article_model.php 339
INFO - 26.06.2025 11:26:46 --> Config Class Initialized
INFO - 26.06.2025 11:26:46 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:26:46 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:26:46 --> Utf8 Class Initialized
INFO - 26.06.2025 11:26:46 --> URI Class Initialized
INFO - 26.06.2025 11:26:46 --> Router Class Initialized
INFO - 26.06.2025 11:26:46 --> Output Class Initialized
INFO - 26.06.2025 11:26:46 --> Security Class Initialized
DEBUG - 26.06.2025 11:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:26:46 --> Input Class Initialized
INFO - 26.06.2025 11:26:46 --> Language Class Initialized
INFO - 26.06.2025 11:26:46 --> Loader Class Initialized
INFO - 26.06.2025 11:26:46 --> Helper loaded: app_helper
INFO - 26.06.2025 11:26:46 --> Helper loaded: language_helper
INFO - 26.06.2025 11:26:46 --> Helper loaded: text_helper
INFO - 26.06.2025 11:26:46 --> Helper loaded: string_helper
INFO - 26.06.2025 11:26:46 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:26:46 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:26:46 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:26:46 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:26:46 --> Email Class Initialized
INFO - 26.06.2025 11:26:46 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:26:46 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:26:46 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:26:46 --> Helper loaded: date_helper
INFO - 26.06.2025 11:26:46 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:26:46 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:26:46 --> Helper loaded: form_helper
INFO - 26.06.2025 11:26:46 --> Form Validation Class Initialized
INFO - 26.06.2025 11:26:46 --> Upload Class Initialized
INFO - 26.06.2025 11:26:46 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:26:46 --> Pagination Class Initialized
INFO - 26.06.2025 11:26:46 --> Controller Class Initialized
INFO - 26.06.2025 11:26:46 --> Model "Article_model" initialized
INFO - 26.06.2025 11:26:46 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:26:46 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:26:46 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:26:46 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:26:46 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/herr_styx2.jpg
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:26:46 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => uploads/articles/sections/herr_styx2.jpg
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:26:46 --> Using existing image: 
DEBUG - 26.06.2025 11:26:46 --> Updated is_main for other articles in category 89
DEBUG - 26.06.2025 11:26:46 --> Database save successful for article ID: 46
DEBUG - 26.06.2025 11:26:46 --> Processing section image upload for index 0: herr_styx.jpg
INFO - 26.06.2025 11:26:46 --> Image Lib Class Initialized
ERROR - 26.06.2025 11:26:46 --> Severity: error --> Exception: file_exists(): Argument #1 ($filename) must be of type string, array given C:\Users\assist15\Desktop\project\STYX_web\application\models\Article_model.php 339
INFO - 26.06.2025 11:26:49 --> Config Class Initialized
INFO - 26.06.2025 11:26:49 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:26:49 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:26:49 --> Utf8 Class Initialized
INFO - 26.06.2025 11:26:49 --> URI Class Initialized
INFO - 26.06.2025 11:26:49 --> Router Class Initialized
INFO - 26.06.2025 11:26:49 --> Output Class Initialized
INFO - 26.06.2025 11:26:49 --> Security Class Initialized
DEBUG - 26.06.2025 11:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:26:49 --> Input Class Initialized
INFO - 26.06.2025 11:26:49 --> Language Class Initialized
INFO - 26.06.2025 11:26:49 --> Loader Class Initialized
INFO - 26.06.2025 11:26:49 --> Helper loaded: app_helper
INFO - 26.06.2025 11:26:49 --> Helper loaded: language_helper
INFO - 26.06.2025 11:26:49 --> Helper loaded: text_helper
INFO - 26.06.2025 11:26:49 --> Helper loaded: string_helper
INFO - 26.06.2025 11:26:49 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:26:49 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:26:49 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:26:49 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:26:49 --> Email Class Initialized
INFO - 26.06.2025 11:26:49 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:26:49 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:26:49 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:26:49 --> Helper loaded: date_helper
INFO - 26.06.2025 11:26:49 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:26:49 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:26:49 --> Helper loaded: form_helper
INFO - 26.06.2025 11:26:49 --> Form Validation Class Initialized
INFO - 26.06.2025 11:26:49 --> Upload Class Initialized
INFO - 26.06.2025 11:26:49 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:26:49 --> Pagination Class Initialized
INFO - 26.06.2025 11:26:49 --> Controller Class Initialized
INFO - 26.06.2025 11:26:49 --> Model "Article_model" initialized
INFO - 26.06.2025 11:26:49 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:26:49 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:26:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:26:49 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:26:49 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:26:49 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:26:49 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:26:49 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:26:49 --> Final output sent to browser
DEBUG - 26.06.2025 11:26:49 --> Total execution time: 0.5096
INFO - 26.06.2025 11:26:54 --> Config Class Initialized
INFO - 26.06.2025 11:26:54 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:26:54 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:26:54 --> Utf8 Class Initialized
INFO - 26.06.2025 11:26:54 --> URI Class Initialized
INFO - 26.06.2025 11:26:54 --> Router Class Initialized
INFO - 26.06.2025 11:26:54 --> Output Class Initialized
INFO - 26.06.2025 11:26:54 --> Security Class Initialized
DEBUG - 26.06.2025 11:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:26:54 --> Input Class Initialized
INFO - 26.06.2025 11:26:54 --> Language Class Initialized
INFO - 26.06.2025 11:26:54 --> Loader Class Initialized
INFO - 26.06.2025 11:26:54 --> Helper loaded: app_helper
INFO - 26.06.2025 11:26:54 --> Helper loaded: language_helper
INFO - 26.06.2025 11:26:54 --> Helper loaded: text_helper
INFO - 26.06.2025 11:26:54 --> Helper loaded: string_helper
INFO - 26.06.2025 11:26:54 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:26:54 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:26:54 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:26:54 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:26:54 --> Email Class Initialized
INFO - 26.06.2025 11:26:54 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:26:54 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:26:54 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:26:54 --> Helper loaded: date_helper
INFO - 26.06.2025 11:26:54 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:26:54 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:26:54 --> Helper loaded: form_helper
INFO - 26.06.2025 11:26:54 --> Form Validation Class Initialized
INFO - 26.06.2025 11:26:54 --> Upload Class Initialized
INFO - 26.06.2025 11:26:54 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:26:54 --> Pagination Class Initialized
INFO - 26.06.2025 11:26:54 --> Controller Class Initialized
INFO - 26.06.2025 11:26:54 --> Model "Article_model" initialized
INFO - 26.06.2025 11:26:54 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:26:54 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:26:54 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:26:54 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:26:54 --> Final output sent to browser
DEBUG - 26.06.2025 11:26:54 --> Total execution time: 0.3856
INFO - 26.06.2025 11:26:56 --> Config Class Initialized
INFO - 26.06.2025 11:26:56 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:26:56 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:26:56 --> Utf8 Class Initialized
INFO - 26.06.2025 11:26:56 --> URI Class Initialized
INFO - 26.06.2025 11:26:56 --> Router Class Initialized
INFO - 26.06.2025 11:26:56 --> Output Class Initialized
INFO - 26.06.2025 11:26:56 --> Security Class Initialized
DEBUG - 26.06.2025 11:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:26:56 --> Input Class Initialized
INFO - 26.06.2025 11:26:56 --> Language Class Initialized
INFO - 26.06.2025 11:26:56 --> Loader Class Initialized
INFO - 26.06.2025 11:26:56 --> Helper loaded: app_helper
INFO - 26.06.2025 11:26:56 --> Helper loaded: language_helper
INFO - 26.06.2025 11:26:56 --> Helper loaded: text_helper
INFO - 26.06.2025 11:26:56 --> Helper loaded: string_helper
INFO - 26.06.2025 11:26:56 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:26:56 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:26:56 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:26:56 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:26:56 --> Email Class Initialized
INFO - 26.06.2025 11:26:56 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:26:56 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:26:56 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:26:56 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:26:56 --> Helper loaded: date_helper
INFO - 26.06.2025 11:26:56 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:26:56 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:26:56 --> Helper loaded: form_helper
INFO - 26.06.2025 11:26:56 --> Form Validation Class Initialized
INFO - 26.06.2025 11:26:56 --> Upload Class Initialized
INFO - 26.06.2025 11:26:56 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:26:56 --> Pagination Class Initialized
INFO - 26.06.2025 11:26:56 --> Controller Class Initialized
INFO - 26.06.2025 11:26:56 --> Model "Article_model" initialized
INFO - 26.06.2025 11:26:56 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:26:56 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:26:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:26:56 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:26:56 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:26:56 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:26:56 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:26:56 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:26:56 --> Final output sent to browser
DEBUG - 26.06.2025 11:26:56 --> Total execution time: 0.4686
INFO - 26.06.2025 11:26:58 --> Config Class Initialized
INFO - 26.06.2025 11:26:58 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:26:58 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:26:58 --> Utf8 Class Initialized
INFO - 26.06.2025 11:26:58 --> URI Class Initialized
INFO - 26.06.2025 11:26:58 --> Router Class Initialized
INFO - 26.06.2025 11:26:58 --> Output Class Initialized
INFO - 26.06.2025 11:26:58 --> Security Class Initialized
DEBUG - 26.06.2025 11:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:26:58 --> Input Class Initialized
INFO - 26.06.2025 11:26:58 --> Language Class Initialized
INFO - 26.06.2025 11:26:58 --> Loader Class Initialized
INFO - 26.06.2025 11:26:58 --> Helper loaded: app_helper
INFO - 26.06.2025 11:26:58 --> Helper loaded: language_helper
INFO - 26.06.2025 11:26:58 --> Helper loaded: text_helper
INFO - 26.06.2025 11:26:58 --> Helper loaded: string_helper
INFO - 26.06.2025 11:26:58 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:26:58 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:26:58 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:26:59 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:26:59 --> Email Class Initialized
INFO - 26.06.2025 11:26:59 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:26:59 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:26:59 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:26:59 --> Helper loaded: date_helper
INFO - 26.06.2025 11:26:59 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:26:59 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:26:59 --> Helper loaded: form_helper
INFO - 26.06.2025 11:26:59 --> Form Validation Class Initialized
INFO - 26.06.2025 11:26:59 --> Upload Class Initialized
INFO - 26.06.2025 11:26:59 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:26:59 --> Pagination Class Initialized
INFO - 26.06.2025 11:26:59 --> Controller Class Initialized
INFO - 26.06.2025 11:26:59 --> Model "Article_model" initialized
INFO - 26.06.2025 11:26:59 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:26:59 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:26:59 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:26:59 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:26:59 --> Final output sent to browser
DEBUG - 26.06.2025 11:26:59 --> Total execution time: 0.3960
INFO - 26.06.2025 11:27:04 --> Config Class Initialized
INFO - 26.06.2025 11:27:04 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:27:04 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:27:04 --> Utf8 Class Initialized
INFO - 26.06.2025 11:27:04 --> URI Class Initialized
INFO - 26.06.2025 11:27:04 --> Router Class Initialized
INFO - 26.06.2025 11:27:04 --> Output Class Initialized
INFO - 26.06.2025 11:27:04 --> Security Class Initialized
DEBUG - 26.06.2025 11:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:27:04 --> Input Class Initialized
INFO - 26.06.2025 11:27:04 --> Language Class Initialized
INFO - 26.06.2025 11:27:04 --> Loader Class Initialized
INFO - 26.06.2025 11:27:04 --> Helper loaded: app_helper
INFO - 26.06.2025 11:27:04 --> Helper loaded: language_helper
INFO - 26.06.2025 11:27:04 --> Helper loaded: text_helper
INFO - 26.06.2025 11:27:04 --> Helper loaded: string_helper
INFO - 26.06.2025 11:27:04 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:27:04 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:27:04 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:27:04 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:27:04 --> Email Class Initialized
INFO - 26.06.2025 11:27:04 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:27:04 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:27:04 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:04 --> Helper loaded: date_helper
INFO - 26.06.2025 11:27:04 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:27:04 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:04 --> Helper loaded: form_helper
INFO - 26.06.2025 11:27:04 --> Form Validation Class Initialized
INFO - 26.06.2025 11:27:04 --> Upload Class Initialized
INFO - 26.06.2025 11:27:04 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:27:04 --> Pagination Class Initialized
INFO - 26.06.2025 11:27:04 --> Controller Class Initialized
INFO - 26.06.2025 11:27:04 --> Model "Article_model" initialized
INFO - 26.06.2025 11:27:04 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:27:04 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:27:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:27:04 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:27:04 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:27:04 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:27:04 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:27:04 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:27:04 --> Final output sent to browser
DEBUG - 26.06.2025 11:27:04 --> Total execution time: 0.4988
INFO - 26.06.2025 11:27:11 --> Config Class Initialized
INFO - 26.06.2025 11:27:11 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:27:11 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:27:11 --> Utf8 Class Initialized
INFO - 26.06.2025 11:27:11 --> URI Class Initialized
INFO - 26.06.2025 11:27:11 --> Router Class Initialized
INFO - 26.06.2025 11:27:11 --> Output Class Initialized
INFO - 26.06.2025 11:27:11 --> Security Class Initialized
DEBUG - 26.06.2025 11:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:27:11 --> Input Class Initialized
INFO - 26.06.2025 11:27:11 --> Language Class Initialized
INFO - 26.06.2025 11:27:11 --> Loader Class Initialized
INFO - 26.06.2025 11:27:11 --> Helper loaded: app_helper
INFO - 26.06.2025 11:27:11 --> Helper loaded: language_helper
INFO - 26.06.2025 11:27:11 --> Helper loaded: text_helper
INFO - 26.06.2025 11:27:11 --> Helper loaded: string_helper
INFO - 26.06.2025 11:27:11 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:27:11 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:27:11 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:27:11 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:27:11 --> Email Class Initialized
INFO - 26.06.2025 11:27:11 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:27:11 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:27:11 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:11 --> Helper loaded: date_helper
INFO - 26.06.2025 11:27:11 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:27:11 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:11 --> Helper loaded: form_helper
INFO - 26.06.2025 11:27:11 --> Form Validation Class Initialized
INFO - 26.06.2025 11:27:11 --> Upload Class Initialized
INFO - 26.06.2025 11:27:11 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:27:11 --> Pagination Class Initialized
INFO - 26.06.2025 11:27:11 --> Controller Class Initialized
INFO - 26.06.2025 11:27:11 --> Model "Article_model" initialized
INFO - 26.06.2025 11:27:11 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:27:11 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:27:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:27:11 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <p><br></p>
        )

    [section_image_titles] => Array
        (
            [0] => 
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => 
        )

    [button_names] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:27:11 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <p><br></p>
            [image] => uploads/articles/sections/herr_styx3.jpg
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:27:11 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <p><br></p>
        )

    [section_image_titles] => Array
        (
            [0] => 
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => 
        )

    [button_names] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <p><br></p>
                    [image] => uploads/articles/sections/herr_styx3.jpg
                    [image_title] => 
                    [button_name] => 
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:27:11 --> Using existing image: 
DEBUG - 26.06.2025 11:27:11 --> Updated is_main for other articles in category 89
DEBUG - 26.06.2025 11:27:11 --> Database save successful for article ID: 46
DEBUG - 26.06.2025 11:27:11 --> Processing section image upload for index 0: herr_styx.jpg
INFO - 26.06.2025 11:27:11 --> Image Lib Class Initialized
ERROR - 26.06.2025 11:27:11 --> Severity: error --> Exception: file_exists(): Argument #1 ($filename) must be of type string, array given C:\Users\assist15\Desktop\project\STYX_web\application\models\Article_model.php 339
INFO - 26.06.2025 11:27:15 --> Config Class Initialized
INFO - 26.06.2025 11:27:15 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:27:15 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:27:15 --> Utf8 Class Initialized
INFO - 26.06.2025 11:27:15 --> URI Class Initialized
INFO - 26.06.2025 11:27:15 --> Router Class Initialized
INFO - 26.06.2025 11:27:15 --> Output Class Initialized
INFO - 26.06.2025 11:27:15 --> Security Class Initialized
DEBUG - 26.06.2025 11:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:27:15 --> Input Class Initialized
INFO - 26.06.2025 11:27:15 --> Language Class Initialized
INFO - 26.06.2025 11:27:15 --> Loader Class Initialized
INFO - 26.06.2025 11:27:15 --> Helper loaded: app_helper
INFO - 26.06.2025 11:27:15 --> Helper loaded: language_helper
INFO - 26.06.2025 11:27:15 --> Helper loaded: text_helper
INFO - 26.06.2025 11:27:15 --> Helper loaded: string_helper
INFO - 26.06.2025 11:27:15 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:27:15 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:27:15 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:27:15 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:27:15 --> Email Class Initialized
INFO - 26.06.2025 11:27:15 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:27:15 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:27:15 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:15 --> Helper loaded: date_helper
INFO - 26.06.2025 11:27:15 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:27:15 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:15 --> Helper loaded: form_helper
INFO - 26.06.2025 11:27:15 --> Form Validation Class Initialized
INFO - 26.06.2025 11:27:15 --> Upload Class Initialized
INFO - 26.06.2025 11:27:15 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:27:15 --> Pagination Class Initialized
INFO - 26.06.2025 11:27:15 --> Controller Class Initialized
INFO - 26.06.2025 11:27:15 --> Model "Article_model" initialized
INFO - 26.06.2025 11:27:15 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:27:15 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:27:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:27:15 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:27:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:27:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:27:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:27:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:27:15 --> Final output sent to browser
DEBUG - 26.06.2025 11:27:15 --> Total execution time: 0.5023
INFO - 26.06.2025 11:27:17 --> Config Class Initialized
INFO - 26.06.2025 11:27:17 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:27:17 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:27:17 --> Utf8 Class Initialized
INFO - 26.06.2025 11:27:17 --> URI Class Initialized
INFO - 26.06.2025 11:27:17 --> Router Class Initialized
INFO - 26.06.2025 11:27:17 --> Output Class Initialized
INFO - 26.06.2025 11:27:17 --> Security Class Initialized
DEBUG - 26.06.2025 11:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:27:17 --> Input Class Initialized
INFO - 26.06.2025 11:27:17 --> Language Class Initialized
INFO - 26.06.2025 11:27:17 --> Loader Class Initialized
INFO - 26.06.2025 11:27:17 --> Helper loaded: app_helper
INFO - 26.06.2025 11:27:17 --> Helper loaded: language_helper
INFO - 26.06.2025 11:27:17 --> Helper loaded: text_helper
INFO - 26.06.2025 11:27:17 --> Helper loaded: string_helper
INFO - 26.06.2025 11:27:17 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:27:17 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:27:17 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:27:17 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:27:17 --> Email Class Initialized
INFO - 26.06.2025 11:27:17 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:27:17 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:27:17 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:27:17 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:17 --> Helper loaded: date_helper
INFO - 26.06.2025 11:27:17 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:27:17 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:17 --> Helper loaded: form_helper
INFO - 26.06.2025 11:27:17 --> Form Validation Class Initialized
INFO - 26.06.2025 11:27:17 --> Upload Class Initialized
INFO - 26.06.2025 11:27:17 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:27:17 --> Pagination Class Initialized
INFO - 26.06.2025 11:27:17 --> Controller Class Initialized
INFO - 26.06.2025 11:27:17 --> Model "Article_model" initialized
INFO - 26.06.2025 11:27:17 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:27:17 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:17 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:27:17 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:27:17 --> Final output sent to browser
DEBUG - 26.06.2025 11:27:17 --> Total execution time: 0.4042
INFO - 26.06.2025 11:27:19 --> Config Class Initialized
INFO - 26.06.2025 11:27:19 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:27:19 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:27:19 --> Utf8 Class Initialized
INFO - 26.06.2025 11:27:19 --> URI Class Initialized
INFO - 26.06.2025 11:27:19 --> Router Class Initialized
INFO - 26.06.2025 11:27:19 --> Output Class Initialized
INFO - 26.06.2025 11:27:19 --> Security Class Initialized
DEBUG - 26.06.2025 11:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:27:19 --> Input Class Initialized
INFO - 26.06.2025 11:27:19 --> Language Class Initialized
INFO - 26.06.2025 11:27:19 --> Loader Class Initialized
INFO - 26.06.2025 11:27:19 --> Helper loaded: app_helper
INFO - 26.06.2025 11:27:19 --> Helper loaded: language_helper
INFO - 26.06.2025 11:27:19 --> Helper loaded: text_helper
INFO - 26.06.2025 11:27:19 --> Helper loaded: string_helper
INFO - 26.06.2025 11:27:19 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:27:19 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:27:19 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:27:19 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:27:19 --> Email Class Initialized
INFO - 26.06.2025 11:27:19 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:27:19 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:27:19 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:19 --> Helper loaded: date_helper
INFO - 26.06.2025 11:27:19 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:27:19 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:19 --> Helper loaded: form_helper
INFO - 26.06.2025 11:27:19 --> Form Validation Class Initialized
INFO - 26.06.2025 11:27:19 --> Upload Class Initialized
INFO - 26.06.2025 11:27:19 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:27:19 --> Pagination Class Initialized
INFO - 26.06.2025 11:27:19 --> Controller Class Initialized
INFO - 26.06.2025 11:27:19 --> Model "Article_model" initialized
INFO - 26.06.2025 11:27:19 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:27:19 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:19 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:27:19 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:27:19 --> Final output sent to browser
DEBUG - 26.06.2025 11:27:19 --> Total execution time: 0.4107
INFO - 26.06.2025 11:27:20 --> Config Class Initialized
INFO - 26.06.2025 11:27:20 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:27:20 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:27:20 --> Utf8 Class Initialized
INFO - 26.06.2025 11:27:20 --> URI Class Initialized
INFO - 26.06.2025 11:27:20 --> Router Class Initialized
INFO - 26.06.2025 11:27:20 --> Output Class Initialized
INFO - 26.06.2025 11:27:20 --> Security Class Initialized
DEBUG - 26.06.2025 11:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:27:20 --> Input Class Initialized
INFO - 26.06.2025 11:27:20 --> Language Class Initialized
INFO - 26.06.2025 11:27:20 --> Loader Class Initialized
INFO - 26.06.2025 11:27:20 --> Helper loaded: app_helper
INFO - 26.06.2025 11:27:20 --> Helper loaded: language_helper
INFO - 26.06.2025 11:27:20 --> Helper loaded: text_helper
INFO - 26.06.2025 11:27:20 --> Helper loaded: string_helper
INFO - 26.06.2025 11:27:20 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:27:20 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:27:20 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:27:20 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:27:20 --> Email Class Initialized
INFO - 26.06.2025 11:27:20 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:27:20 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:27:20 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:27:20 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:20 --> Helper loaded: date_helper
INFO - 26.06.2025 11:27:20 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:27:20 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:20 --> Helper loaded: form_helper
INFO - 26.06.2025 11:27:20 --> Form Validation Class Initialized
INFO - 26.06.2025 11:27:20 --> Upload Class Initialized
INFO - 26.06.2025 11:27:20 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:27:20 --> Pagination Class Initialized
INFO - 26.06.2025 11:27:20 --> Controller Class Initialized
INFO - 26.06.2025 11:27:20 --> Model "Article_model" initialized
INFO - 26.06.2025 11:27:20 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:27:20 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:20 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:27:20 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:27:20 --> Final output sent to browser
DEBUG - 26.06.2025 11:27:20 --> Total execution time: 0.3972
INFO - 26.06.2025 11:27:21 --> Config Class Initialized
INFO - 26.06.2025 11:27:21 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:27:21 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:27:21 --> Utf8 Class Initialized
INFO - 26.06.2025 11:27:21 --> URI Class Initialized
INFO - 26.06.2025 11:27:21 --> Router Class Initialized
INFO - 26.06.2025 11:27:21 --> Output Class Initialized
INFO - 26.06.2025 11:27:21 --> Security Class Initialized
DEBUG - 26.06.2025 11:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:27:21 --> Input Class Initialized
INFO - 26.06.2025 11:27:21 --> Language Class Initialized
INFO - 26.06.2025 11:27:21 --> Loader Class Initialized
INFO - 26.06.2025 11:27:21 --> Helper loaded: app_helper
INFO - 26.06.2025 11:27:21 --> Helper loaded: language_helper
INFO - 26.06.2025 11:27:21 --> Helper loaded: text_helper
INFO - 26.06.2025 11:27:21 --> Helper loaded: string_helper
INFO - 26.06.2025 11:27:21 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:27:21 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:27:21 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:27:21 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:27:21 --> Email Class Initialized
INFO - 26.06.2025 11:27:21 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:27:21 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:27:21 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:21 --> Helper loaded: date_helper
INFO - 26.06.2025 11:27:21 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:27:21 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:27:21 --> Helper loaded: form_helper
INFO - 26.06.2025 11:27:21 --> Form Validation Class Initialized
INFO - 26.06.2025 11:27:21 --> Upload Class Initialized
INFO - 26.06.2025 11:27:21 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:27:21 --> Pagination Class Initialized
INFO - 26.06.2025 11:27:21 --> Controller Class Initialized
INFO - 26.06.2025 11:27:21 --> Model "Article_model" initialized
INFO - 26.06.2025 11:27:21 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:27:21 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:27:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:27:21 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:27:21 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:27:21 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:27:21 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:27:21 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:27:21 --> Final output sent to browser
DEBUG - 26.06.2025 11:27:21 --> Total execution time: 0.4731
INFO - 26.06.2025 11:28:17 --> Config Class Initialized
INFO - 26.06.2025 11:28:17 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:28:17 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:28:17 --> Utf8 Class Initialized
INFO - 26.06.2025 11:28:17 --> URI Class Initialized
INFO - 26.06.2025 11:28:17 --> Router Class Initialized
INFO - 26.06.2025 11:28:17 --> Output Class Initialized
INFO - 26.06.2025 11:28:17 --> Security Class Initialized
DEBUG - 26.06.2025 11:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:28:17 --> Input Class Initialized
INFO - 26.06.2025 11:28:17 --> Language Class Initialized
INFO - 26.06.2025 11:28:17 --> Loader Class Initialized
INFO - 26.06.2025 11:28:17 --> Helper loaded: app_helper
INFO - 26.06.2025 11:28:17 --> Helper loaded: language_helper
INFO - 26.06.2025 11:28:17 --> Helper loaded: text_helper
INFO - 26.06.2025 11:28:17 --> Helper loaded: string_helper
INFO - 26.06.2025 11:28:17 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:28:17 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:28:17 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:28:18 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:28:18 --> Email Class Initialized
INFO - 26.06.2025 11:28:18 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:28:18 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:28:18 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:28:18 --> Helper loaded: date_helper
INFO - 26.06.2025 11:28:18 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:28:18 --> Helper loaded: form_helper
INFO - 26.06.2025 11:28:18 --> Form Validation Class Initialized
INFO - 26.06.2025 11:28:18 --> Upload Class Initialized
INFO - 26.06.2025 11:28:18 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:28:18 --> Pagination Class Initialized
INFO - 26.06.2025 11:28:18 --> Controller Class Initialized
INFO - 26.06.2025 11:28:18 --> Model "Article_model" initialized
INFO - 26.06.2025 11:28:18 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:28:18 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:28:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:28:18 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 933
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von </span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich </span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a> </span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""> und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => http://localhost/STYX_web/de/aktuelles/crowdinvesting
            [external_url] => 
        )

)

INFO - 26.06.2025 11:28:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:28:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:28:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:28:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:28:18 --> Final output sent to browser
DEBUG - 26.06.2025 11:28:18 --> Total execution time: 0.4649
INFO - 26.06.2025 11:28:18 --> Config Class Initialized
INFO - 26.06.2025 11:28:18 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:28:18 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:28:18 --> Utf8 Class Initialized
INFO - 26.06.2025 11:28:18 --> URI Class Initialized
INFO - 26.06.2025 11:28:18 --> Router Class Initialized
INFO - 26.06.2025 11:28:18 --> Output Class Initialized
INFO - 26.06.2025 11:28:18 --> Security Class Initialized
DEBUG - 26.06.2025 11:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:28:18 --> Input Class Initialized
INFO - 26.06.2025 11:28:18 --> Language Class Initialized
INFO - 26.06.2025 11:28:18 --> Loader Class Initialized
INFO - 26.06.2025 11:28:18 --> Helper loaded: app_helper
INFO - 26.06.2025 11:28:18 --> Helper loaded: language_helper
INFO - 26.06.2025 11:28:18 --> Helper loaded: text_helper
INFO - 26.06.2025 11:28:18 --> Helper loaded: string_helper
INFO - 26.06.2025 11:28:18 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:28:18 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:28:18 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:28:18 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:28:18 --> Email Class Initialized
INFO - 26.06.2025 11:28:18 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:28:18 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:28:18 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:28:18 --> Helper loaded: date_helper
INFO - 26.06.2025 11:28:18 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:28:18 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:28:18 --> Helper loaded: form_helper
INFO - 26.06.2025 11:28:18 --> Form Validation Class Initialized
INFO - 26.06.2025 11:28:18 --> Upload Class Initialized
INFO - 26.06.2025 11:28:18 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:28:18 --> Pagination Class Initialized
INFO - 26.06.2025 11:28:18 --> Controller Class Initialized
INFO - 26.06.2025 11:28:18 --> Model "App_model" initialized
INFO - 26.06.2025 11:28:18 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:28:18 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
ERROR - 26.06.2025 11:28:18 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:28:18 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:28:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:28:18 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:28:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:28:18 --> Final output sent to browser
DEBUG - 26.06.2025 11:28:18 --> Total execution time: 0.4644
INFO - 26.06.2025 11:30:02 --> Config Class Initialized
INFO - 26.06.2025 11:30:02 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:30:02 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:30:02 --> Utf8 Class Initialized
INFO - 26.06.2025 11:30:02 --> URI Class Initialized
INFO - 26.06.2025 11:30:02 --> Router Class Initialized
INFO - 26.06.2025 11:30:02 --> Output Class Initialized
INFO - 26.06.2025 11:30:02 --> Security Class Initialized
DEBUG - 26.06.2025 11:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:30:02 --> Input Class Initialized
INFO - 26.06.2025 11:30:02 --> Language Class Initialized
INFO - 26.06.2025 11:30:02 --> Loader Class Initialized
INFO - 26.06.2025 11:30:02 --> Helper loaded: app_helper
INFO - 26.06.2025 11:30:02 --> Helper loaded: language_helper
INFO - 26.06.2025 11:30:02 --> Helper loaded: text_helper
INFO - 26.06.2025 11:30:02 --> Helper loaded: string_helper
INFO - 26.06.2025 11:30:02 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:30:02 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:30:02 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:30:02 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:30:02 --> Email Class Initialized
INFO - 26.06.2025 11:30:02 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:30:02 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:30:02 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:30:02 --> Helper loaded: date_helper
INFO - 26.06.2025 11:30:02 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:30:02 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:30:02 --> Helper loaded: form_helper
INFO - 26.06.2025 11:30:02 --> Form Validation Class Initialized
INFO - 26.06.2025 11:30:02 --> Upload Class Initialized
INFO - 26.06.2025 11:30:02 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:30:02 --> Pagination Class Initialized
INFO - 26.06.2025 11:30:02 --> Controller Class Initialized
INFO - 26.06.2025 11:30:02 --> Model "Article_model" initialized
INFO - 26.06.2025 11:30:02 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:30:02 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:30:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:30:02 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:30:02 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/herr_styx4.jpg
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:30:02 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => uploads/articles/sections/herr_styx4.jpg
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:30:02 --> Using existing image: 
DEBUG - 26.06.2025 11:30:02 --> Updated is_main for other articles in category 89
DEBUG - 26.06.2025 11:30:02 --> Database save successful for article ID: 46
DEBUG - 26.06.2025 11:30:02 --> Processing section image upload for index 0: herr_styx.jpg
INFO - 26.06.2025 11:30:02 --> Image Lib Class Initialized
ERROR - 26.06.2025 11:30:02 --> Severity: error --> Exception: file_exists(): Argument #1 ($filename) must be of type string, array given C:\Users\assist15\Desktop\project\STYX_web\application\models\Article_model.php 339
INFO - 26.06.2025 11:30:06 --> Config Class Initialized
INFO - 26.06.2025 11:30:06 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:30:06 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:30:06 --> Utf8 Class Initialized
INFO - 26.06.2025 11:30:06 --> URI Class Initialized
INFO - 26.06.2025 11:30:06 --> Router Class Initialized
INFO - 26.06.2025 11:30:06 --> Output Class Initialized
INFO - 26.06.2025 11:30:06 --> Security Class Initialized
DEBUG - 26.06.2025 11:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:30:06 --> Input Class Initialized
INFO - 26.06.2025 11:30:06 --> Language Class Initialized
INFO - 26.06.2025 11:30:06 --> Loader Class Initialized
INFO - 26.06.2025 11:30:06 --> Helper loaded: app_helper
INFO - 26.06.2025 11:30:06 --> Helper loaded: language_helper
INFO - 26.06.2025 11:30:06 --> Helper loaded: text_helper
INFO - 26.06.2025 11:30:06 --> Helper loaded: string_helper
INFO - 26.06.2025 11:30:06 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:30:06 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:30:06 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:30:06 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:30:06 --> Email Class Initialized
INFO - 26.06.2025 11:30:06 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:30:06 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:30:06 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:30:06 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:30:06 --> Helper loaded: date_helper
INFO - 26.06.2025 11:30:06 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:30:06 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:30:06 --> Helper loaded: form_helper
INFO - 26.06.2025 11:30:06 --> Form Validation Class Initialized
INFO - 26.06.2025 11:30:06 --> Upload Class Initialized
INFO - 26.06.2025 11:30:06 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:30:06 --> Pagination Class Initialized
INFO - 26.06.2025 11:30:06 --> Controller Class Initialized
INFO - 26.06.2025 11:30:06 --> Model "Article_model" initialized
INFO - 26.06.2025 11:30:06 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:30:06 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:30:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:30:06 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:30:06 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:30:06 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:30:06 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:30:06 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:30:06 --> Final output sent to browser
DEBUG - 26.06.2025 11:30:06 --> Total execution time: 0.4733
INFO - 26.06.2025 11:30:09 --> Config Class Initialized
INFO - 26.06.2025 11:30:09 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:30:09 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:30:09 --> Utf8 Class Initialized
INFO - 26.06.2025 11:30:09 --> URI Class Initialized
INFO - 26.06.2025 11:30:09 --> Router Class Initialized
INFO - 26.06.2025 11:30:09 --> Output Class Initialized
INFO - 26.06.2025 11:30:09 --> Security Class Initialized
DEBUG - 26.06.2025 11:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:30:09 --> Input Class Initialized
INFO - 26.06.2025 11:30:09 --> Language Class Initialized
INFO - 26.06.2025 11:30:09 --> Loader Class Initialized
INFO - 26.06.2025 11:30:09 --> Helper loaded: app_helper
INFO - 26.06.2025 11:30:09 --> Helper loaded: language_helper
INFO - 26.06.2025 11:30:09 --> Helper loaded: text_helper
INFO - 26.06.2025 11:30:09 --> Helper loaded: string_helper
INFO - 26.06.2025 11:30:09 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:30:09 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:30:09 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:30:09 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:30:09 --> Email Class Initialized
INFO - 26.06.2025 11:30:09 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:30:09 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:30:09 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:30:09 --> Helper loaded: date_helper
INFO - 26.06.2025 11:30:09 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:30:09 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:30:09 --> Helper loaded: form_helper
INFO - 26.06.2025 11:30:09 --> Form Validation Class Initialized
INFO - 26.06.2025 11:30:09 --> Upload Class Initialized
INFO - 26.06.2025 11:30:09 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:30:09 --> Pagination Class Initialized
INFO - 26.06.2025 11:30:09 --> Controller Class Initialized
INFO - 26.06.2025 11:30:09 --> Model "Article_model" initialized
INFO - 26.06.2025 11:30:09 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:30:09 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:30:09 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:30:09 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:30:09 --> Final output sent to browser
DEBUG - 26.06.2025 11:30:09 --> Total execution time: 0.3812
INFO - 26.06.2025 11:33:04 --> Config Class Initialized
INFO - 26.06.2025 11:33:04 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:33:04 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:33:04 --> Utf8 Class Initialized
INFO - 26.06.2025 11:33:04 --> URI Class Initialized
INFO - 26.06.2025 11:33:04 --> Router Class Initialized
INFO - 26.06.2025 11:33:04 --> Output Class Initialized
INFO - 26.06.2025 11:33:04 --> Security Class Initialized
DEBUG - 26.06.2025 11:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:33:04 --> Input Class Initialized
INFO - 26.06.2025 11:33:04 --> Language Class Initialized
INFO - 26.06.2025 11:33:04 --> Loader Class Initialized
INFO - 26.06.2025 11:33:04 --> Helper loaded: app_helper
INFO - 26.06.2025 11:33:04 --> Helper loaded: language_helper
INFO - 26.06.2025 11:33:04 --> Helper loaded: text_helper
INFO - 26.06.2025 11:33:04 --> Helper loaded: string_helper
INFO - 26.06.2025 11:33:04 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:33:04 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:33:04 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:33:04 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:33:04 --> Email Class Initialized
INFO - 26.06.2025 11:33:04 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:33:04 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:33:04 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:04 --> Helper loaded: date_helper
INFO - 26.06.2025 11:33:04 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:04 --> Helper loaded: form_helper
INFO - 26.06.2025 11:33:04 --> Form Validation Class Initialized
INFO - 26.06.2025 11:33:04 --> Upload Class Initialized
INFO - 26.06.2025 11:33:04 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:33:04 --> Pagination Class Initialized
INFO - 26.06.2025 11:33:04 --> Controller Class Initialized
INFO - 26.06.2025 11:33:04 --> Model "Article_model" initialized
INFO - 26.06.2025 11:33:04 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:33:04 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:33:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:33:04 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:33:05 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:33:05 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:33:05 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:33:05 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:33:05 --> Final output sent to browser
DEBUG - 26.06.2025 11:33:05 --> Total execution time: 0.5283
INFO - 26.06.2025 11:33:10 --> Config Class Initialized
INFO - 26.06.2025 11:33:10 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:33:10 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:33:10 --> Utf8 Class Initialized
INFO - 26.06.2025 11:33:10 --> URI Class Initialized
INFO - 26.06.2025 11:33:10 --> Router Class Initialized
INFO - 26.06.2025 11:33:10 --> Output Class Initialized
INFO - 26.06.2025 11:33:10 --> Security Class Initialized
DEBUG - 26.06.2025 11:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:33:10 --> Input Class Initialized
INFO - 26.06.2025 11:33:10 --> Language Class Initialized
INFO - 26.06.2025 11:33:10 --> Loader Class Initialized
INFO - 26.06.2025 11:33:10 --> Helper loaded: app_helper
INFO - 26.06.2025 11:33:10 --> Helper loaded: language_helper
INFO - 26.06.2025 11:33:10 --> Helper loaded: text_helper
INFO - 26.06.2025 11:33:10 --> Helper loaded: string_helper
INFO - 26.06.2025 11:33:10 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:33:10 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:33:10 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:33:10 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:33:10 --> Email Class Initialized
INFO - 26.06.2025 11:33:10 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:33:10 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:33:10 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:33:10 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:10 --> Helper loaded: date_helper
INFO - 26.06.2025 11:33:10 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:33:10 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:10 --> Helper loaded: form_helper
INFO - 26.06.2025 11:33:10 --> Form Validation Class Initialized
INFO - 26.06.2025 11:33:10 --> Upload Class Initialized
INFO - 26.06.2025 11:33:10 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:33:10 --> Pagination Class Initialized
INFO - 26.06.2025 11:33:10 --> Controller Class Initialized
INFO - 26.06.2025 11:33:10 --> Model "Article_model" initialized
INFO - 26.06.2025 11:33:10 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:33:10 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:33:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:33:10 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <p><br></p>
        )

    [section_image_titles] => Array
        (
            [0] => 
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => 
        )

    [button_names] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:33:11 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <p><br></p>
            [image] => uploads/articles/sections/herr_styx5.jpg
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:33:11 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <p><br></p>
        )

    [section_image_titles] => Array
        (
            [0] => 
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => 
        )

    [button_names] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <p><br></p>
                    [image] => uploads/articles/sections/herr_styx5.jpg
                    [image_title] => 
                    [button_name] => 
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:33:11 --> Using existing image: 
DEBUG - 26.06.2025 11:33:11 --> Updated is_main for other articles in category 89
DEBUG - 26.06.2025 11:33:11 --> Database save successful for article ID: 46
DEBUG - 26.06.2025 11:33:11 --> Processing section image upload for index 0: herr_styx.jpg
INFO - 26.06.2025 11:33:11 --> Image Lib Class Initialized
ERROR - 26.06.2025 11:33:11 --> Severity: error --> Exception: file_exists(): Argument #1 ($filename) must be of type string, array given C:\Users\assist15\Desktop\project\STYX_web\application\models\Article_model.php 339
INFO - 26.06.2025 11:33:12 --> Config Class Initialized
INFO - 26.06.2025 11:33:12 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:33:12 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:33:12 --> Utf8 Class Initialized
INFO - 26.06.2025 11:33:12 --> URI Class Initialized
INFO - 26.06.2025 11:33:12 --> Router Class Initialized
INFO - 26.06.2025 11:33:12 --> Output Class Initialized
INFO - 26.06.2025 11:33:12 --> Security Class Initialized
DEBUG - 26.06.2025 11:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:33:12 --> Input Class Initialized
INFO - 26.06.2025 11:33:12 --> Language Class Initialized
INFO - 26.06.2025 11:33:12 --> Loader Class Initialized
INFO - 26.06.2025 11:33:12 --> Helper loaded: app_helper
INFO - 26.06.2025 11:33:12 --> Helper loaded: language_helper
INFO - 26.06.2025 11:33:12 --> Helper loaded: text_helper
INFO - 26.06.2025 11:33:12 --> Helper loaded: string_helper
INFO - 26.06.2025 11:33:12 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:33:12 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:33:12 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:33:12 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:33:12 --> Email Class Initialized
INFO - 26.06.2025 11:33:12 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:33:12 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:33:12 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:12 --> Helper loaded: date_helper
INFO - 26.06.2025 11:33:12 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:33:12 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:12 --> Helper loaded: form_helper
INFO - 26.06.2025 11:33:12 --> Form Validation Class Initialized
INFO - 26.06.2025 11:33:12 --> Upload Class Initialized
INFO - 26.06.2025 11:33:12 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:33:12 --> Pagination Class Initialized
INFO - 26.06.2025 11:33:12 --> Controller Class Initialized
INFO - 26.06.2025 11:33:12 --> Model "Article_model" initialized
INFO - 26.06.2025 11:33:12 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:33:12 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:33:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:33:12 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:33:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:33:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:33:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:33:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:33:12 --> Final output sent to browser
DEBUG - 26.06.2025 11:33:12 --> Total execution time: 0.4794
INFO - 26.06.2025 11:33:45 --> Config Class Initialized
INFO - 26.06.2025 11:33:45 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:33:45 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:33:45 --> Utf8 Class Initialized
INFO - 26.06.2025 11:33:45 --> URI Class Initialized
INFO - 26.06.2025 11:33:45 --> Router Class Initialized
INFO - 26.06.2025 11:33:45 --> Output Class Initialized
INFO - 26.06.2025 11:33:45 --> Security Class Initialized
DEBUG - 26.06.2025 11:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:33:45 --> Input Class Initialized
INFO - 26.06.2025 11:33:45 --> Language Class Initialized
INFO - 26.06.2025 11:33:45 --> Loader Class Initialized
INFO - 26.06.2025 11:33:45 --> Helper loaded: app_helper
INFO - 26.06.2025 11:33:45 --> Helper loaded: language_helper
INFO - 26.06.2025 11:33:45 --> Helper loaded: text_helper
INFO - 26.06.2025 11:33:45 --> Helper loaded: string_helper
INFO - 26.06.2025 11:33:45 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:33:45 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:33:45 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:33:45 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:33:45 --> Email Class Initialized
INFO - 26.06.2025 11:33:45 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:33:45 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:33:45 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:45 --> Helper loaded: date_helper
INFO - 26.06.2025 11:33:45 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:33:45 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:45 --> Helper loaded: form_helper
INFO - 26.06.2025 11:33:45 --> Form Validation Class Initialized
INFO - 26.06.2025 11:33:45 --> Upload Class Initialized
INFO - 26.06.2025 11:33:45 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:33:45 --> Pagination Class Initialized
INFO - 26.06.2025 11:33:45 --> Controller Class Initialized
INFO - 26.06.2025 11:33:45 --> Model "Article_model" initialized
INFO - 26.06.2025 11:33:45 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:33:45 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:33:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:33:46 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 933
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von </span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich </span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a> </span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""> und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => http://localhost/STYX_web/de/aktuelles/crowdinvesting
            [external_url] => 
        )

)

INFO - 26.06.2025 11:33:46 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:33:46 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:33:46 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:33:46 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:33:46 --> Final output sent to browser
DEBUG - 26.06.2025 11:33:46 --> Total execution time: 0.4680
INFO - 26.06.2025 11:33:46 --> Config Class Initialized
INFO - 26.06.2025 11:33:46 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:33:46 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:33:46 --> Utf8 Class Initialized
INFO - 26.06.2025 11:33:46 --> URI Class Initialized
INFO - 26.06.2025 11:33:46 --> Router Class Initialized
INFO - 26.06.2025 11:33:46 --> Output Class Initialized
INFO - 26.06.2025 11:33:46 --> Security Class Initialized
DEBUG - 26.06.2025 11:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:33:46 --> Input Class Initialized
INFO - 26.06.2025 11:33:46 --> Language Class Initialized
INFO - 26.06.2025 11:33:46 --> Loader Class Initialized
INFO - 26.06.2025 11:33:46 --> Helper loaded: app_helper
INFO - 26.06.2025 11:33:46 --> Helper loaded: language_helper
INFO - 26.06.2025 11:33:46 --> Helper loaded: text_helper
INFO - 26.06.2025 11:33:46 --> Helper loaded: string_helper
INFO - 26.06.2025 11:33:46 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:33:46 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:33:46 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:33:46 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:33:46 --> Email Class Initialized
INFO - 26.06.2025 11:33:46 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:33:46 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:33:46 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:33:46 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:46 --> Helper loaded: date_helper
INFO - 26.06.2025 11:33:46 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:33:46 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:46 --> Helper loaded: form_helper
INFO - 26.06.2025 11:33:46 --> Form Validation Class Initialized
INFO - 26.06.2025 11:33:46 --> Upload Class Initialized
INFO - 26.06.2025 11:33:46 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:33:46 --> Pagination Class Initialized
INFO - 26.06.2025 11:33:46 --> Controller Class Initialized
INFO - 26.06.2025 11:33:46 --> Model "App_model" initialized
INFO - 26.06.2025 11:33:46 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:33:46 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
ERROR - 26.06.2025 11:33:46 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:33:46 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:33:46 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:33:46 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:33:46 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:33:46 --> Final output sent to browser
DEBUG - 26.06.2025 11:33:46 --> Total execution time: 0.4782
INFO - 26.06.2025 11:33:57 --> Config Class Initialized
INFO - 26.06.2025 11:33:57 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:33:57 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:33:57 --> Utf8 Class Initialized
INFO - 26.06.2025 11:33:57 --> URI Class Initialized
INFO - 26.06.2025 11:33:57 --> Router Class Initialized
INFO - 26.06.2025 11:33:57 --> Output Class Initialized
INFO - 26.06.2025 11:33:57 --> Security Class Initialized
DEBUG - 26.06.2025 11:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:33:57 --> Input Class Initialized
INFO - 26.06.2025 11:33:57 --> Language Class Initialized
INFO - 26.06.2025 11:33:57 --> Loader Class Initialized
INFO - 26.06.2025 11:33:57 --> Helper loaded: app_helper
INFO - 26.06.2025 11:33:57 --> Helper loaded: language_helper
INFO - 26.06.2025 11:33:57 --> Helper loaded: text_helper
INFO - 26.06.2025 11:33:57 --> Helper loaded: string_helper
INFO - 26.06.2025 11:33:57 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:33:57 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:33:57 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:33:57 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:33:57 --> Email Class Initialized
INFO - 26.06.2025 11:33:57 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:33:57 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:33:57 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:57 --> Helper loaded: date_helper
INFO - 26.06.2025 11:33:57 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:33:57 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:57 --> Helper loaded: form_helper
INFO - 26.06.2025 11:33:57 --> Form Validation Class Initialized
INFO - 26.06.2025 11:33:57 --> Upload Class Initialized
INFO - 26.06.2025 11:33:57 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:33:57 --> Pagination Class Initialized
INFO - 26.06.2025 11:33:57 --> Controller Class Initialized
INFO - 26.06.2025 11:33:57 --> Model "Article_model" initialized
INFO - 26.06.2025 11:33:57 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:33:57 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:33:57 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:33:57 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:33:57 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/herr_styx6.jpg
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:33:57 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => uploads/articles/sections/herr_styx6.jpg
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:33:57 --> Using existing image: 
DEBUG - 26.06.2025 11:33:57 --> Updated is_main for other articles in category 89
DEBUG - 26.06.2025 11:33:57 --> Database save successful for article ID: 46
DEBUG - 26.06.2025 11:33:57 --> Processing section image upload for index 0: herr_styx.jpg
INFO - 26.06.2025 11:33:57 --> Image Lib Class Initialized
ERROR - 26.06.2025 11:33:57 --> Severity: error --> Exception: file_exists(): Argument #1 ($filename) must be of type string, array given C:\Users\assist15\Desktop\project\STYX_web\application\models\Article_model.php 339
INFO - 26.06.2025 11:33:59 --> Config Class Initialized
INFO - 26.06.2025 11:33:59 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:33:59 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:33:59 --> Utf8 Class Initialized
INFO - 26.06.2025 11:33:59 --> URI Class Initialized
INFO - 26.06.2025 11:33:59 --> Router Class Initialized
INFO - 26.06.2025 11:33:59 --> Output Class Initialized
INFO - 26.06.2025 11:33:59 --> Security Class Initialized
DEBUG - 26.06.2025 11:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:33:59 --> Input Class Initialized
INFO - 26.06.2025 11:33:59 --> Language Class Initialized
INFO - 26.06.2025 11:33:59 --> Loader Class Initialized
INFO - 26.06.2025 11:33:59 --> Helper loaded: app_helper
INFO - 26.06.2025 11:33:59 --> Helper loaded: language_helper
INFO - 26.06.2025 11:33:59 --> Helper loaded: text_helper
INFO - 26.06.2025 11:33:59 --> Helper loaded: string_helper
INFO - 26.06.2025 11:33:59 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:33:59 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:33:59 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:33:59 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:33:59 --> Email Class Initialized
INFO - 26.06.2025 11:33:59 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:33:59 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:33:59 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:33:59 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:59 --> Helper loaded: date_helper
INFO - 26.06.2025 11:33:59 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:33:59 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:33:59 --> Helper loaded: form_helper
INFO - 26.06.2025 11:33:59 --> Form Validation Class Initialized
INFO - 26.06.2025 11:33:59 --> Upload Class Initialized
INFO - 26.06.2025 11:33:59 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:33:59 --> Pagination Class Initialized
INFO - 26.06.2025 11:33:59 --> Controller Class Initialized
INFO - 26.06.2025 11:33:59 --> Model "Article_model" initialized
INFO - 26.06.2025 11:33:59 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:33:59 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:33:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:33:59 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:33:59 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:33:59 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:33:59 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:33:59 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:33:59 --> Final output sent to browser
DEBUG - 26.06.2025 11:33:59 --> Total execution time: 0.4586
INFO - 26.06.2025 11:34:00 --> Config Class Initialized
INFO - 26.06.2025 11:34:00 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:34:00 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:34:00 --> Utf8 Class Initialized
INFO - 26.06.2025 11:34:00 --> URI Class Initialized
INFO - 26.06.2025 11:34:00 --> Router Class Initialized
INFO - 26.06.2025 11:34:00 --> Output Class Initialized
INFO - 26.06.2025 11:34:00 --> Security Class Initialized
DEBUG - 26.06.2025 11:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:34:00 --> Input Class Initialized
INFO - 26.06.2025 11:34:00 --> Language Class Initialized
INFO - 26.06.2025 11:34:00 --> Loader Class Initialized
INFO - 26.06.2025 11:34:00 --> Helper loaded: app_helper
INFO - 26.06.2025 11:34:00 --> Helper loaded: language_helper
INFO - 26.06.2025 11:34:00 --> Helper loaded: text_helper
INFO - 26.06.2025 11:34:00 --> Helper loaded: string_helper
INFO - 26.06.2025 11:34:00 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:34:00 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:34:00 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:34:00 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:34:00 --> Email Class Initialized
INFO - 26.06.2025 11:34:00 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:34:00 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:34:00 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:34:00 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:00 --> Helper loaded: date_helper
INFO - 26.06.2025 11:34:00 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:34:00 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:00 --> Helper loaded: form_helper
INFO - 26.06.2025 11:34:00 --> Form Validation Class Initialized
INFO - 26.06.2025 11:34:00 --> Upload Class Initialized
INFO - 26.06.2025 11:34:00 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:34:00 --> Pagination Class Initialized
INFO - 26.06.2025 11:34:00 --> Controller Class Initialized
INFO - 26.06.2025 11:34:00 --> Model "Article_model" initialized
INFO - 26.06.2025 11:34:00 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:34:00 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:00 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:34:00 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:34:00 --> Final output sent to browser
DEBUG - 26.06.2025 11:34:00 --> Total execution time: 0.3782
INFO - 26.06.2025 11:34:01 --> Config Class Initialized
INFO - 26.06.2025 11:34:01 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:34:01 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:34:01 --> Utf8 Class Initialized
INFO - 26.06.2025 11:34:01 --> URI Class Initialized
INFO - 26.06.2025 11:34:01 --> Router Class Initialized
INFO - 26.06.2025 11:34:01 --> Output Class Initialized
INFO - 26.06.2025 11:34:01 --> Security Class Initialized
DEBUG - 26.06.2025 11:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:34:01 --> Input Class Initialized
INFO - 26.06.2025 11:34:01 --> Language Class Initialized
INFO - 26.06.2025 11:34:01 --> Loader Class Initialized
INFO - 26.06.2025 11:34:01 --> Helper loaded: app_helper
INFO - 26.06.2025 11:34:01 --> Helper loaded: language_helper
INFO - 26.06.2025 11:34:01 --> Helper loaded: text_helper
INFO - 26.06.2025 11:34:01 --> Helper loaded: string_helper
INFO - 26.06.2025 11:34:01 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:34:01 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:34:01 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:34:01 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:34:01 --> Email Class Initialized
INFO - 26.06.2025 11:34:01 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:34:01 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:34:01 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:01 --> Helper loaded: date_helper
INFO - 26.06.2025 11:34:01 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:34:01 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:01 --> Helper loaded: form_helper
INFO - 26.06.2025 11:34:01 --> Form Validation Class Initialized
INFO - 26.06.2025 11:34:01 --> Upload Class Initialized
INFO - 26.06.2025 11:34:01 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:34:01 --> Pagination Class Initialized
INFO - 26.06.2025 11:34:01 --> Controller Class Initialized
INFO - 26.06.2025 11:34:01 --> Model "Article_model" initialized
INFO - 26.06.2025 11:34:01 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:34:02 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:34:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:34:02 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:34:02 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:34:02 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:34:02 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:34:02 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:34:02 --> Final output sent to browser
DEBUG - 26.06.2025 11:34:02 --> Total execution time: 0.4887
INFO - 26.06.2025 11:34:04 --> Config Class Initialized
INFO - 26.06.2025 11:34:04 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:34:04 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:34:04 --> Utf8 Class Initialized
INFO - 26.06.2025 11:34:04 --> URI Class Initialized
INFO - 26.06.2025 11:34:04 --> Router Class Initialized
INFO - 26.06.2025 11:34:04 --> Output Class Initialized
INFO - 26.06.2025 11:34:04 --> Security Class Initialized
DEBUG - 26.06.2025 11:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:34:04 --> Input Class Initialized
INFO - 26.06.2025 11:34:04 --> Language Class Initialized
INFO - 26.06.2025 11:34:04 --> Loader Class Initialized
INFO - 26.06.2025 11:34:04 --> Helper loaded: app_helper
INFO - 26.06.2025 11:34:04 --> Helper loaded: language_helper
INFO - 26.06.2025 11:34:04 --> Helper loaded: text_helper
INFO - 26.06.2025 11:34:04 --> Helper loaded: string_helper
INFO - 26.06.2025 11:34:04 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:34:04 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:34:04 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:34:04 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:34:04 --> Email Class Initialized
INFO - 26.06.2025 11:34:04 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:34:04 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:34:04 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:34:04 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:04 --> Helper loaded: date_helper
INFO - 26.06.2025 11:34:04 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:34:04 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:04 --> Helper loaded: form_helper
INFO - 26.06.2025 11:34:04 --> Form Validation Class Initialized
INFO - 26.06.2025 11:34:04 --> Upload Class Initialized
INFO - 26.06.2025 11:34:04 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:34:04 --> Pagination Class Initialized
INFO - 26.06.2025 11:34:04 --> Controller Class Initialized
INFO - 26.06.2025 11:34:04 --> Model "Article_model" initialized
INFO - 26.06.2025 11:34:04 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:34:04 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:05 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:34:05 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:34:05 --> Final output sent to browser
DEBUG - 26.06.2025 11:34:05 --> Total execution time: 0.4190
INFO - 26.06.2025 11:34:05 --> Config Class Initialized
INFO - 26.06.2025 11:34:05 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:34:05 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:34:05 --> Utf8 Class Initialized
INFO - 26.06.2025 11:34:05 --> URI Class Initialized
INFO - 26.06.2025 11:34:05 --> Router Class Initialized
INFO - 26.06.2025 11:34:05 --> Output Class Initialized
INFO - 26.06.2025 11:34:05 --> Security Class Initialized
DEBUG - 26.06.2025 11:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:34:05 --> Input Class Initialized
INFO - 26.06.2025 11:34:05 --> Language Class Initialized
INFO - 26.06.2025 11:34:05 --> Loader Class Initialized
INFO - 26.06.2025 11:34:05 --> Helper loaded: app_helper
INFO - 26.06.2025 11:34:05 --> Helper loaded: language_helper
INFO - 26.06.2025 11:34:05 --> Helper loaded: text_helper
INFO - 26.06.2025 11:34:05 --> Helper loaded: string_helper
INFO - 26.06.2025 11:34:05 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:34:05 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:34:05 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:34:05 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:34:05 --> Email Class Initialized
INFO - 26.06.2025 11:34:05 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:34:05 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:34:05 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:34:05 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:05 --> Helper loaded: date_helper
INFO - 26.06.2025 11:34:05 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:34:05 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:05 --> Helper loaded: form_helper
INFO - 26.06.2025 11:34:05 --> Form Validation Class Initialized
INFO - 26.06.2025 11:34:05 --> Upload Class Initialized
INFO - 26.06.2025 11:34:05 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:34:05 --> Pagination Class Initialized
INFO - 26.06.2025 11:34:05 --> Controller Class Initialized
INFO - 26.06.2025 11:34:05 --> Model "Article_model" initialized
INFO - 26.06.2025 11:34:05 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:34:05 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:34:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:34:06 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:34:06 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:34:06 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:34:06 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:34:06 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:34:06 --> Final output sent to browser
DEBUG - 26.06.2025 11:34:06 --> Total execution time: 0.4690
INFO - 26.06.2025 11:34:13 --> Config Class Initialized
INFO - 26.06.2025 11:34:13 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:34:13 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:34:13 --> Utf8 Class Initialized
INFO - 26.06.2025 11:34:13 --> URI Class Initialized
INFO - 26.06.2025 11:34:13 --> Router Class Initialized
INFO - 26.06.2025 11:34:13 --> Output Class Initialized
INFO - 26.06.2025 11:34:13 --> Security Class Initialized
DEBUG - 26.06.2025 11:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:34:13 --> Input Class Initialized
INFO - 26.06.2025 11:34:13 --> Language Class Initialized
INFO - 26.06.2025 11:34:13 --> Loader Class Initialized
INFO - 26.06.2025 11:34:13 --> Helper loaded: app_helper
INFO - 26.06.2025 11:34:13 --> Helper loaded: language_helper
INFO - 26.06.2025 11:34:13 --> Helper loaded: text_helper
INFO - 26.06.2025 11:34:13 --> Helper loaded: string_helper
INFO - 26.06.2025 11:34:13 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:34:13 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:34:13 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:34:13 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:34:13 --> Email Class Initialized
INFO - 26.06.2025 11:34:13 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:34:13 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:34:13 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:13 --> Helper loaded: date_helper
INFO - 26.06.2025 11:34:13 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:34:13 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:13 --> Helper loaded: form_helper
INFO - 26.06.2025 11:34:13 --> Form Validation Class Initialized
INFO - 26.06.2025 11:34:13 --> Upload Class Initialized
INFO - 26.06.2025 11:34:13 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:34:13 --> Pagination Class Initialized
INFO - 26.06.2025 11:34:13 --> Controller Class Initialized
INFO - 26.06.2025 11:34:13 --> Model "Article_model" initialized
INFO - 26.06.2025 11:34:13 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:34:14 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:34:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:34:14 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:34:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:34:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:34:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:34:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:34:14 --> Final output sent to browser
DEBUG - 26.06.2025 11:34:14 --> Total execution time: 0.4657
INFO - 26.06.2025 11:34:16 --> Config Class Initialized
INFO - 26.06.2025 11:34:16 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:34:16 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:34:16 --> Utf8 Class Initialized
INFO - 26.06.2025 11:34:16 --> URI Class Initialized
INFO - 26.06.2025 11:34:16 --> Router Class Initialized
INFO - 26.06.2025 11:34:16 --> Output Class Initialized
INFO - 26.06.2025 11:34:16 --> Security Class Initialized
DEBUG - 26.06.2025 11:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:34:16 --> Input Class Initialized
INFO - 26.06.2025 11:34:16 --> Language Class Initialized
INFO - 26.06.2025 11:34:16 --> Loader Class Initialized
INFO - 26.06.2025 11:34:16 --> Helper loaded: app_helper
INFO - 26.06.2025 11:34:16 --> Helper loaded: language_helper
INFO - 26.06.2025 11:34:16 --> Helper loaded: text_helper
INFO - 26.06.2025 11:34:16 --> Helper loaded: string_helper
INFO - 26.06.2025 11:34:16 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:34:16 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:34:16 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:34:16 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:34:16 --> Email Class Initialized
INFO - 26.06.2025 11:34:16 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:34:16 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:34:16 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:16 --> Helper loaded: date_helper
INFO - 26.06.2025 11:34:16 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:34:16 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:16 --> Helper loaded: form_helper
INFO - 26.06.2025 11:34:16 --> Form Validation Class Initialized
INFO - 26.06.2025 11:34:16 --> Upload Class Initialized
INFO - 26.06.2025 11:34:16 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:34:16 --> Pagination Class Initialized
INFO - 26.06.2025 11:34:16 --> Controller Class Initialized
INFO - 26.06.2025 11:34:16 --> Model "Article_model" initialized
INFO - 26.06.2025 11:34:16 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:34:16 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:16 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:34:16 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:34:16 --> Final output sent to browser
DEBUG - 26.06.2025 11:34:16 --> Total execution time: 0.3904
INFO - 26.06.2025 11:34:18 --> Config Class Initialized
INFO - 26.06.2025 11:34:18 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:34:18 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:34:18 --> Utf8 Class Initialized
INFO - 26.06.2025 11:34:18 --> URI Class Initialized
INFO - 26.06.2025 11:34:18 --> Router Class Initialized
INFO - 26.06.2025 11:34:18 --> Output Class Initialized
INFO - 26.06.2025 11:34:18 --> Security Class Initialized
DEBUG - 26.06.2025 11:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:34:18 --> Input Class Initialized
INFO - 26.06.2025 11:34:18 --> Language Class Initialized
INFO - 26.06.2025 11:34:18 --> Loader Class Initialized
INFO - 26.06.2025 11:34:18 --> Helper loaded: app_helper
INFO - 26.06.2025 11:34:18 --> Helper loaded: language_helper
INFO - 26.06.2025 11:34:18 --> Helper loaded: text_helper
INFO - 26.06.2025 11:34:18 --> Helper loaded: string_helper
INFO - 26.06.2025 11:34:18 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:34:18 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:34:18 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:34:18 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:34:18 --> Email Class Initialized
INFO - 26.06.2025 11:34:18 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:34:18 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:34:18 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:34:18 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:18 --> Helper loaded: date_helper
INFO - 26.06.2025 11:34:18 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:34:18 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:18 --> Helper loaded: form_helper
INFO - 26.06.2025 11:34:18 --> Form Validation Class Initialized
INFO - 26.06.2025 11:34:18 --> Upload Class Initialized
INFO - 26.06.2025 11:34:18 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:34:18 --> Pagination Class Initialized
INFO - 26.06.2025 11:34:18 --> Controller Class Initialized
INFO - 26.06.2025 11:34:18 --> Model "Article_model" initialized
INFO - 26.06.2025 11:34:18 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:34:18 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:34:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:34:18 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:34:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:34:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:34:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:34:18 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:34:18 --> Final output sent to browser
DEBUG - 26.06.2025 11:34:18 --> Total execution time: 0.4814
INFO - 26.06.2025 11:34:25 --> Config Class Initialized
INFO - 26.06.2025 11:34:25 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:34:25 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:34:25 --> Utf8 Class Initialized
INFO - 26.06.2025 11:34:25 --> URI Class Initialized
INFO - 26.06.2025 11:34:25 --> Router Class Initialized
INFO - 26.06.2025 11:34:25 --> Output Class Initialized
INFO - 26.06.2025 11:34:25 --> Security Class Initialized
DEBUG - 26.06.2025 11:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:34:25 --> Input Class Initialized
INFO - 26.06.2025 11:34:25 --> Language Class Initialized
INFO - 26.06.2025 11:34:25 --> Loader Class Initialized
INFO - 26.06.2025 11:34:25 --> Helper loaded: app_helper
INFO - 26.06.2025 11:34:25 --> Helper loaded: language_helper
INFO - 26.06.2025 11:34:25 --> Helper loaded: text_helper
INFO - 26.06.2025 11:34:25 --> Helper loaded: string_helper
INFO - 26.06.2025 11:34:25 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:34:25 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:34:25 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:34:25 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:34:25 --> Email Class Initialized
INFO - 26.06.2025 11:34:25 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:34:25 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:34:25 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:34:25 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:25 --> Helper loaded: date_helper
INFO - 26.06.2025 11:34:25 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:34:25 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:25 --> Helper loaded: form_helper
INFO - 26.06.2025 11:34:25 --> Form Validation Class Initialized
INFO - 26.06.2025 11:34:25 --> Upload Class Initialized
INFO - 26.06.2025 11:34:25 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:34:25 --> Pagination Class Initialized
INFO - 26.06.2025 11:34:25 --> Controller Class Initialized
INFO - 26.06.2025 11:34:25 --> Model "Article_model" initialized
INFO - 26.06.2025 11:34:25 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:34:25 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:34:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:34:25 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <p><br></p>
        )

    [section_image_titles] => Array
        (
            [0] => 
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => 
        )

    [button_names] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:34:25 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <p><br></p>
            [image] => uploads/articles/sections/herr_styx.jpg
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

)

ERROR - 26.06.2025 11:34:25 --> Severity: error --> Exception: Unknown column 'thumb_image' in 'field list' C:\Users\assist15\Desktop\project\STYX_web\system\database\drivers\mysqli\mysqli_driver.php 307
INFO - 26.06.2025 11:34:26 --> Config Class Initialized
INFO - 26.06.2025 11:34:26 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:34:26 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:34:26 --> Utf8 Class Initialized
INFO - 26.06.2025 11:34:26 --> URI Class Initialized
INFO - 26.06.2025 11:34:26 --> Router Class Initialized
INFO - 26.06.2025 11:34:26 --> Output Class Initialized
INFO - 26.06.2025 11:34:26 --> Security Class Initialized
DEBUG - 26.06.2025 11:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:34:26 --> Input Class Initialized
INFO - 26.06.2025 11:34:26 --> Language Class Initialized
INFO - 26.06.2025 11:34:26 --> Loader Class Initialized
INFO - 26.06.2025 11:34:26 --> Helper loaded: app_helper
INFO - 26.06.2025 11:34:26 --> Helper loaded: language_helper
INFO - 26.06.2025 11:34:26 --> Helper loaded: text_helper
INFO - 26.06.2025 11:34:26 --> Helper loaded: string_helper
INFO - 26.06.2025 11:34:26 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:34:26 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:34:26 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:34:27 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:34:27 --> Email Class Initialized
INFO - 26.06.2025 11:34:27 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:34:27 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:34:27 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:34:27 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:27 --> Helper loaded: date_helper
INFO - 26.06.2025 11:34:27 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:34:27 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:27 --> Helper loaded: form_helper
INFO - 26.06.2025 11:34:27 --> Form Validation Class Initialized
INFO - 26.06.2025 11:34:27 --> Upload Class Initialized
INFO - 26.06.2025 11:34:27 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:34:27 --> Pagination Class Initialized
INFO - 26.06.2025 11:34:27 --> Controller Class Initialized
INFO - 26.06.2025 11:34:27 --> Model "Article_model" initialized
INFO - 26.06.2025 11:34:27 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:34:27 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:34:27 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:34:27 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:34:27 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:34:27 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:34:27 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:34:27 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:34:27 --> Final output sent to browser
DEBUG - 26.06.2025 11:34:27 --> Total execution time: 0.4721
INFO - 26.06.2025 11:34:29 --> Config Class Initialized
INFO - 26.06.2025 11:34:29 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:34:29 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:34:29 --> Utf8 Class Initialized
INFO - 26.06.2025 11:34:29 --> URI Class Initialized
INFO - 26.06.2025 11:34:29 --> Router Class Initialized
INFO - 26.06.2025 11:34:29 --> Output Class Initialized
INFO - 26.06.2025 11:34:29 --> Security Class Initialized
DEBUG - 26.06.2025 11:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:34:29 --> Input Class Initialized
INFO - 26.06.2025 11:34:29 --> Language Class Initialized
INFO - 26.06.2025 11:34:29 --> Loader Class Initialized
INFO - 26.06.2025 11:34:29 --> Helper loaded: app_helper
INFO - 26.06.2025 11:34:29 --> Helper loaded: language_helper
INFO - 26.06.2025 11:34:29 --> Helper loaded: text_helper
INFO - 26.06.2025 11:34:29 --> Helper loaded: string_helper
INFO - 26.06.2025 11:34:29 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:34:29 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:34:29 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:34:29 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:34:29 --> Email Class Initialized
INFO - 26.06.2025 11:34:29 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:34:29 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:34:29 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:34:29 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:29 --> Helper loaded: date_helper
INFO - 26.06.2025 11:34:29 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:34:29 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:29 --> Helper loaded: form_helper
INFO - 26.06.2025 11:34:29 --> Form Validation Class Initialized
INFO - 26.06.2025 11:34:29 --> Upload Class Initialized
INFO - 26.06.2025 11:34:29 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:34:29 --> Pagination Class Initialized
INFO - 26.06.2025 11:34:29 --> Controller Class Initialized
INFO - 26.06.2025 11:34:29 --> Model "Article_model" initialized
INFO - 26.06.2025 11:34:29 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:34:29 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:34:29 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:34:29 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:34:29 --> Final output sent to browser
DEBUG - 26.06.2025 11:34:29 --> Total execution time: 0.3887
INFO - 26.06.2025 11:38:19 --> Config Class Initialized
INFO - 26.06.2025 11:38:19 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:38:19 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:38:19 --> Utf8 Class Initialized
INFO - 26.06.2025 11:38:19 --> URI Class Initialized
INFO - 26.06.2025 11:38:19 --> Router Class Initialized
INFO - 26.06.2025 11:38:19 --> Output Class Initialized
INFO - 26.06.2025 11:38:19 --> Security Class Initialized
DEBUG - 26.06.2025 11:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:38:19 --> Input Class Initialized
INFO - 26.06.2025 11:38:19 --> Language Class Initialized
INFO - 26.06.2025 11:38:19 --> Loader Class Initialized
INFO - 26.06.2025 11:38:19 --> Helper loaded: app_helper
INFO - 26.06.2025 11:38:19 --> Helper loaded: language_helper
INFO - 26.06.2025 11:38:19 --> Helper loaded: text_helper
INFO - 26.06.2025 11:38:19 --> Helper loaded: string_helper
INFO - 26.06.2025 11:38:19 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:38:19 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:38:19 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:38:19 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:38:19 --> Email Class Initialized
INFO - 26.06.2025 11:38:19 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:38:19 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:38:19 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:38:19 --> Helper loaded: date_helper
INFO - 26.06.2025 11:38:19 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:38:19 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:38:19 --> Helper loaded: form_helper
INFO - 26.06.2025 11:38:19 --> Form Validation Class Initialized
INFO - 26.06.2025 11:38:19 --> Upload Class Initialized
INFO - 26.06.2025 11:38:19 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:38:19 --> Pagination Class Initialized
INFO - 26.06.2025 11:38:19 --> Controller Class Initialized
INFO - 26.06.2025 11:38:19 --> Model "Article_model" initialized
INFO - 26.06.2025 11:38:19 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:38:19 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:38:19 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:38:19 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:38:19 --> Final output sent to browser
DEBUG - 26.06.2025 11:38:19 --> Total execution time: 0.4132
INFO - 26.06.2025 11:38:20 --> Config Class Initialized
INFO - 26.06.2025 11:38:20 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:38:20 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:38:20 --> Utf8 Class Initialized
INFO - 26.06.2025 11:38:20 --> URI Class Initialized
INFO - 26.06.2025 11:38:20 --> Router Class Initialized
INFO - 26.06.2025 11:38:20 --> Output Class Initialized
INFO - 26.06.2025 11:38:20 --> Security Class Initialized
DEBUG - 26.06.2025 11:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:38:20 --> Input Class Initialized
INFO - 26.06.2025 11:38:20 --> Language Class Initialized
INFO - 26.06.2025 11:38:20 --> Loader Class Initialized
INFO - 26.06.2025 11:38:20 --> Helper loaded: app_helper
INFO - 26.06.2025 11:38:20 --> Helper loaded: language_helper
INFO - 26.06.2025 11:38:20 --> Helper loaded: text_helper
INFO - 26.06.2025 11:38:20 --> Helper loaded: string_helper
INFO - 26.06.2025 11:38:20 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:38:20 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:38:20 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:38:20 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:38:20 --> Email Class Initialized
INFO - 26.06.2025 11:38:20 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:38:20 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:38:20 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:38:20 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:38:20 --> Helper loaded: date_helper
INFO - 26.06.2025 11:38:20 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:38:20 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:38:20 --> Helper loaded: form_helper
INFO - 26.06.2025 11:38:20 --> Form Validation Class Initialized
INFO - 26.06.2025 11:38:20 --> Upload Class Initialized
INFO - 26.06.2025 11:38:20 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:38:20 --> Pagination Class Initialized
INFO - 26.06.2025 11:38:20 --> Controller Class Initialized
INFO - 26.06.2025 11:38:20 --> Model "Article_model" initialized
INFO - 26.06.2025 11:38:20 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:38:20 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:38:20 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:38:20 --> Fetched sections for article 46: Array
(
)

INFO - 26.06.2025 11:38:20 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:38:20 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:38:20 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:38:20 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:38:21 --> Final output sent to browser
DEBUG - 26.06.2025 11:38:21 --> Total execution time: 0.4787
INFO - 26.06.2025 11:38:41 --> Config Class Initialized
INFO - 26.06.2025 11:38:41 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:38:41 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:38:41 --> Utf8 Class Initialized
INFO - 26.06.2025 11:38:41 --> URI Class Initialized
INFO - 26.06.2025 11:38:41 --> Router Class Initialized
INFO - 26.06.2025 11:38:41 --> Output Class Initialized
INFO - 26.06.2025 11:38:41 --> Security Class Initialized
DEBUG - 26.06.2025 11:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:38:41 --> Input Class Initialized
INFO - 26.06.2025 11:38:41 --> Language Class Initialized
INFO - 26.06.2025 11:38:41 --> Loader Class Initialized
INFO - 26.06.2025 11:38:41 --> Helper loaded: app_helper
INFO - 26.06.2025 11:38:42 --> Helper loaded: language_helper
INFO - 26.06.2025 11:38:42 --> Helper loaded: text_helper
INFO - 26.06.2025 11:38:42 --> Helper loaded: string_helper
INFO - 26.06.2025 11:38:42 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:38:42 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:38:42 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:38:42 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:38:42 --> Email Class Initialized
INFO - 26.06.2025 11:38:42 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:38:42 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:38:42 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:38:42 --> Helper loaded: date_helper
INFO - 26.06.2025 11:38:42 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:38:42 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:38:42 --> Helper loaded: form_helper
INFO - 26.06.2025 11:38:42 --> Form Validation Class Initialized
INFO - 26.06.2025 11:38:42 --> Upload Class Initialized
INFO - 26.06.2025 11:38:42 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:38:42 --> Pagination Class Initialized
INFO - 26.06.2025 11:38:42 --> Controller Class Initialized
INFO - 26.06.2025 11:38:42 --> Model "Article_model" initialized
INFO - 26.06.2025 11:38:42 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:38:42 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:38:42 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:38:42 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:38:42 --> Final output sent to browser
DEBUG - 26.06.2025 11:38:42 --> Total execution time: 0.5656
INFO - 26.06.2025 11:39:01 --> Config Class Initialized
INFO - 26.06.2025 11:39:01 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:39:01 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:39:01 --> Utf8 Class Initialized
INFO - 26.06.2025 11:39:01 --> URI Class Initialized
INFO - 26.06.2025 11:39:01 --> Router Class Initialized
INFO - 26.06.2025 11:39:01 --> Output Class Initialized
INFO - 26.06.2025 11:39:01 --> Security Class Initialized
DEBUG - 26.06.2025 11:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:39:01 --> Input Class Initialized
INFO - 26.06.2025 11:39:01 --> Language Class Initialized
INFO - 26.06.2025 11:39:01 --> Loader Class Initialized
INFO - 26.06.2025 11:39:01 --> Helper loaded: app_helper
INFO - 26.06.2025 11:39:01 --> Helper loaded: language_helper
INFO - 26.06.2025 11:39:01 --> Helper loaded: text_helper
INFO - 26.06.2025 11:39:01 --> Helper loaded: string_helper
INFO - 26.06.2025 11:39:01 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:39:01 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:39:01 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:39:02 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:39:02 --> Email Class Initialized
INFO - 26.06.2025 11:39:02 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:39:02 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:39:02 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:39:02 --> Helper loaded: date_helper
INFO - 26.06.2025 11:39:02 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:39:02 --> Helper loaded: form_helper
INFO - 26.06.2025 11:39:02 --> Form Validation Class Initialized
INFO - 26.06.2025 11:39:02 --> Upload Class Initialized
INFO - 26.06.2025 11:39:02 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:39:02 --> Pagination Class Initialized
INFO - 26.06.2025 11:39:02 --> Controller Class Initialized
INFO - 26.06.2025 11:39:02 --> Model "Article_model" initialized
INFO - 26.06.2025 11:39:02 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:39:02 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:39:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:39:02 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 933
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von </span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich </span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a> </span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""> und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => http://localhost/STYX_web/de/aktuelles/crowdinvesting
            [external_url] => 
        )

)

INFO - 26.06.2025 11:39:02 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:39:02 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:39:02 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:39:02 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:39:02 --> Final output sent to browser
DEBUG - 26.06.2025 11:39:02 --> Total execution time: 0.5267
INFO - 26.06.2025 11:39:02 --> Config Class Initialized
INFO - 26.06.2025 11:39:02 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:39:02 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:39:02 --> Utf8 Class Initialized
INFO - 26.06.2025 11:39:02 --> URI Class Initialized
INFO - 26.06.2025 11:39:02 --> Router Class Initialized
INFO - 26.06.2025 11:39:02 --> Output Class Initialized
INFO - 26.06.2025 11:39:02 --> Security Class Initialized
DEBUG - 26.06.2025 11:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:39:02 --> Input Class Initialized
INFO - 26.06.2025 11:39:02 --> Language Class Initialized
INFO - 26.06.2025 11:39:02 --> Loader Class Initialized
INFO - 26.06.2025 11:39:02 --> Helper loaded: app_helper
INFO - 26.06.2025 11:39:02 --> Helper loaded: language_helper
INFO - 26.06.2025 11:39:02 --> Helper loaded: text_helper
INFO - 26.06.2025 11:39:02 --> Helper loaded: string_helper
INFO - 26.06.2025 11:39:02 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:39:02 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:39:02 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:39:02 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:39:02 --> Email Class Initialized
INFO - 26.06.2025 11:39:02 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:39:02 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:39:02 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:39:02 --> Helper loaded: date_helper
INFO - 26.06.2025 11:39:02 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:39:02 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:39:02 --> Helper loaded: form_helper
INFO - 26.06.2025 11:39:02 --> Form Validation Class Initialized
INFO - 26.06.2025 11:39:02 --> Upload Class Initialized
INFO - 26.06.2025 11:39:02 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:39:02 --> Pagination Class Initialized
INFO - 26.06.2025 11:39:02 --> Controller Class Initialized
INFO - 26.06.2025 11:39:02 --> Model "App_model" initialized
INFO - 26.06.2025 11:39:02 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:39:02 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
ERROR - 26.06.2025 11:39:02 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:39:02 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:39:03 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:39:03 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:39:03 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:39:03 --> Final output sent to browser
DEBUG - 26.06.2025 11:39:03 --> Total execution time: 0.5616
INFO - 26.06.2025 11:39:07 --> Config Class Initialized
INFO - 26.06.2025 11:39:07 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:39:07 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:39:07 --> Utf8 Class Initialized
INFO - 26.06.2025 11:39:07 --> URI Class Initialized
INFO - 26.06.2025 11:39:07 --> Router Class Initialized
INFO - 26.06.2025 11:39:07 --> Output Class Initialized
INFO - 26.06.2025 11:39:07 --> Security Class Initialized
DEBUG - 26.06.2025 11:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:39:07 --> Input Class Initialized
INFO - 26.06.2025 11:39:07 --> Language Class Initialized
INFO - 26.06.2025 11:39:07 --> Loader Class Initialized
INFO - 26.06.2025 11:39:07 --> Helper loaded: app_helper
INFO - 26.06.2025 11:39:07 --> Helper loaded: language_helper
INFO - 26.06.2025 11:39:07 --> Helper loaded: text_helper
INFO - 26.06.2025 11:39:07 --> Helper loaded: string_helper
INFO - 26.06.2025 11:39:07 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:39:07 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:39:07 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:39:07 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:39:07 --> Email Class Initialized
INFO - 26.06.2025 11:39:07 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:39:07 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:39:07 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:39:07 --> Helper loaded: date_helper
INFO - 26.06.2025 11:39:07 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:39:07 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:39:07 --> Helper loaded: form_helper
INFO - 26.06.2025 11:39:07 --> Form Validation Class Initialized
INFO - 26.06.2025 11:39:07 --> Upload Class Initialized
INFO - 26.06.2025 11:39:07 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:39:07 --> Pagination Class Initialized
INFO - 26.06.2025 11:39:07 --> Controller Class Initialized
INFO - 26.06.2025 11:39:07 --> Model "Article_model" initialized
INFO - 26.06.2025 11:39:07 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:39:07 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:39:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:39:07 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:39:07 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/herr_styx.jpg
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:39:07 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/Stix-Wolfgang-NEU-rgb.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => uploads/articles/sections/herr_styx.jpg
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

        )

)

INFO - 26.06.2025 11:39:07 --> Image Lib Class Initialized
DEBUG - 26.06.2025 11:39:07 --> Inserting section 0: Array
(
    [article_id] => 46
    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
    [image] => uploads/articles/sections/ueber-styx_section_0_1750937947.jpg
    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
    [button_name] => lokfff
    [subpage] => 
    [external_url] => 
    [order] => 0
)

INFO - 26.06.2025 11:39:07 --> Config Class Initialized
INFO - 26.06.2025 11:39:07 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:39:07 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:39:07 --> Utf8 Class Initialized
INFO - 26.06.2025 11:39:07 --> URI Class Initialized
INFO - 26.06.2025 11:39:07 --> Router Class Initialized
INFO - 26.06.2025 11:39:07 --> Output Class Initialized
INFO - 26.06.2025 11:39:07 --> Security Class Initialized
DEBUG - 26.06.2025 11:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:39:07 --> Input Class Initialized
INFO - 26.06.2025 11:39:07 --> Language Class Initialized
INFO - 26.06.2025 11:39:07 --> Loader Class Initialized
INFO - 26.06.2025 11:39:07 --> Helper loaded: app_helper
INFO - 26.06.2025 11:39:07 --> Helper loaded: language_helper
INFO - 26.06.2025 11:39:07 --> Helper loaded: text_helper
INFO - 26.06.2025 11:39:07 --> Helper loaded: string_helper
INFO - 26.06.2025 11:39:07 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:39:07 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:39:07 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:39:08 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:39:08 --> Email Class Initialized
INFO - 26.06.2025 11:39:08 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:39:08 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:39:08 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:39:08 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:39:08 --> Helper loaded: date_helper
INFO - 26.06.2025 11:39:08 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:39:08 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:39:08 --> Helper loaded: form_helper
INFO - 26.06.2025 11:39:08 --> Form Validation Class Initialized
INFO - 26.06.2025 11:39:08 --> Upload Class Initialized
INFO - 26.06.2025 11:39:08 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:39:08 --> Pagination Class Initialized
INFO - 26.06.2025 11:39:08 --> Controller Class Initialized
INFO - 26.06.2025 11:39:08 --> Model "Article_model" initialized
INFO - 26.06.2025 11:39:08 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:39:08 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:39:08 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:39:08 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:39:08 --> Final output sent to browser
DEBUG - 26.06.2025 11:39:08 --> Total execution time: 0.4226
INFO - 26.06.2025 11:42:08 --> Config Class Initialized
INFO - 26.06.2025 11:42:08 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:42:08 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:42:08 --> Utf8 Class Initialized
INFO - 26.06.2025 11:42:08 --> URI Class Initialized
INFO - 26.06.2025 11:42:08 --> Router Class Initialized
INFO - 26.06.2025 11:42:08 --> Output Class Initialized
INFO - 26.06.2025 11:42:08 --> Security Class Initialized
DEBUG - 26.06.2025 11:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:42:08 --> Input Class Initialized
INFO - 26.06.2025 11:42:08 --> Language Class Initialized
INFO - 26.06.2025 11:42:08 --> Loader Class Initialized
INFO - 26.06.2025 11:42:08 --> Helper loaded: app_helper
INFO - 26.06.2025 11:42:08 --> Helper loaded: language_helper
INFO - 26.06.2025 11:42:08 --> Helper loaded: text_helper
INFO - 26.06.2025 11:42:08 --> Helper loaded: string_helper
INFO - 26.06.2025 11:42:08 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:42:08 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:42:08 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:42:08 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:42:08 --> Email Class Initialized
INFO - 26.06.2025 11:42:08 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:42:08 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:42:08 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:08 --> Helper loaded: date_helper
INFO - 26.06.2025 11:42:08 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:42:08 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:08 --> Helper loaded: form_helper
INFO - 26.06.2025 11:42:08 --> Form Validation Class Initialized
INFO - 26.06.2025 11:42:08 --> Upload Class Initialized
INFO - 26.06.2025 11:42:08 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:42:08 --> Pagination Class Initialized
INFO - 26.06.2025 11:42:08 --> Controller Class Initialized
INFO - 26.06.2025 11:42:08 --> Model "Article_model" initialized
INFO - 26.06.2025 11:42:08 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:42:08 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:08 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:42:08 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:42:08 --> Final output sent to browser
DEBUG - 26.06.2025 11:42:08 --> Total execution time: 0.4373
INFO - 26.06.2025 11:42:09 --> Config Class Initialized
INFO - 26.06.2025 11:42:09 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:42:09 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:42:09 --> Utf8 Class Initialized
INFO - 26.06.2025 11:42:09 --> URI Class Initialized
INFO - 26.06.2025 11:42:09 --> Router Class Initialized
INFO - 26.06.2025 11:42:09 --> Output Class Initialized
INFO - 26.06.2025 11:42:09 --> Security Class Initialized
DEBUG - 26.06.2025 11:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:42:09 --> Input Class Initialized
INFO - 26.06.2025 11:42:09 --> Language Class Initialized
INFO - 26.06.2025 11:42:09 --> Loader Class Initialized
INFO - 26.06.2025 11:42:09 --> Helper loaded: app_helper
INFO - 26.06.2025 11:42:09 --> Helper loaded: language_helper
INFO - 26.06.2025 11:42:09 --> Helper loaded: text_helper
INFO - 26.06.2025 11:42:09 --> Helper loaded: string_helper
INFO - 26.06.2025 11:42:09 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:42:09 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:42:09 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:42:10 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:42:10 --> Email Class Initialized
INFO - 26.06.2025 11:42:10 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:42:10 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:42:10 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:10 --> Helper loaded: date_helper
INFO - 26.06.2025 11:42:10 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:10 --> Helper loaded: form_helper
INFO - 26.06.2025 11:42:10 --> Form Validation Class Initialized
INFO - 26.06.2025 11:42:10 --> Upload Class Initialized
INFO - 26.06.2025 11:42:10 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:42:10 --> Pagination Class Initialized
INFO - 26.06.2025 11:42:10 --> Controller Class Initialized
INFO - 26.06.2025 11:42:10 --> Model "Article_model" initialized
INFO - 26.06.2025 11:42:10 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:42:10 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:42:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:42:10 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0_1750937947.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

)

INFO - 26.06.2025 11:42:10 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:42:10 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:42:10 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:42:10 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:42:10 --> Final output sent to browser
DEBUG - 26.06.2025 11:42:10 --> Total execution time: 0.4792
INFO - 26.06.2025 11:42:10 --> Config Class Initialized
INFO - 26.06.2025 11:42:10 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:42:10 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:42:10 --> Utf8 Class Initialized
INFO - 26.06.2025 11:42:10 --> URI Class Initialized
INFO - 26.06.2025 11:42:10 --> Router Class Initialized
INFO - 26.06.2025 11:42:10 --> Output Class Initialized
INFO - 26.06.2025 11:42:10 --> Security Class Initialized
DEBUG - 26.06.2025 11:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:42:10 --> Input Class Initialized
INFO - 26.06.2025 11:42:10 --> Language Class Initialized
INFO - 26.06.2025 11:42:10 --> Loader Class Initialized
INFO - 26.06.2025 11:42:10 --> Helper loaded: app_helper
INFO - 26.06.2025 11:42:10 --> Helper loaded: language_helper
INFO - 26.06.2025 11:42:10 --> Helper loaded: text_helper
INFO - 26.06.2025 11:42:10 --> Helper loaded: string_helper
INFO - 26.06.2025 11:42:10 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:42:10 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:42:10 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:42:10 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:42:10 --> Email Class Initialized
INFO - 26.06.2025 11:42:10 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:42:10 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:42:10 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:10 --> Helper loaded: date_helper
INFO - 26.06.2025 11:42:10 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:42:10 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:10 --> Helper loaded: form_helper
INFO - 26.06.2025 11:42:10 --> Form Validation Class Initialized
INFO - 26.06.2025 11:42:10 --> Upload Class Initialized
INFO - 26.06.2025 11:42:10 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:42:10 --> Pagination Class Initialized
INFO - 26.06.2025 11:42:10 --> Controller Class Initialized
INFO - 26.06.2025 11:42:10 --> Model "App_model" initialized
INFO - 26.06.2025 11:42:10 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:42:10 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/ueber-styx_section_0_1750937947.jpg
ERROR - 26.06.2025 11:42:10 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:42:10 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:42:10 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:42:10 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:42:11 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:42:11 --> Final output sent to browser
DEBUG - 26.06.2025 11:42:11 --> Total execution time: 0.5341
INFO - 26.06.2025 11:42:16 --> Config Class Initialized
INFO - 26.06.2025 11:42:16 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:42:16 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:42:16 --> Utf8 Class Initialized
INFO - 26.06.2025 11:42:16 --> URI Class Initialized
INFO - 26.06.2025 11:42:16 --> Router Class Initialized
INFO - 26.06.2025 11:42:16 --> Output Class Initialized
INFO - 26.06.2025 11:42:16 --> Security Class Initialized
DEBUG - 26.06.2025 11:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:42:16 --> Input Class Initialized
INFO - 26.06.2025 11:42:16 --> Language Class Initialized
INFO - 26.06.2025 11:42:16 --> Loader Class Initialized
INFO - 26.06.2025 11:42:16 --> Helper loaded: app_helper
INFO - 26.06.2025 11:42:16 --> Helper loaded: language_helper
INFO - 26.06.2025 11:42:16 --> Helper loaded: text_helper
INFO - 26.06.2025 11:42:16 --> Helper loaded: string_helper
INFO - 26.06.2025 11:42:16 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:42:16 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:42:16 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:42:16 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:42:16 --> Email Class Initialized
INFO - 26.06.2025 11:42:16 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:42:16 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:42:16 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:16 --> Helper loaded: date_helper
INFO - 26.06.2025 11:42:16 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:16 --> Helper loaded: form_helper
INFO - 26.06.2025 11:42:16 --> Form Validation Class Initialized
INFO - 26.06.2025 11:42:16 --> Upload Class Initialized
INFO - 26.06.2025 11:42:16 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:42:16 --> Pagination Class Initialized
INFO - 26.06.2025 11:42:16 --> Controller Class Initialized
INFO - 26.06.2025 11:42:16 --> Model "Article_model" initialized
INFO - 26.06.2025 11:42:16 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:42:16 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:42:16 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:42:16 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0_1750937947.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:42:16 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => 
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:42:16 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
        )

    [ftp_section_image] => Array
        (
            [0] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0_1750937947.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => 
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:42:16 --> Processing section image upload for index 0: herr_styx.jpg
INFO - 26.06.2025 11:42:16 --> Image Lib Class Initialized
DEBUG - 26.06.2025 11:42:16 --> Section image uploaded successfully for index 0: uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
DEBUG - 26.06.2025 11:42:16 --> Inserting section 0: Array
(
    [article_id] => 46
    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
    [image] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
    [button_name] => lokfff
    [subpage] => 
    [external_url] => 
    [order] => 0
)

INFO - 26.06.2025 11:42:16 --> Config Class Initialized
INFO - 26.06.2025 11:42:16 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:42:16 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:42:16 --> Utf8 Class Initialized
INFO - 26.06.2025 11:42:16 --> URI Class Initialized
INFO - 26.06.2025 11:42:16 --> Router Class Initialized
INFO - 26.06.2025 11:42:16 --> Output Class Initialized
INFO - 26.06.2025 11:42:16 --> Security Class Initialized
DEBUG - 26.06.2025 11:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:42:16 --> Input Class Initialized
INFO - 26.06.2025 11:42:16 --> Language Class Initialized
INFO - 26.06.2025 11:42:16 --> Loader Class Initialized
INFO - 26.06.2025 11:42:16 --> Helper loaded: app_helper
INFO - 26.06.2025 11:42:16 --> Helper loaded: language_helper
INFO - 26.06.2025 11:42:16 --> Helper loaded: text_helper
INFO - 26.06.2025 11:42:16 --> Helper loaded: string_helper
INFO - 26.06.2025 11:42:16 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:42:16 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:42:16 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:42:16 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:42:16 --> Email Class Initialized
INFO - 26.06.2025 11:42:16 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:42:16 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:42:16 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:16 --> Helper loaded: date_helper
INFO - 26.06.2025 11:42:16 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:42:16 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:16 --> Helper loaded: form_helper
INFO - 26.06.2025 11:42:16 --> Form Validation Class Initialized
INFO - 26.06.2025 11:42:16 --> Upload Class Initialized
INFO - 26.06.2025 11:42:16 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:42:16 --> Pagination Class Initialized
INFO - 26.06.2025 11:42:16 --> Controller Class Initialized
INFO - 26.06.2025 11:42:16 --> Model "Article_model" initialized
INFO - 26.06.2025 11:42:16 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:42:16 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:16 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:42:16 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:42:16 --> Final output sent to browser
DEBUG - 26.06.2025 11:42:16 --> Total execution time: 0.4098
INFO - 26.06.2025 11:42:36 --> Config Class Initialized
INFO - 26.06.2025 11:42:36 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:42:36 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:42:36 --> Utf8 Class Initialized
INFO - 26.06.2025 11:42:36 --> URI Class Initialized
INFO - 26.06.2025 11:42:36 --> Router Class Initialized
INFO - 26.06.2025 11:42:36 --> Output Class Initialized
INFO - 26.06.2025 11:42:36 --> Security Class Initialized
DEBUG - 26.06.2025 11:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:42:36 --> Input Class Initialized
INFO - 26.06.2025 11:42:36 --> Language Class Initialized
INFO - 26.06.2025 11:42:36 --> Loader Class Initialized
INFO - 26.06.2025 11:42:36 --> Helper loaded: app_helper
INFO - 26.06.2025 11:42:36 --> Helper loaded: language_helper
INFO - 26.06.2025 11:42:36 --> Helper loaded: text_helper
INFO - 26.06.2025 11:42:36 --> Helper loaded: string_helper
INFO - 26.06.2025 11:42:36 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:42:36 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:42:36 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:42:36 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:42:36 --> Email Class Initialized
INFO - 26.06.2025 11:42:36 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:42:36 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:42:36 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:36 --> Helper loaded: date_helper
INFO - 26.06.2025 11:42:36 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:42:36 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:36 --> Helper loaded: form_helper
INFO - 26.06.2025 11:42:36 --> Form Validation Class Initialized
INFO - 26.06.2025 11:42:36 --> Upload Class Initialized
INFO - 26.06.2025 11:42:36 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:42:36 --> Pagination Class Initialized
INFO - 26.06.2025 11:42:36 --> Controller Class Initialized
INFO - 26.06.2025 11:42:36 --> Model "Article_model" initialized
INFO - 26.06.2025 11:42:36 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:42:36 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:42:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:42:36 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

)

INFO - 26.06.2025 11:42:36 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:42:36 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:42:36 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:42:36 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:42:36 --> Final output sent to browser
DEBUG - 26.06.2025 11:42:36 --> Total execution time: 0.5090
INFO - 26.06.2025 11:42:45 --> Config Class Initialized
INFO - 26.06.2025 11:42:45 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:42:45 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:42:45 --> Utf8 Class Initialized
INFO - 26.06.2025 11:42:45 --> URI Class Initialized
INFO - 26.06.2025 11:42:45 --> Router Class Initialized
INFO - 26.06.2025 11:42:45 --> Output Class Initialized
INFO - 26.06.2025 11:42:45 --> Security Class Initialized
DEBUG - 26.06.2025 11:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:42:45 --> Input Class Initialized
INFO - 26.06.2025 11:42:45 --> Language Class Initialized
INFO - 26.06.2025 11:42:45 --> Loader Class Initialized
INFO - 26.06.2025 11:42:45 --> Helper loaded: app_helper
INFO - 26.06.2025 11:42:45 --> Helper loaded: language_helper
INFO - 26.06.2025 11:42:45 --> Helper loaded: text_helper
INFO - 26.06.2025 11:42:45 --> Helper loaded: string_helper
INFO - 26.06.2025 11:42:45 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:42:45 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:42:45 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:42:45 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:42:45 --> Email Class Initialized
INFO - 26.06.2025 11:42:45 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:42:45 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:42:45 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:45 --> Helper loaded: date_helper
INFO - 26.06.2025 11:42:45 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:42:45 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:42:45 --> Helper loaded: form_helper
INFO - 26.06.2025 11:42:45 --> Form Validation Class Initialized
INFO - 26.06.2025 11:42:45 --> Upload Class Initialized
INFO - 26.06.2025 11:42:45 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:42:45 --> Pagination Class Initialized
INFO - 26.06.2025 11:42:45 --> Controller Class Initialized
INFO - 26.06.2025 11:42:45 --> Model "Article_model" initialized
INFO - 26.06.2025 11:42:45 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:42:45 --> Image Lib Class Initialized
INFO - 26.06.2025 11:42:45 --> Final output sent to browser
DEBUG - 26.06.2025 11:42:45 --> Total execution time: 0.2490
INFO - 26.06.2025 11:43:04 --> Config Class Initialized
INFO - 26.06.2025 11:43:04 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:43:04 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:43:04 --> Utf8 Class Initialized
INFO - 26.06.2025 11:43:04 --> URI Class Initialized
INFO - 26.06.2025 11:43:04 --> Router Class Initialized
INFO - 26.06.2025 11:43:04 --> Output Class Initialized
INFO - 26.06.2025 11:43:04 --> Security Class Initialized
DEBUG - 26.06.2025 11:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:43:04 --> Input Class Initialized
INFO - 26.06.2025 11:43:04 --> Language Class Initialized
INFO - 26.06.2025 11:43:04 --> Loader Class Initialized
INFO - 26.06.2025 11:43:04 --> Helper loaded: app_helper
INFO - 26.06.2025 11:43:04 --> Helper loaded: language_helper
INFO - 26.06.2025 11:43:04 --> Helper loaded: text_helper
INFO - 26.06.2025 11:43:04 --> Helper loaded: string_helper
INFO - 26.06.2025 11:43:04 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:43:04 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:43:04 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:43:04 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:43:04 --> Email Class Initialized
INFO - 26.06.2025 11:43:04 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:43:04 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:43:04 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:04 --> Helper loaded: date_helper
INFO - 26.06.2025 11:43:04 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:43:04 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:04 --> Helper loaded: form_helper
INFO - 26.06.2025 11:43:04 --> Form Validation Class Initialized
INFO - 26.06.2025 11:43:04 --> Upload Class Initialized
INFO - 26.06.2025 11:43:04 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:43:04 --> Pagination Class Initialized
INFO - 26.06.2025 11:43:04 --> Controller Class Initialized
INFO - 26.06.2025 11:43:04 --> Model "Article_model" initialized
INFO - 26.06.2025 11:43:04 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:43:04 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:43:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:43:04 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [1] => <p>klôjklôjklôjklôjklô</p>
            [2] => <p>jklôjklôjklôjklôjklôjklô</p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
            [1] => 
            [2] => 
        )

    [ftp_section_image] => Array
        (
            [0] => 
            [1] => 
            [2] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
            [1] => 
            [2] => 
        )

    [button_names] => Array
        (
            [0] => lokfff
            [1] => 
            [2] => 
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:43:04 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

    [1] => Array
        (
            [content] => <p>klôjklôjklôjklôjklô</p>
            [image] => 
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

    [2] => Array
        (
            [content] => <p>jklôjklôjklôjklôjklôjklô</p>
            [image] => 
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:43:04 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [1] => <p>klôjklôjklôjklôjklô</p>
            [2] => <p>jklôjklôjklôjklôjklôjklô</p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
            [1] => 
            [2] => 
        )

    [ftp_section_image] => Array
        (
            [0] => 
            [1] => 
            [2] => 
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
            [1] => 
            [2] => 
        )

    [button_names] => Array
        (
            [0] => lokfff
            [1] => 
            [2] => 
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

            [1] => Array
                (
                    [content] => <p>klôjklôjklôjklôjklô</p>
                    [image] => 
                    [image_title] => 
                    [button_name] => 
                    [subpage] => 
                    [external_url] => 
                )

            [2] => Array
                (
                    [content] => <p>jklôjklôjklôjklôjklôjklô</p>
                    [image] => 
                    [image_title] => 
                    [button_name] => 
                    [subpage] => 
                    [external_url] => 
                )

        )

)

DEBUG - 26.06.2025 11:43:05 --> Inserting section 0: Array
(
    [article_id] => 46
    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
    [image] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
    [button_name] => lokfff
    [subpage] => 
    [external_url] => 
    [order] => 0
)

DEBUG - 26.06.2025 11:43:05 --> Processing section image upload for index 1: STYX_Gelaende_990x990.jpg
INFO - 26.06.2025 11:43:05 --> Image Lib Class Initialized
DEBUG - 26.06.2025 11:43:05 --> Section image uploaded successfully for index 1: uploads/articles/sections/ueber-styx_section_1_1750938185.jpg
DEBUG - 26.06.2025 11:43:05 --> Inserting section 1: Array
(
    [article_id] => 46
    [content] => <p>klôjklôjklôjklôjklô</p>
    [image] => uploads/articles/sections/ueber-styx_section_1_1750938185.jpg
    [image_title] => 
    [button_name] => 
    [subpage] => 
    [external_url] => 
    [order] => 1
)

DEBUG - 26.06.2025 11:43:05 --> Processing section image upload for index 2: Aloe Vera Produkte.jpg
DEBUG - 26.06.2025 11:43:05 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:43:05 --> Section image uploaded successfully for index 2: uploads/articles/sections/ueber-styx_section_2_1750938185.jpg
DEBUG - 26.06.2025 11:43:05 --> Inserting section 2: Array
(
    [article_id] => 46
    [content] => <p>jklôjklôjklôjklôjklôjklô</p>
    [image] => uploads/articles/sections/ueber-styx_section_2_1750938185.jpg
    [image_title] => 
    [button_name] => 
    [subpage] => 
    [external_url] => 
    [order] => 2
)

INFO - 26.06.2025 11:43:05 --> Config Class Initialized
INFO - 26.06.2025 11:43:05 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:43:05 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:43:05 --> Utf8 Class Initialized
INFO - 26.06.2025 11:43:05 --> URI Class Initialized
INFO - 26.06.2025 11:43:05 --> Router Class Initialized
INFO - 26.06.2025 11:43:05 --> Output Class Initialized
INFO - 26.06.2025 11:43:05 --> Security Class Initialized
DEBUG - 26.06.2025 11:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:43:05 --> Input Class Initialized
INFO - 26.06.2025 11:43:05 --> Language Class Initialized
INFO - 26.06.2025 11:43:05 --> Loader Class Initialized
INFO - 26.06.2025 11:43:05 --> Helper loaded: app_helper
INFO - 26.06.2025 11:43:05 --> Helper loaded: language_helper
INFO - 26.06.2025 11:43:05 --> Helper loaded: text_helper
INFO - 26.06.2025 11:43:05 --> Helper loaded: string_helper
INFO - 26.06.2025 11:43:05 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:43:05 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:43:05 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:43:05 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:43:05 --> Email Class Initialized
INFO - 26.06.2025 11:43:05 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:43:05 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:43:05 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:43:05 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:05 --> Helper loaded: date_helper
INFO - 26.06.2025 11:43:05 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:43:05 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:05 --> Helper loaded: form_helper
INFO - 26.06.2025 11:43:05 --> Form Validation Class Initialized
INFO - 26.06.2025 11:43:05 --> Upload Class Initialized
INFO - 26.06.2025 11:43:05 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:43:05 --> Pagination Class Initialized
INFO - 26.06.2025 11:43:05 --> Controller Class Initialized
INFO - 26.06.2025 11:43:05 --> Model "Article_model" initialized
INFO - 26.06.2025 11:43:05 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:43:05 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:05 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:43:05 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:43:05 --> Final output sent to browser
DEBUG - 26.06.2025 11:43:05 --> Total execution time: 0.4150
INFO - 26.06.2025 11:43:17 --> Config Class Initialized
INFO - 26.06.2025 11:43:17 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:43:17 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:43:17 --> Utf8 Class Initialized
INFO - 26.06.2025 11:43:17 --> URI Class Initialized
INFO - 26.06.2025 11:43:17 --> Router Class Initialized
INFO - 26.06.2025 11:43:17 --> Output Class Initialized
INFO - 26.06.2025 11:43:17 --> Security Class Initialized
DEBUG - 26.06.2025 11:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:43:17 --> Input Class Initialized
INFO - 26.06.2025 11:43:17 --> Language Class Initialized
INFO - 26.06.2025 11:43:17 --> Loader Class Initialized
INFO - 26.06.2025 11:43:17 --> Helper loaded: app_helper
INFO - 26.06.2025 11:43:17 --> Helper loaded: language_helper
INFO - 26.06.2025 11:43:17 --> Helper loaded: text_helper
INFO - 26.06.2025 11:43:17 --> Helper loaded: string_helper
INFO - 26.06.2025 11:43:17 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:43:17 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:43:17 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:43:17 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:43:17 --> Email Class Initialized
INFO - 26.06.2025 11:43:17 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:43:17 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:43:17 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:17 --> Helper loaded: date_helper
INFO - 26.06.2025 11:43:17 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:43:17 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:17 --> Helper loaded: form_helper
INFO - 26.06.2025 11:43:17 --> Form Validation Class Initialized
INFO - 26.06.2025 11:43:17 --> Upload Class Initialized
INFO - 26.06.2025 11:43:17 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:43:17 --> Pagination Class Initialized
INFO - 26.06.2025 11:43:17 --> Controller Class Initialized
INFO - 26.06.2025 11:43:17 --> Model "Article_model" initialized
INFO - 26.06.2025 11:43:17 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:43:17 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:43:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:43:17 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [1] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>klôjklôjklôjklôjklô</p>
            [image] => uploads/articles/sections/ueber-styx_section_1_1750938185.jpg
            [order] => 1
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [2] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>jklôjklôjklôjklôjklôjklô</p>
            [image] => uploads/articles/sections/ueber-styx_section_2_1750938185.jpg
            [order] => 2
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

)

INFO - 26.06.2025 11:43:17 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:43:17 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:43:17 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:43:17 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:43:17 --> Final output sent to browser
DEBUG - 26.06.2025 11:43:17 --> Total execution time: 0.4873
INFO - 26.06.2025 11:43:34 --> Config Class Initialized
INFO - 26.06.2025 11:43:34 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:43:34 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:43:34 --> Utf8 Class Initialized
INFO - 26.06.2025 11:43:34 --> URI Class Initialized
INFO - 26.06.2025 11:43:34 --> Router Class Initialized
INFO - 26.06.2025 11:43:34 --> Output Class Initialized
INFO - 26.06.2025 11:43:34 --> Security Class Initialized
DEBUG - 26.06.2025 11:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:43:34 --> Input Class Initialized
INFO - 26.06.2025 11:43:34 --> Language Class Initialized
INFO - 26.06.2025 11:43:34 --> Loader Class Initialized
INFO - 26.06.2025 11:43:34 --> Helper loaded: app_helper
INFO - 26.06.2025 11:43:34 --> Helper loaded: language_helper
INFO - 26.06.2025 11:43:34 --> Helper loaded: text_helper
INFO - 26.06.2025 11:43:34 --> Helper loaded: string_helper
INFO - 26.06.2025 11:43:34 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:43:34 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:43:34 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:43:34 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:43:34 --> Email Class Initialized
INFO - 26.06.2025 11:43:34 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:43:34 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:43:34 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:34 --> Helper loaded: date_helper
INFO - 26.06.2025 11:43:34 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:34 --> Helper loaded: form_helper
INFO - 26.06.2025 11:43:34 --> Form Validation Class Initialized
INFO - 26.06.2025 11:43:34 --> Upload Class Initialized
INFO - 26.06.2025 11:43:34 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:43:34 --> Pagination Class Initialized
INFO - 26.06.2025 11:43:34 --> Controller Class Initialized
INFO - 26.06.2025 11:43:34 --> Model "Ftpmanager_model" initialized
INFO - 26.06.2025 11:43:38 --> Final output sent to browser
DEBUG - 26.06.2025 11:43:38 --> Total execution time: 3.8541
INFO - 26.06.2025 11:43:39 --> Config Class Initialized
INFO - 26.06.2025 11:43:39 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:43:39 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:43:39 --> Utf8 Class Initialized
INFO - 26.06.2025 11:43:39 --> URI Class Initialized
INFO - 26.06.2025 11:43:39 --> Router Class Initialized
INFO - 26.06.2025 11:43:39 --> Output Class Initialized
INFO - 26.06.2025 11:43:39 --> Security Class Initialized
DEBUG - 26.06.2025 11:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:43:39 --> Input Class Initialized
INFO - 26.06.2025 11:43:39 --> Language Class Initialized
INFO - 26.06.2025 11:43:39 --> Loader Class Initialized
INFO - 26.06.2025 11:43:39 --> Helper loaded: app_helper
INFO - 26.06.2025 11:43:39 --> Helper loaded: language_helper
INFO - 26.06.2025 11:43:39 --> Helper loaded: text_helper
INFO - 26.06.2025 11:43:39 --> Helper loaded: string_helper
INFO - 26.06.2025 11:43:39 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:43:39 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:43:39 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:43:39 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:43:39 --> Email Class Initialized
INFO - 26.06.2025 11:43:39 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:43:39 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:43:39 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:39 --> Helper loaded: date_helper
INFO - 26.06.2025 11:43:39 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:43:39 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:39 --> Helper loaded: form_helper
INFO - 26.06.2025 11:43:39 --> Form Validation Class Initialized
INFO - 26.06.2025 11:43:39 --> Upload Class Initialized
INFO - 26.06.2025 11:43:39 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:43:39 --> Pagination Class Initialized
INFO - 26.06.2025 11:43:39 --> Controller Class Initialized
INFO - 26.06.2025 11:43:39 --> Model "Ftpmanager_model" initialized
INFO - 26.06.2025 11:43:41 --> Final output sent to browser
DEBUG - 26.06.2025 11:43:41 --> Total execution time: 2.6823
INFO - 26.06.2025 11:43:42 --> Config Class Initialized
INFO - 26.06.2025 11:43:42 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:43:42 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:43:42 --> Utf8 Class Initialized
INFO - 26.06.2025 11:43:42 --> URI Class Initialized
INFO - 26.06.2025 11:43:42 --> Router Class Initialized
INFO - 26.06.2025 11:43:42 --> Output Class Initialized
INFO - 26.06.2025 11:43:42 --> Security Class Initialized
DEBUG - 26.06.2025 11:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:43:42 --> Input Class Initialized
INFO - 26.06.2025 11:43:42 --> Language Class Initialized
INFO - 26.06.2025 11:43:42 --> Loader Class Initialized
INFO - 26.06.2025 11:43:42 --> Helper loaded: app_helper
INFO - 26.06.2025 11:43:42 --> Helper loaded: language_helper
INFO - 26.06.2025 11:43:42 --> Helper loaded: text_helper
INFO - 26.06.2025 11:43:42 --> Helper loaded: string_helper
INFO - 26.06.2025 11:43:42 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:43:42 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:43:42 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:43:43 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:43:43 --> Email Class Initialized
INFO - 26.06.2025 11:43:43 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:43:43 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:43:43 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:43 --> Helper loaded: date_helper
INFO - 26.06.2025 11:43:43 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:43:43 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:43 --> Helper loaded: form_helper
INFO - 26.06.2025 11:43:43 --> Form Validation Class Initialized
INFO - 26.06.2025 11:43:43 --> Upload Class Initialized
INFO - 26.06.2025 11:43:43 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:43:43 --> Pagination Class Initialized
INFO - 26.06.2025 11:43:43 --> Controller Class Initialized
INFO - 26.06.2025 11:43:43 --> Model "Ftpmanager_model" initialized
INFO - 26.06.2025 11:43:45 --> Final output sent to browser
DEBUG - 26.06.2025 11:43:45 --> Total execution time: 2.9100
INFO - 26.06.2025 11:43:46 --> Config Class Initialized
INFO - 26.06.2025 11:43:46 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:43:46 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:43:46 --> Utf8 Class Initialized
INFO - 26.06.2025 11:43:46 --> URI Class Initialized
INFO - 26.06.2025 11:43:46 --> Router Class Initialized
INFO - 26.06.2025 11:43:46 --> Output Class Initialized
INFO - 26.06.2025 11:43:46 --> Security Class Initialized
DEBUG - 26.06.2025 11:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:43:46 --> Input Class Initialized
INFO - 26.06.2025 11:43:46 --> Language Class Initialized
INFO - 26.06.2025 11:43:46 --> Loader Class Initialized
INFO - 26.06.2025 11:43:46 --> Helper loaded: app_helper
INFO - 26.06.2025 11:43:46 --> Helper loaded: language_helper
INFO - 26.06.2025 11:43:46 --> Helper loaded: text_helper
INFO - 26.06.2025 11:43:46 --> Helper loaded: string_helper
INFO - 26.06.2025 11:43:46 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:43:46 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:43:46 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:43:46 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:43:46 --> Email Class Initialized
INFO - 26.06.2025 11:43:46 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:43:46 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:43:46 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:46 --> Helper loaded: date_helper
INFO - 26.06.2025 11:43:46 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:43:46 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:46 --> Helper loaded: form_helper
INFO - 26.06.2025 11:43:46 --> Form Validation Class Initialized
INFO - 26.06.2025 11:43:46 --> Upload Class Initialized
INFO - 26.06.2025 11:43:46 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:43:46 --> Pagination Class Initialized
INFO - 26.06.2025 11:43:46 --> Controller Class Initialized
INFO - 26.06.2025 11:43:46 --> Model "Ftpmanager_model" initialized
INFO - 26.06.2025 11:43:49 --> Final output sent to browser
DEBUG - 26.06.2025 11:43:49 --> Total execution time: 3.3756
INFO - 26.06.2025 11:43:53 --> Config Class Initialized
INFO - 26.06.2025 11:43:53 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:43:53 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:43:53 --> Utf8 Class Initialized
INFO - 26.06.2025 11:43:53 --> URI Class Initialized
INFO - 26.06.2025 11:43:53 --> Router Class Initialized
INFO - 26.06.2025 11:43:53 --> Output Class Initialized
INFO - 26.06.2025 11:43:53 --> Security Class Initialized
DEBUG - 26.06.2025 11:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:43:53 --> Input Class Initialized
INFO - 26.06.2025 11:43:53 --> Language Class Initialized
INFO - 26.06.2025 11:43:53 --> Loader Class Initialized
INFO - 26.06.2025 11:43:53 --> Helper loaded: app_helper
INFO - 26.06.2025 11:43:53 --> Helper loaded: language_helper
INFO - 26.06.2025 11:43:53 --> Helper loaded: text_helper
INFO - 26.06.2025 11:43:53 --> Helper loaded: string_helper
INFO - 26.06.2025 11:43:53 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:43:53 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:43:53 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:43:53 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:43:53 --> Email Class Initialized
INFO - 26.06.2025 11:43:53 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:43:53 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:43:53 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:53 --> Helper loaded: date_helper
INFO - 26.06.2025 11:43:53 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:43:53 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:53 --> Helper loaded: form_helper
INFO - 26.06.2025 11:43:53 --> Form Validation Class Initialized
INFO - 26.06.2025 11:43:53 --> Upload Class Initialized
INFO - 26.06.2025 11:43:53 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:43:53 --> Pagination Class Initialized
INFO - 26.06.2025 11:43:53 --> Controller Class Initialized
INFO - 26.06.2025 11:43:53 --> Model "Article_model" initialized
INFO - 26.06.2025 11:43:53 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:43:53 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:43:53 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:43:53 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [1] => <p>klôjklôjklôjklôjklô</p>
            [2] => <p>jklôjklôjklôjklôjklôjklô</p>
            [3] => <p>rurtzurtzurtzurbt zu</p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
            [1] => 
            [2] => 
            [3] => 
        )

    [ftp_section_image] => Array
        (
            [0] => 
            [1] => 
            [2] => 
            [3] => https://styx.styxnatur.at/uploads/articles/sections/herr_styx.jpg
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
            [1] => uploads/articles/sections/ueber-styx_section_1_1750938185.jpg
            [2] => uploads/articles/sections/ueber-styx_section_2_1750938185.jpg
            [3] => 
        )

    [button_names] => Array
        (
            [0] => lokfff
            [1] => 
            [2] => 
            [3] => 
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:43:53 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

    [1] => Array
        (
            [content] => <p>klôjklôjklôjklôjklô</p>
            [image] => uploads/articles/sections/ueber-styx_section_1_1750938185.jpg
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

    [2] => Array
        (
            [content] => <p>jklôjklôjklôjklôjklôjklô</p>
            [image] => uploads/articles/sections/ueber-styx_section_2_1750938185.jpg
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

    [3] => Array
        (
            [content] => <p>rurtzurtzurtzurbt zu</p>
            [image] => https://styx.styxnatur.at/uploads/articles/sections/herr_styx.jpg
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:43:53 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => 
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [1] => <p>klôjklôjklôjklôjklô</p>
            [2] => <p>jklôjklôjklôjklôjklôjklô</p>
            [3] => <p>rurtzurtzurtzurbt zu</p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
            [1] => 
            [2] => 
            [3] => 
        )

    [ftp_section_image] => Array
        (
            [0] => 
            [1] => 
            [2] => 
            [3] => https://styx.styxnatur.at/uploads/articles/sections/herr_styx.jpg
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
            [1] => uploads/articles/sections/ueber-styx_section_1_1750938185.jpg
            [2] => uploads/articles/sections/ueber-styx_section_2_1750938185.jpg
            [3] => 
        )

    [button_names] => Array
        (
            [0] => lokfff
            [1] => 
            [2] => 
            [3] => 
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [image] => uploads/articles/green_brands_2022_2023_styx_naturcosmetic_1750934029.jpg
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

            [1] => Array
                (
                    [content] => <p>klôjklôjklôjklôjklô</p>
                    [image] => uploads/articles/sections/ueber-styx_section_1_1750938185.jpg
                    [image_title] => 
                    [button_name] => 
                    [subpage] => 
                    [external_url] => 
                )

            [2] => Array
                (
                    [content] => <p>jklôjklôjklôjklôjklôjklô</p>
                    [image] => uploads/articles/sections/ueber-styx_section_2_1750938185.jpg
                    [image_title] => 
                    [button_name] => 
                    [subpage] => 
                    [external_url] => 
                )

            [3] => Array
                (
                    [content] => <p>rurtzurtzurtzurbt zu</p>
                    [image] => https://styx.styxnatur.at/uploads/articles/sections/herr_styx.jpg
                    [image_title] => 
                    [button_name] => 
                    [subpage] => 
                    [external_url] => 
                )

        )

)

INFO - 26.06.2025 11:43:53 --> Image Lib Class Initialized
DEBUG - 26.06.2025 11:43:53 --> Inserting section 0: Array
(
    [article_id] => 46
    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
    [image] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
    [button_name] => lokfff
    [subpage] => 
    [external_url] => 
    [order] => 0
)

DEBUG - 26.06.2025 11:43:53 --> Inserting section 1: Array
(
    [article_id] => 46
    [content] => <p>klôjklôjklôjklôjklô</p>
    [image] => uploads/articles/sections/ueber-styx_section_1_1750938185.jpg
    [image_title] => 
    [button_name] => 
    [subpage] => 
    [external_url] => 
    [order] => 1
)

DEBUG - 26.06.2025 11:43:53 --> Inserting section 2: Array
(
    [article_id] => 46
    [content] => <p>jklôjklôjklôjklôjklôjklô</p>
    [image] => uploads/articles/sections/ueber-styx_section_2_1750938185.jpg
    [image_title] => 
    [button_name] => 
    [subpage] => 
    [external_url] => 
    [order] => 2
)

DEBUG - 26.06.2025 11:43:53 --> Inserting section 3: Array
(
    [article_id] => 46
    [content] => <p>rurtzurtzurtzurbt zu</p>
    [image] => 
    [image_title] => 
    [button_name] => 
    [subpage] => 
    [external_url] => 
    [order] => 3
)

INFO - 26.06.2025 11:43:53 --> Config Class Initialized
INFO - 26.06.2025 11:43:53 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:43:53 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:43:53 --> Utf8 Class Initialized
INFO - 26.06.2025 11:43:53 --> URI Class Initialized
INFO - 26.06.2025 11:43:53 --> Router Class Initialized
INFO - 26.06.2025 11:43:53 --> Output Class Initialized
INFO - 26.06.2025 11:43:53 --> Security Class Initialized
DEBUG - 26.06.2025 11:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:43:53 --> Input Class Initialized
INFO - 26.06.2025 11:43:53 --> Language Class Initialized
INFO - 26.06.2025 11:43:53 --> Loader Class Initialized
INFO - 26.06.2025 11:43:53 --> Helper loaded: app_helper
INFO - 26.06.2025 11:43:53 --> Helper loaded: language_helper
INFO - 26.06.2025 11:43:53 --> Helper loaded: text_helper
INFO - 26.06.2025 11:43:53 --> Helper loaded: string_helper
INFO - 26.06.2025 11:43:53 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:43:53 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:43:53 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:43:54 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:43:54 --> Email Class Initialized
INFO - 26.06.2025 11:43:54 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:43:54 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:43:54 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:54 --> Helper loaded: date_helper
INFO - 26.06.2025 11:43:54 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:43:54 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:54 --> Helper loaded: form_helper
INFO - 26.06.2025 11:43:54 --> Form Validation Class Initialized
INFO - 26.06.2025 11:43:54 --> Upload Class Initialized
INFO - 26.06.2025 11:43:54 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:43:54 --> Pagination Class Initialized
INFO - 26.06.2025 11:43:54 --> Controller Class Initialized
INFO - 26.06.2025 11:43:54 --> Model "Article_model" initialized
INFO - 26.06.2025 11:43:54 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:43:54 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:43:54 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:43:54 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:43:54 --> Final output sent to browser
DEBUG - 26.06.2025 11:43:54 --> Total execution time: 0.3936
INFO - 26.06.2025 11:45:00 --> Config Class Initialized
INFO - 26.06.2025 11:45:00 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:45:00 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:45:00 --> Utf8 Class Initialized
INFO - 26.06.2025 11:45:00 --> URI Class Initialized
INFO - 26.06.2025 11:45:00 --> Router Class Initialized
INFO - 26.06.2025 11:45:00 --> Output Class Initialized
INFO - 26.06.2025 11:45:00 --> Security Class Initialized
DEBUG - 26.06.2025 11:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:45:00 --> Input Class Initialized
INFO - 26.06.2025 11:45:00 --> Language Class Initialized
INFO - 26.06.2025 11:45:00 --> Loader Class Initialized
INFO - 26.06.2025 11:45:00 --> Helper loaded: app_helper
INFO - 26.06.2025 11:45:00 --> Helper loaded: language_helper
INFO - 26.06.2025 11:45:00 --> Helper loaded: text_helper
INFO - 26.06.2025 11:45:00 --> Helper loaded: string_helper
INFO - 26.06.2025 11:45:00 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:45:00 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:45:00 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:45:00 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:45:00 --> Email Class Initialized
INFO - 26.06.2025 11:45:00 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:45:00 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:45:00 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:45:00 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:45:00 --> Helper loaded: date_helper
INFO - 26.06.2025 11:45:00 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:45:00 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:45:00 --> Helper loaded: form_helper
INFO - 26.06.2025 11:45:00 --> Form Validation Class Initialized
INFO - 26.06.2025 11:45:00 --> Upload Class Initialized
INFO - 26.06.2025 11:45:00 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:45:00 --> Pagination Class Initialized
INFO - 26.06.2025 11:45:00 --> Controller Class Initialized
INFO - 26.06.2025 11:45:00 --> Model "Article_model" initialized
INFO - 26.06.2025 11:45:00 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:45:00 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:45:01 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:45:01 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0_1750938136.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [1] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>klôjklôjklôjklôjklô</p>
            [image] => uploads/articles/sections/ueber-styx_section_1_1750938185.jpg
            [order] => 1
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [2] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>jklôjklôjklôjklôjklôjklô</p>
            [image] => uploads/articles/sections/ueber-styx_section_2_1750938185.jpg
            [order] => 2
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [3] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>rurtzurtzurtzurbt zu</p>
            [image] => 
            [order] => 3
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

)

INFO - 26.06.2025 11:45:01 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:45:01 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:45:01 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:45:01 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:45:01 --> Final output sent to browser
DEBUG - 26.06.2025 11:45:01 --> Total execution time: 0.5059
INFO - 26.06.2025 11:47:20 --> Config Class Initialized
INFO - 26.06.2025 11:47:20 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:47:20 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:47:20 --> Utf8 Class Initialized
INFO - 26.06.2025 11:47:20 --> URI Class Initialized
INFO - 26.06.2025 11:47:20 --> Router Class Initialized
INFO - 26.06.2025 11:47:20 --> Output Class Initialized
INFO - 26.06.2025 11:47:20 --> Security Class Initialized
DEBUG - 26.06.2025 11:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:47:20 --> Input Class Initialized
INFO - 26.06.2025 11:47:20 --> Language Class Initialized
INFO - 26.06.2025 11:47:20 --> Loader Class Initialized
INFO - 26.06.2025 11:47:20 --> Helper loaded: app_helper
INFO - 26.06.2025 11:47:20 --> Helper loaded: language_helper
INFO - 26.06.2025 11:47:20 --> Helper loaded: text_helper
INFO - 26.06.2025 11:47:20 --> Helper loaded: string_helper
INFO - 26.06.2025 11:47:20 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:47:20 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:47:20 --> Database Driver Class Initialized
INFO - 26.06.2025 11:47:20 --> Config Class Initialized
INFO - 26.06.2025 11:47:20 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:47:20 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:47:20 --> Utf8 Class Initialized
INFO - 26.06.2025 11:47:20 --> URI Class Initialized
INFO - 26.06.2025 11:47:20 --> Router Class Initialized
INFO - 26.06.2025 11:47:20 --> Output Class Initialized
INFO - 26.06.2025 11:47:20 --> Security Class Initialized
DEBUG - 26.06.2025 11:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:47:20 --> Input Class Initialized
INFO - 26.06.2025 11:47:20 --> Language Class Initialized
DEBUG - 26.06.2025 11:47:20 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:47:20 --> Loader Class Initialized
INFO - 26.06.2025 11:47:20 --> Helper loaded: app_helper
INFO - 26.06.2025 11:47:20 --> Helper loaded: language_helper
INFO - 26.06.2025 11:47:20 --> Email Class Initialized
INFO - 26.06.2025 11:47:20 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:47:20 --> Helper loaded: text_helper
INFO - 26.06.2025 11:47:20 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:47:20 --> Helper loaded: string_helper
INFO - 26.06.2025 11:47:20 --> Helper loaded: url_helper
INFO - 26.06.2025 11:47:20 --> Language file loaded: language/german/app_lang.php
DEBUG - 26.06.2025 11:47:20 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:47:20 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:47:20 --> Helper loaded: date_helper
INFO - 26.06.2025 11:47:20 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:47:20 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:47:20 --> Helper loaded: form_helper
INFO - 26.06.2025 11:47:20 --> Form Validation Class Initialized
INFO - 26.06.2025 11:47:20 --> Database Driver Class Initialized
INFO - 26.06.2025 11:47:20 --> Upload Class Initialized
INFO - 26.06.2025 11:47:20 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:47:20 --> Pagination Class Initialized
INFO - 26.06.2025 11:47:20 --> Controller Class Initialized
INFO - 26.06.2025 11:47:20 --> Model "App_model" initialized
INFO - 26.06.2025 11:47:20 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:47:20 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
ERROR - 26.06.2025 11:47:20 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:47:20 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:47:20 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:47:20 --> Could not find the language line "ABOUT_US"
DEBUG - 26.06.2025 11:47:21 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:47:21 --> Email Class Initialized
INFO - 26.06.2025 11:47:21 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:47:21 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:47:21 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:47:21 --> Helper loaded: date_helper
INFO - 26.06.2025 11:47:21 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:47:21 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:47:21 --> Helper loaded: form_helper
INFO - 26.06.2025 11:47:21 --> Form Validation Class Initialized
INFO - 26.06.2025 11:47:21 --> Upload Class Initialized
INFO - 26.06.2025 11:47:21 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:47:21 --> Pagination Class Initialized
INFO - 26.06.2025 11:47:21 --> Controller Class Initialized
INFO - 26.06.2025 11:47:21 --> Model "App_model" initialized
INFO - 26.06.2025 11:47:21 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:47:21 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
INFO - 26.06.2025 11:47:21 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:47:21 --> Final output sent to browser
DEBUG - 26.06.2025 11:47:21 --> Total execution time: 0.4814
ERROR - 26.06.2025 11:47:21 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:47:21 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:47:21 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:47:21 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:47:21 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:47:21 --> Final output sent to browser
DEBUG - 26.06.2025 11:47:21 --> Total execution time: 0.4809
INFO - 26.06.2025 11:48:13 --> Config Class Initialized
INFO - 26.06.2025 11:48:13 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:48:13 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:48:13 --> Utf8 Class Initialized
INFO - 26.06.2025 11:48:13 --> URI Class Initialized
INFO - 26.06.2025 11:48:13 --> Router Class Initialized
INFO - 26.06.2025 11:48:13 --> Output Class Initialized
INFO - 26.06.2025 11:48:13 --> Security Class Initialized
DEBUG - 26.06.2025 11:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:48:13 --> Input Class Initialized
INFO - 26.06.2025 11:48:13 --> Language Class Initialized
INFO - 26.06.2025 11:48:13 --> Loader Class Initialized
INFO - 26.06.2025 11:48:13 --> Helper loaded: app_helper
INFO - 26.06.2025 11:48:13 --> Helper loaded: language_helper
INFO - 26.06.2025 11:48:13 --> Helper loaded: text_helper
INFO - 26.06.2025 11:48:13 --> Helper loaded: string_helper
INFO - 26.06.2025 11:48:13 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:48:13 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:48:13 --> Database Driver Class Initialized
INFO - 26.06.2025 11:48:13 --> Config Class Initialized
INFO - 26.06.2025 11:48:13 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:48:13 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:48:13 --> Utf8 Class Initialized
INFO - 26.06.2025 11:48:13 --> URI Class Initialized
INFO - 26.06.2025 11:48:13 --> Router Class Initialized
INFO - 26.06.2025 11:48:13 --> Output Class Initialized
INFO - 26.06.2025 11:48:13 --> Security Class Initialized
DEBUG - 26.06.2025 11:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:48:13 --> Input Class Initialized
INFO - 26.06.2025 11:48:13 --> Language Class Initialized
INFO - 26.06.2025 11:48:13 --> Loader Class Initialized
INFO - 26.06.2025 11:48:13 --> Helper loaded: app_helper
INFO - 26.06.2025 11:48:13 --> Helper loaded: language_helper
INFO - 26.06.2025 11:48:13 --> Helper loaded: text_helper
INFO - 26.06.2025 11:48:13 --> Helper loaded: string_helper
INFO - 26.06.2025 11:48:13 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:48:13 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:48:13 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:48:14 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:48:14 --> Email Class Initialized
INFO - 26.06.2025 11:48:14 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:48:14 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:48:14 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:14 --> Helper loaded: date_helper
INFO - 26.06.2025 11:48:14 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:14 --> Helper loaded: form_helper
INFO - 26.06.2025 11:48:14 --> Form Validation Class Initialized
INFO - 26.06.2025 11:48:14 --> Upload Class Initialized
INFO - 26.06.2025 11:48:14 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:48:14 --> Pagination Class Initialized
INFO - 26.06.2025 11:48:14 --> Controller Class Initialized
INFO - 26.06.2025 11:48:14 --> Model "App_model" initialized
INFO - 26.06.2025 11:48:14 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:48:14 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
DEBUG - 26.06.2025 11:48:14 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:48:14 --> Email Class Initialized
INFO - 26.06.2025 11:48:14 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:48:14 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:48:14 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:14 --> Helper loaded: date_helper
INFO - 26.06.2025 11:48:14 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:14 --> Helper loaded: form_helper
INFO - 26.06.2025 11:48:14 --> Form Validation Class Initialized
INFO - 26.06.2025 11:48:14 --> Upload Class Initialized
INFO - 26.06.2025 11:48:14 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:48:14 --> Pagination Class Initialized
INFO - 26.06.2025 11:48:14 --> Controller Class Initialized
INFO - 26.06.2025 11:48:14 --> Model "App_model" initialized
INFO - 26.06.2025 11:48:14 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:48:14 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:48:14 --> Could not find the language line "ERROR_404_DESCRIPTION"
ERROR - 26.06.2025 11:48:14 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
ERROR - 26.06.2025 11:48:14 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:48:14 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:48:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:48:14 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:48:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:48:15 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:48:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:48:15 --> Final output sent to browser
DEBUG - 26.06.2025 11:48:15 --> Total execution time: 1.8518
INFO - 26.06.2025 11:48:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:48:15 --> Final output sent to browser
DEBUG - 26.06.2025 11:48:15 --> Total execution time: 1.7058
INFO - 26.06.2025 11:48:17 --> Config Class Initialized
INFO - 26.06.2025 11:48:17 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:48:17 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:48:17 --> Utf8 Class Initialized
INFO - 26.06.2025 11:48:17 --> URI Class Initialized
INFO - 26.06.2025 11:48:17 --> Router Class Initialized
INFO - 26.06.2025 11:48:17 --> Output Class Initialized
INFO - 26.06.2025 11:48:17 --> Security Class Initialized
DEBUG - 26.06.2025 11:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:48:17 --> Input Class Initialized
INFO - 26.06.2025 11:48:17 --> Language Class Initialized
INFO - 26.06.2025 11:48:17 --> Loader Class Initialized
INFO - 26.06.2025 11:48:17 --> Helper loaded: app_helper
INFO - 26.06.2025 11:48:17 --> Helper loaded: language_helper
INFO - 26.06.2025 11:48:17 --> Helper loaded: text_helper
INFO - 26.06.2025 11:48:17 --> Helper loaded: string_helper
INFO - 26.06.2025 11:48:17 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:48:17 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:48:17 --> Database Driver Class Initialized
INFO - 26.06.2025 11:48:17 --> Config Class Initialized
INFO - 26.06.2025 11:48:17 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:48:17 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:48:17 --> Utf8 Class Initialized
INFO - 26.06.2025 11:48:17 --> URI Class Initialized
INFO - 26.06.2025 11:48:17 --> Router Class Initialized
INFO - 26.06.2025 11:48:17 --> Output Class Initialized
INFO - 26.06.2025 11:48:17 --> Security Class Initialized
DEBUG - 26.06.2025 11:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:48:17 --> Input Class Initialized
INFO - 26.06.2025 11:48:17 --> Language Class Initialized
INFO - 26.06.2025 11:48:17 --> Loader Class Initialized
INFO - 26.06.2025 11:48:17 --> Helper loaded: app_helper
INFO - 26.06.2025 11:48:17 --> Helper loaded: language_helper
INFO - 26.06.2025 11:48:17 --> Helper loaded: text_helper
INFO - 26.06.2025 11:48:17 --> Helper loaded: string_helper
INFO - 26.06.2025 11:48:17 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:48:17 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:48:17 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:48:17 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:48:17 --> Email Class Initialized
INFO - 26.06.2025 11:48:17 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:48:17 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:48:17 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:17 --> Helper loaded: date_helper
INFO - 26.06.2025 11:48:17 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:17 --> Helper loaded: form_helper
INFO - 26.06.2025 11:48:17 --> Form Validation Class Initialized
INFO - 26.06.2025 11:48:17 --> Upload Class Initialized
INFO - 26.06.2025 11:48:17 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:48:17 --> Pagination Class Initialized
INFO - 26.06.2025 11:48:17 --> Controller Class Initialized
INFO - 26.06.2025 11:48:17 --> Model "App_model" initialized
INFO - 26.06.2025 11:48:17 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:48:17 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
ERROR - 26.06.2025 11:48:17 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:48:17 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:48:17 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:48:17 --> Could not find the language line "ABOUT_US"
DEBUG - 26.06.2025 11:48:17 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:48:17 --> Email Class Initialized
INFO - 26.06.2025 11:48:17 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:48:17 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:48:17 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:17 --> Helper loaded: date_helper
INFO - 26.06.2025 11:48:17 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:48:17 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:17 --> Helper loaded: form_helper
INFO - 26.06.2025 11:48:17 --> Form Validation Class Initialized
INFO - 26.06.2025 11:48:17 --> Upload Class Initialized
INFO - 26.06.2025 11:48:17 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:48:17 --> Pagination Class Initialized
INFO - 26.06.2025 11:48:17 --> Controller Class Initialized
INFO - 26.06.2025 11:48:17 --> Model "App_model" initialized
INFO - 26.06.2025 11:48:17 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:48:17 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
INFO - 26.06.2025 11:48:17 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:48:17 --> Final output sent to browser
DEBUG - 26.06.2025 11:48:17 --> Total execution time: 0.4979
ERROR - 26.06.2025 11:48:17 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:48:17 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:48:17 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:48:17 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:48:17 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:48:17 --> Final output sent to browser
DEBUG - 26.06.2025 11:48:17 --> Total execution time: 0.5219
INFO - 26.06.2025 11:48:32 --> Config Class Initialized
INFO - 26.06.2025 11:48:32 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:48:32 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:48:32 --> Utf8 Class Initialized
INFO - 26.06.2025 11:48:32 --> URI Class Initialized
INFO - 26.06.2025 11:48:32 --> Router Class Initialized
INFO - 26.06.2025 11:48:32 --> Output Class Initialized
INFO - 26.06.2025 11:48:32 --> Security Class Initialized
DEBUG - 26.06.2025 11:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:48:32 --> Input Class Initialized
INFO - 26.06.2025 11:48:32 --> Language Class Initialized
INFO - 26.06.2025 11:48:32 --> Loader Class Initialized
INFO - 26.06.2025 11:48:32 --> Helper loaded: app_helper
INFO - 26.06.2025 11:48:32 --> Helper loaded: language_helper
INFO - 26.06.2025 11:48:32 --> Helper loaded: text_helper
INFO - 26.06.2025 11:48:32 --> Helper loaded: string_helper
INFO - 26.06.2025 11:48:32 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:48:32 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:48:32 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:48:32 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:48:32 --> Email Class Initialized
INFO - 26.06.2025 11:48:32 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:48:32 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:48:32 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:48:32 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:32 --> Helper loaded: date_helper
INFO - 26.06.2025 11:48:32 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:48:32 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:32 --> Helper loaded: form_helper
INFO - 26.06.2025 11:48:32 --> Form Validation Class Initialized
INFO - 26.06.2025 11:48:32 --> Upload Class Initialized
INFO - 26.06.2025 11:48:32 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:48:32 --> Pagination Class Initialized
INFO - 26.06.2025 11:48:32 --> Controller Class Initialized
INFO - 26.06.2025 11:48:32 --> Model "Article_model" initialized
INFO - 26.06.2025 11:48:32 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:48:32 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:48:32 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:48:32 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0_1750938494.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [1] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>klôjklôjklôjklôjklô</p>
            [image] => uploads/articles/sections/ueber-styx_section_1_1750938494.jpg
            [order] => 1
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [2] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>jklôjklôjklôjklôjklôjklô<br><br><img src="https://styx.styxnatur.at/uploads/articles/summernote/herr_styx_1750938488.jpg" style="font-family: Poppins; width: 676px;"><br></p>
            [image] => uploads/articles/sections/ueber-styx_section_2_1750938494.jpg
            [order] => 2
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [3] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>rurtzurtzurtzurbt zu</p>
            [image] => uploads/articles/sections/aroma_derm_folder_1.jpg
            [order] => 3
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

)

INFO - 26.06.2025 11:48:32 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:48:32 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:48:32 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:48:32 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:48:32 --> Final output sent to browser
DEBUG - 26.06.2025 11:48:32 --> Total execution time: 0.4679
INFO - 26.06.2025 11:48:32 --> Config Class Initialized
INFO - 26.06.2025 11:48:32 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:48:32 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:48:32 --> Utf8 Class Initialized
INFO - 26.06.2025 11:48:32 --> URI Class Initialized
INFO - 26.06.2025 11:48:32 --> Router Class Initialized
INFO - 26.06.2025 11:48:32 --> Output Class Initialized
INFO - 26.06.2025 11:48:32 --> Security Class Initialized
DEBUG - 26.06.2025 11:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:48:32 --> Input Class Initialized
INFO - 26.06.2025 11:48:32 --> Language Class Initialized
INFO - 26.06.2025 11:48:32 --> Loader Class Initialized
INFO - 26.06.2025 11:48:32 --> Helper loaded: app_helper
INFO - 26.06.2025 11:48:32 --> Helper loaded: language_helper
INFO - 26.06.2025 11:48:32 --> Helper loaded: text_helper
INFO - 26.06.2025 11:48:32 --> Helper loaded: string_helper
INFO - 26.06.2025 11:48:32 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:48:32 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:48:32 --> Database Driver Class Initialized
INFO - 26.06.2025 11:48:32 --> Config Class Initialized
INFO - 26.06.2025 11:48:32 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:48:32 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:48:32 --> Utf8 Class Initialized
INFO - 26.06.2025 11:48:32 --> URI Class Initialized
INFO - 26.06.2025 11:48:32 --> Router Class Initialized
INFO - 26.06.2025 11:48:32 --> Output Class Initialized
INFO - 26.06.2025 11:48:32 --> Security Class Initialized
DEBUG - 26.06.2025 11:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:48:32 --> Input Class Initialized
INFO - 26.06.2025 11:48:32 --> Language Class Initialized
INFO - 26.06.2025 11:48:32 --> Loader Class Initialized
INFO - 26.06.2025 11:48:32 --> Helper loaded: app_helper
INFO - 26.06.2025 11:48:32 --> Helper loaded: language_helper
INFO - 26.06.2025 11:48:32 --> Helper loaded: text_helper
INFO - 26.06.2025 11:48:32 --> Helper loaded: string_helper
INFO - 26.06.2025 11:48:32 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:48:32 --> Config Class Initialized
INFO - 26.06.2025 11:48:32 --> Hooks Class Initialized
INFO - 26.06.2025 11:48:32 --> Config Class Initialized
INFO - 26.06.2025 11:48:32 --> Hooks Class Initialized
INFO - 26.06.2025 11:48:32 --> Config Class Initialized
INFO - 26.06.2025 11:48:32 --> Config Class Initialized
INFO - 26.06.2025 11:48:32 --> Hooks Class Initialized
INFO - 26.06.2025 11:48:32 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:48:32 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:48:32 --> Utf8 Class Initialized
DEBUG - 26.06.2025 11:48:32 --> UTF-8 Support Enabled
DEBUG - 26.06.2025 11:48:32 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:48:32 --> Utf8 Class Initialized
INFO - 26.06.2025 11:48:32 --> URI Class Initialized
DEBUG - 26.06.2025 11:48:32 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:48:32 --> Utf8 Class Initialized
INFO - 26.06.2025 11:48:32 --> Utf8 Class Initialized
INFO - 26.06.2025 11:48:32 --> URI Class Initialized
INFO - 26.06.2025 11:48:32 --> URI Class Initialized
INFO - 26.06.2025 11:48:32 --> URI Class Initialized
INFO - 26.06.2025 11:48:32 --> Router Class Initialized
INFO - 26.06.2025 11:48:32 --> Router Class Initialized
INFO - 26.06.2025 11:48:32 --> Router Class Initialized
INFO - 26.06.2025 11:48:32 --> Router Class Initialized
INFO - 26.06.2025 11:48:32 --> Output Class Initialized
INFO - 26.06.2025 11:48:32 --> Output Class Initialized
INFO - 26.06.2025 11:48:32 --> Security Class Initialized
INFO - 26.06.2025 11:48:32 --> Output Class Initialized
INFO - 26.06.2025 11:48:32 --> Output Class Initialized
INFO - 26.06.2025 11:48:32 --> Security Class Initialized
DEBUG - 26.06.2025 11:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:48:32 --> Security Class Initialized
INFO - 26.06.2025 11:48:32 --> Input Class Initialized
INFO - 26.06.2025 11:48:33 --> Security Class Initialized
DEBUG - 26.06.2025 11:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:48:33 --> Language Class Initialized
INFO - 26.06.2025 11:48:33 --> Input Class Initialized
DEBUG - 26.06.2025 11:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:48:33 --> Input Class Initialized
INFO - 26.06.2025 11:48:33 --> Language Class Initialized
DEBUG - 26.06.2025 11:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:48:33 --> Input Class Initialized
INFO - 26.06.2025 11:48:33 --> Language Class Initialized
INFO - 26.06.2025 11:48:33 --> Language Class Initialized
INFO - 26.06.2025 11:48:33 --> Loader Class Initialized
INFO - 26.06.2025 11:48:33 --> Loader Class Initialized
INFO - 26.06.2025 11:48:33 --> Loader Class Initialized
INFO - 26.06.2025 11:48:33 --> Helper loaded: app_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: app_helper
INFO - 26.06.2025 11:48:33 --> Loader Class Initialized
INFO - 26.06.2025 11:48:33 --> Helper loaded: language_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: app_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: language_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: language_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: text_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: app_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: text_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: text_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: language_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: string_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: string_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: string_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: text_helper
INFO - 26.06.2025 11:48:33 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:48:33 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:48:33 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:48:33 --> Helper loaded: string_helper
INFO - 26.06.2025 11:48:33 --> Language file loaded: language/german/app_lang.php
DEBUG - 26.06.2025 11:48:33 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:48:33 --> Email Class Initialized
INFO - 26.06.2025 11:48:33 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:48:33 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:33 --> Helper loaded: date_helper
INFO - 26.06.2025 11:48:33 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:33 --> Helper loaded: form_helper
INFO - 26.06.2025 11:48:33 --> Form Validation Class Initialized
INFO - 26.06.2025 11:48:33 --> Upload Class Initialized
INFO - 26.06.2025 11:48:33 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:48:33 --> Pagination Class Initialized
INFO - 26.06.2025 11:48:33 --> Controller Class Initialized
INFO - 26.06.2025 11:48:33 --> Model "App_model" initialized
INFO - 26.06.2025 11:48:33 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:48:33 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/ueber-styx.jpg
ERROR - 26.06.2025 11:48:33 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:48:33 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:48:33 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:48:33 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:48:33 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:48:33 --> Final output sent to browser
DEBUG - 26.06.2025 11:48:33 --> Total execution time: 0.4861
INFO - 26.06.2025 11:48:33 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:48:33 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:48:33 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:48:33 --> Email Class Initialized
INFO - 26.06.2025 11:48:33 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:48:33 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:33 --> Helper loaded: date_helper
INFO - 26.06.2025 11:48:33 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:33 --> Helper loaded: form_helper
INFO - 26.06.2025 11:48:33 --> Form Validation Class Initialized
INFO - 26.06.2025 11:48:33 --> Upload Class Initialized
INFO - 26.06.2025 11:48:33 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:48:33 --> Pagination Class Initialized
INFO - 26.06.2025 11:48:33 --> Controller Class Initialized
INFO - 26.06.2025 11:48:33 --> Model "App_model" initialized
INFO - 26.06.2025 11:48:33 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:48:33 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
ERROR - 26.06.2025 11:48:33 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:48:33 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:48:33 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:48:33 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:48:33 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:48:33 --> Final output sent to browser
DEBUG - 26.06.2025 11:48:33 --> Total execution time: 0.8212
INFO - 26.06.2025 11:48:33 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:48:33 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:48:33 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:48:33 --> Email Class Initialized
INFO - 26.06.2025 11:48:33 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:48:33 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:48:33 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:33 --> Helper loaded: date_helper
INFO - 26.06.2025 11:48:33 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:48:33 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:33 --> Helper loaded: form_helper
INFO - 26.06.2025 11:48:33 --> Form Validation Class Initialized
INFO - 26.06.2025 11:48:33 --> Upload Class Initialized
INFO - 26.06.2025 11:48:33 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:48:33 --> Pagination Class Initialized
INFO - 26.06.2025 11:48:33 --> Controller Class Initialized
INFO - 26.06.2025 11:48:33 --> Model "App_model" initialized
INFO - 26.06.2025 11:48:33 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:48:33 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/aroma_derm_folder_1.jpg
ERROR - 26.06.2025 11:48:34 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:48:34 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:48:34 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:48:34 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:48:34 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:48:34 --> Final output sent to browser
DEBUG - 26.06.2025 11:48:34 --> Total execution time: 1.2061
INFO - 26.06.2025 11:48:34 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:48:34 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:48:34 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:48:34 --> Email Class Initialized
INFO - 26.06.2025 11:48:34 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:48:34 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:48:34 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:34 --> Helper loaded: date_helper
INFO - 26.06.2025 11:48:34 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:34 --> Helper loaded: form_helper
INFO - 26.06.2025 11:48:34 --> Form Validation Class Initialized
INFO - 26.06.2025 11:48:34 --> Upload Class Initialized
INFO - 26.06.2025 11:48:34 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:48:34 --> Pagination Class Initialized
INFO - 26.06.2025 11:48:34 --> Controller Class Initialized
INFO - 26.06.2025 11:48:34 --> Model "App_model" initialized
INFO - 26.06.2025 11:48:34 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:48:34 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/ueber-styx_section_0_1750938494.jpg
ERROR - 26.06.2025 11:48:34 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:48:34 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:48:34 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:48:34 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:48:34 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:48:34 --> Final output sent to browser
DEBUG - 26.06.2025 11:48:34 --> Total execution time: 1.6565
INFO - 26.06.2025 11:48:34 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:48:34 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:48:34 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:48:34 --> Email Class Initialized
INFO - 26.06.2025 11:48:34 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:48:34 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:48:34 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:34 --> Helper loaded: date_helper
INFO - 26.06.2025 11:48:34 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:48:34 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:34 --> Helper loaded: form_helper
INFO - 26.06.2025 11:48:34 --> Form Validation Class Initialized
INFO - 26.06.2025 11:48:34 --> Upload Class Initialized
INFO - 26.06.2025 11:48:34 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:48:34 --> Pagination Class Initialized
INFO - 26.06.2025 11:48:34 --> Controller Class Initialized
INFO - 26.06.2025 11:48:34 --> Model "App_model" initialized
INFO - 26.06.2025 11:48:34 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:48:34 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/ueber-styx_section_1_1750938494.jpg
ERROR - 26.06.2025 11:48:34 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:48:34 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:48:35 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:48:35 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:48:35 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:48:35 --> Final output sent to browser
DEBUG - 26.06.2025 11:48:35 --> Total execution time: 2.1053
INFO - 26.06.2025 11:48:35 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:48:35 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:48:35 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:48:35 --> Email Class Initialized
INFO - 26.06.2025 11:48:35 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:48:35 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:48:35 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:48:35 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:35 --> Helper loaded: date_helper
INFO - 26.06.2025 11:48:35 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:48:35 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:35 --> Helper loaded: form_helper
INFO - 26.06.2025 11:48:35 --> Form Validation Class Initialized
INFO - 26.06.2025 11:48:35 --> Upload Class Initialized
INFO - 26.06.2025 11:48:35 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:48:35 --> Pagination Class Initialized
INFO - 26.06.2025 11:48:35 --> Controller Class Initialized
INFO - 26.06.2025 11:48:35 --> Model "App_model" initialized
INFO - 26.06.2025 11:48:35 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:48:35 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/ueber-styx_section_2_1750938494.jpg
ERROR - 26.06.2025 11:48:35 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:48:35 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:48:35 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:48:35 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:48:35 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:48:35 --> Final output sent to browser
DEBUG - 26.06.2025 11:48:35 --> Total execution time: 2.5530
INFO - 26.06.2025 11:48:52 --> Config Class Initialized
INFO - 26.06.2025 11:48:52 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:48:52 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:48:52 --> Utf8 Class Initialized
INFO - 26.06.2025 11:48:52 --> URI Class Initialized
INFO - 26.06.2025 11:48:52 --> Router Class Initialized
INFO - 26.06.2025 11:48:52 --> Output Class Initialized
INFO - 26.06.2025 11:48:52 --> Security Class Initialized
DEBUG - 26.06.2025 11:48:52 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:48:52 --> Input Class Initialized
INFO - 26.06.2025 11:48:52 --> Language Class Initialized
INFO - 26.06.2025 11:48:52 --> Loader Class Initialized
INFO - 26.06.2025 11:48:52 --> Helper loaded: app_helper
INFO - 26.06.2025 11:48:52 --> Helper loaded: language_helper
INFO - 26.06.2025 11:48:52 --> Helper loaded: text_helper
INFO - 26.06.2025 11:48:52 --> Helper loaded: string_helper
INFO - 26.06.2025 11:48:52 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:48:52 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:48:52 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:48:52 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:48:52 --> Email Class Initialized
INFO - 26.06.2025 11:48:52 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:48:52 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:48:52 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:52 --> Helper loaded: date_helper
INFO - 26.06.2025 11:48:52 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:48:52 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:52 --> Helper loaded: form_helper
INFO - 26.06.2025 11:48:52 --> Form Validation Class Initialized
INFO - 26.06.2025 11:48:52 --> Upload Class Initialized
INFO - 26.06.2025 11:48:52 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:48:52 --> Pagination Class Initialized
INFO - 26.06.2025 11:48:52 --> Controller Class Initialized
INFO - 26.06.2025 11:48:52 --> Model "Ftpmanager_model" initialized
INFO - 26.06.2025 11:48:55 --> Final output sent to browser
DEBUG - 26.06.2025 11:48:55 --> Total execution time: 3.3992
INFO - 26.06.2025 11:48:56 --> Config Class Initialized
INFO - 26.06.2025 11:48:56 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:48:56 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:48:56 --> Utf8 Class Initialized
INFO - 26.06.2025 11:48:56 --> URI Class Initialized
INFO - 26.06.2025 11:48:56 --> Router Class Initialized
INFO - 26.06.2025 11:48:56 --> Output Class Initialized
INFO - 26.06.2025 11:48:56 --> Security Class Initialized
DEBUG - 26.06.2025 11:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:48:56 --> Input Class Initialized
INFO - 26.06.2025 11:48:56 --> Language Class Initialized
INFO - 26.06.2025 11:48:56 --> Loader Class Initialized
INFO - 26.06.2025 11:48:56 --> Helper loaded: app_helper
INFO - 26.06.2025 11:48:56 --> Helper loaded: language_helper
INFO - 26.06.2025 11:48:56 --> Helper loaded: text_helper
INFO - 26.06.2025 11:48:56 --> Helper loaded: string_helper
INFO - 26.06.2025 11:48:56 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:48:56 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:48:56 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:48:56 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:48:56 --> Email Class Initialized
INFO - 26.06.2025 11:48:56 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:48:56 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:48:56 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:56 --> Helper loaded: date_helper
INFO - 26.06.2025 11:48:56 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:48:56 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:48:56 --> Helper loaded: form_helper
INFO - 26.06.2025 11:48:56 --> Form Validation Class Initialized
INFO - 26.06.2025 11:48:56 --> Upload Class Initialized
INFO - 26.06.2025 11:48:56 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:48:56 --> Pagination Class Initialized
INFO - 26.06.2025 11:48:56 --> Controller Class Initialized
INFO - 26.06.2025 11:48:56 --> Model "Ftpmanager_model" initialized
INFO - 26.06.2025 11:48:59 --> Final output sent to browser
DEBUG - 26.06.2025 11:48:59 --> Total execution time: 2.8659
INFO - 26.06.2025 11:49:00 --> Config Class Initialized
INFO - 26.06.2025 11:49:00 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:49:00 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:49:00 --> Utf8 Class Initialized
INFO - 26.06.2025 11:49:00 --> URI Class Initialized
INFO - 26.06.2025 11:49:00 --> Router Class Initialized
INFO - 26.06.2025 11:49:00 --> Output Class Initialized
INFO - 26.06.2025 11:49:00 --> Security Class Initialized
DEBUG - 26.06.2025 11:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:49:00 --> Input Class Initialized
INFO - 26.06.2025 11:49:00 --> Language Class Initialized
INFO - 26.06.2025 11:49:00 --> Loader Class Initialized
INFO - 26.06.2025 11:49:00 --> Helper loaded: app_helper
INFO - 26.06.2025 11:49:00 --> Helper loaded: language_helper
INFO - 26.06.2025 11:49:01 --> Helper loaded: text_helper
INFO - 26.06.2025 11:49:01 --> Helper loaded: string_helper
INFO - 26.06.2025 11:49:01 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:49:01 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:49:01 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:49:01 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:49:01 --> Email Class Initialized
INFO - 26.06.2025 11:49:01 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:49:01 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:49:01 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:01 --> Helper loaded: date_helper
INFO - 26.06.2025 11:49:01 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:49:01 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:01 --> Helper loaded: form_helper
INFO - 26.06.2025 11:49:01 --> Form Validation Class Initialized
INFO - 26.06.2025 11:49:01 --> Upload Class Initialized
INFO - 26.06.2025 11:49:01 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:49:01 --> Pagination Class Initialized
INFO - 26.06.2025 11:49:01 --> Controller Class Initialized
INFO - 26.06.2025 11:49:01 --> Model "Ftpmanager_model" initialized
INFO - 26.06.2025 11:49:03 --> Final output sent to browser
DEBUG - 26.06.2025 11:49:03 --> Total execution time: 2.8194
INFO - 26.06.2025 11:49:08 --> Config Class Initialized
INFO - 26.06.2025 11:49:08 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:49:08 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:49:08 --> Utf8 Class Initialized
INFO - 26.06.2025 11:49:08 --> URI Class Initialized
INFO - 26.06.2025 11:49:08 --> Router Class Initialized
INFO - 26.06.2025 11:49:08 --> Output Class Initialized
INFO - 26.06.2025 11:49:08 --> Security Class Initialized
DEBUG - 26.06.2025 11:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:49:08 --> Input Class Initialized
INFO - 26.06.2025 11:49:08 --> Language Class Initialized
INFO - 26.06.2025 11:49:08 --> Loader Class Initialized
INFO - 26.06.2025 11:49:08 --> Helper loaded: app_helper
INFO - 26.06.2025 11:49:08 --> Helper loaded: language_helper
INFO - 26.06.2025 11:49:08 --> Helper loaded: text_helper
INFO - 26.06.2025 11:49:08 --> Helper loaded: string_helper
INFO - 26.06.2025 11:49:08 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:49:08 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:49:08 --> Database Driver Class Initialized
INFO - 26.06.2025 11:49:08 --> Config Class Initialized
INFO - 26.06.2025 11:49:08 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:49:08 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:49:08 --> Utf8 Class Initialized
INFO - 26.06.2025 11:49:08 --> URI Class Initialized
INFO - 26.06.2025 11:49:08 --> Router Class Initialized
INFO - 26.06.2025 11:49:08 --> Output Class Initialized
INFO - 26.06.2025 11:49:08 --> Security Class Initialized
DEBUG - 26.06.2025 11:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:49:08 --> Input Class Initialized
INFO - 26.06.2025 11:49:08 --> Language Class Initialized
INFO - 26.06.2025 11:49:08 --> Loader Class Initialized
INFO - 26.06.2025 11:49:08 --> Helper loaded: app_helper
INFO - 26.06.2025 11:49:08 --> Helper loaded: language_helper
INFO - 26.06.2025 11:49:08 --> Helper loaded: text_helper
INFO - 26.06.2025 11:49:08 --> Helper loaded: string_helper
INFO - 26.06.2025 11:49:08 --> Language file loaded: language/german/app_lang.php
DEBUG - 26.06.2025 11:49:08 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:49:08 --> Email Class Initialized
INFO - 26.06.2025 11:49:08 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:49:08 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:49:08 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:08 --> Helper loaded: date_helper
INFO - 26.06.2025 11:49:08 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:49:08 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:08 --> Helper loaded: form_helper
INFO - 26.06.2025 11:49:08 --> Form Validation Class Initialized
INFO - 26.06.2025 11:49:08 --> Upload Class Initialized
INFO - 26.06.2025 11:49:08 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:49:08 --> Pagination Class Initialized
INFO - 26.06.2025 11:49:08 --> Controller Class Initialized
INFO - 26.06.2025 11:49:08 --> Model "App_model" initialized
INFO - 26.06.2025 11:49:08 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:49:08 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
ERROR - 26.06.2025 11:49:08 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:49:08 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:49:09 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:49:09 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:49:09 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:49:09 --> Final output sent to browser
DEBUG - 26.06.2025 11:49:09 --> Total execution time: 0.4594
INFO - 26.06.2025 11:49:09 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:49:09 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:49:09 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:49:09 --> Email Class Initialized
INFO - 26.06.2025 11:49:09 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:49:09 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:49:09 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:09 --> Helper loaded: date_helper
INFO - 26.06.2025 11:49:09 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:49:09 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:09 --> Helper loaded: form_helper
INFO - 26.06.2025 11:49:09 --> Form Validation Class Initialized
INFO - 26.06.2025 11:49:09 --> Upload Class Initialized
INFO - 26.06.2025 11:49:09 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:49:09 --> Pagination Class Initialized
INFO - 26.06.2025 11:49:09 --> Controller Class Initialized
INFO - 26.06.2025 11:49:09 --> Model "Article_model" initialized
INFO - 26.06.2025 11:49:09 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:49:09 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:49:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:49:09 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => uploads/articles/ueber-styx.jpg
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [1] => <p>klôjklôjklôjklôjklô</p>
            [2] => <p>jklôjklôjklôjklôjklôjklô<br><br><img src="https://styx.styxnatur.at/uploads/articles/summernote/herr_styx_1750938488.jpg" style="font-family: Poppins; width: 676px;"><br></p>
            [3] => <p>rurtzurtzurtzurbt zu</p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
            [1] => 
            [2] => 
            [3] => 
        )

    [ftp_section_image] => Array
        (
            [0] => 
            [1] => 
            [2] => 
            [3] => https://styx.styxnatur.at/uploads/news/1b204f426ca7ef4bae070616b1f517e5.jpg
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0_1750938494.jpg
            [1] => uploads/articles/sections/ueber-styx_section_1_1750938494.jpg
            [2] => uploads/articles/sections/ueber-styx_section_2_1750938494.jpg
            [3] => uploads/articles/sections/aroma_derm_folder_1.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
            [1] => 
            [2] => 
            [3] => 
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:49:09 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => 
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

    [1] => Array
        (
            [content] => <p>klôjklôjklôjklôjklô</p>
            [image] => 
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

    [2] => Array
        (
            [content] => <p>jklôjklôjklôjklôjklôjklô<br><br><img src="https://styx.styxnatur.at/uploads/articles/summernote/herr_styx_1750938488.jpg" style="font-family: Poppins; width: 676px;"><br></p>
            [image] => uploads/articles/sections/ueber-styx_section_2_1750938494.jpg
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

    [3] => Array
        (
            [content] => <p>rurtzurtzurtzurbt zu</p>
            [image] => https://styx.styxnatur.at/uploads/news/1b204f426ca7ef4bae070616b1f517e5.jpg
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:49:09 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => uploads/articles/ueber-styx.jpg
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [1] => <p>klôjklôjklôjklôjklô</p>
            [2] => <p>jklôjklôjklôjklôjklôjklô<br><br><img src="https://styx.styxnatur.at/uploads/articles/summernote/herr_styx_1750938488.jpg" style="font-family: Poppins; width: 676px;"><br></p>
            [3] => <p>rurtzurtzurtzurbt zu</p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
            [1] => 
            [2] => 
            [3] => 
        )

    [ftp_section_image] => Array
        (
            [0] => 
            [1] => 
            [2] => 
            [3] => https://styx.styxnatur.at/uploads/news/1b204f426ca7ef4bae070616b1f517e5.jpg
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0_1750938494.jpg
            [1] => uploads/articles/sections/ueber-styx_section_1_1750938494.jpg
            [2] => uploads/articles/sections/ueber-styx_section_2_1750938494.jpg
            [3] => uploads/articles/sections/aroma_derm_folder_1.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
            [1] => 
            [2] => 
            [3] => 
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [image] => uploads/articles/green_brands_2022_2023_styx_naturcosmetic_1750934029.jpg
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => 
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

            [1] => Array
                (
                    [content] => <p>klôjklôjklôjklôjklô</p>
                    [image] => 
                    [image_title] => 
                    [button_name] => 
                    [subpage] => 
                    [external_url] => 
                )

            [2] => Array
                (
                    [content] => <p>jklôjklôjklôjklôjklôjklô<br><br><img src="https://styx.styxnatur.at/uploads/articles/summernote/herr_styx_1750938488.jpg" style="font-family: Poppins; width: 676px;"><br></p>
                    [image] => uploads/articles/sections/ueber-styx_section_2_1750938494.jpg
                    [image_title] => 
                    [button_name] => 
                    [subpage] => 
                    [external_url] => 
                )

            [3] => Array
                (
                    [content] => <p>rurtzurtzurtzurbt zu</p>
                    [image] => https://styx.styxnatur.at/uploads/news/1b204f426ca7ef4bae070616b1f517e5.jpg
                    [image_title] => 
                    [button_name] => 
                    [subpage] => 
                    [external_url] => 
                )

        )

)

INFO - 26.06.2025 11:49:09 --> Image Lib Class Initialized
DEBUG - 26.06.2025 11:49:09 --> Processing section image upload for index 0: herr_styx.jpg
DEBUG - 26.06.2025 11:49:09 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:49:09 --> Section image uploaded successfully for index 0: uploads/articles/sections/ueber-styx_section_0_1750938549.jpg
DEBUG - 26.06.2025 11:49:09 --> Inserting section 0: Array
(
    [article_id] => 46
    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
    [image] => uploads/articles/sections/ueber-styx_section_0_1750938549.jpg
    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
    [button_name] => lokfff
    [subpage] => 
    [external_url] => 
    [order] => 0
)

DEBUG - 26.06.2025 11:49:09 --> Processing section image upload for index 1: herr_styx.jpg
DEBUG - 26.06.2025 11:49:09 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:49:09 --> Section image uploaded successfully for index 1: uploads/articles/sections/ueber-styx_section_1_1750938549.jpg
DEBUG - 26.06.2025 11:49:09 --> Inserting section 1: Array
(
    [article_id] => 46
    [content] => <p>klôjklôjklôjklôjklô</p>
    [image] => uploads/articles/sections/ueber-styx_section_1_1750938549.jpg
    [image_title] => 
    [button_name] => 
    [subpage] => 
    [external_url] => 
    [order] => 1
)

DEBUG - 26.06.2025 11:49:09 --> Inserting section 2: Array
(
    [article_id] => 46
    [content] => <p>jklôjklôjklôjklôjklôjklô<br><br><img src="https://styx.styxnatur.at/uploads/articles/summernote/herr_styx_1750938488.jpg" style="font-family: Poppins; width: 676px;"><br></p>
    [image] => uploads/articles/sections/ueber-styx_section_2_1750938494.jpg
    [image_title] => 
    [button_name] => 
    [subpage] => 
    [external_url] => 
    [order] => 2
)

DEBUG - 26.06.2025 11:49:10 --> Inserting section 3: Array
(
    [article_id] => 46
    [content] => <p>rurtzurtzurtzurbt zu</p>
    [image] => uploads/articles/sections/aroma_derm_folder_1.jpg
    [image_title] => 
    [button_name] => 
    [subpage] => 
    [external_url] => 
    [order] => 3
)

INFO - 26.06.2025 11:49:10 --> Config Class Initialized
INFO - 26.06.2025 11:49:10 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:49:10 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:49:10 --> Utf8 Class Initialized
INFO - 26.06.2025 11:49:10 --> URI Class Initialized
INFO - 26.06.2025 11:49:10 --> Router Class Initialized
INFO - 26.06.2025 11:49:10 --> Output Class Initialized
INFO - 26.06.2025 11:49:10 --> Security Class Initialized
DEBUG - 26.06.2025 11:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:49:10 --> Input Class Initialized
INFO - 26.06.2025 11:49:10 --> Language Class Initialized
INFO - 26.06.2025 11:49:10 --> Loader Class Initialized
INFO - 26.06.2025 11:49:10 --> Helper loaded: app_helper
INFO - 26.06.2025 11:49:10 --> Helper loaded: language_helper
INFO - 26.06.2025 11:49:10 --> Helper loaded: text_helper
INFO - 26.06.2025 11:49:10 --> Helper loaded: string_helper
INFO - 26.06.2025 11:49:10 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:49:10 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:49:10 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:49:10 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:49:10 --> Email Class Initialized
INFO - 26.06.2025 11:49:10 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:49:10 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:49:10 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:10 --> Helper loaded: date_helper
INFO - 26.06.2025 11:49:10 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:10 --> Helper loaded: form_helper
INFO - 26.06.2025 11:49:10 --> Form Validation Class Initialized
INFO - 26.06.2025 11:49:10 --> Upload Class Initialized
INFO - 26.06.2025 11:49:10 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:49:10 --> Pagination Class Initialized
INFO - 26.06.2025 11:49:10 --> Controller Class Initialized
INFO - 26.06.2025 11:49:10 --> Model "Article_model" initialized
INFO - 26.06.2025 11:49:10 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:49:10 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:10 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:49:10 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:49:10 --> Final output sent to browser
DEBUG - 26.06.2025 11:49:10 --> Total execution time: 0.3990
INFO - 26.06.2025 11:49:14 --> Config Class Initialized
INFO - 26.06.2025 11:49:14 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:49:14 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:49:14 --> Utf8 Class Initialized
INFO - 26.06.2025 11:49:14 --> URI Class Initialized
INFO - 26.06.2025 11:49:14 --> Router Class Initialized
INFO - 26.06.2025 11:49:14 --> Output Class Initialized
INFO - 26.06.2025 11:49:14 --> Security Class Initialized
DEBUG - 26.06.2025 11:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:49:14 --> Input Class Initialized
INFO - 26.06.2025 11:49:14 --> Language Class Initialized
INFO - 26.06.2025 11:49:14 --> Loader Class Initialized
INFO - 26.06.2025 11:49:14 --> Helper loaded: app_helper
INFO - 26.06.2025 11:49:14 --> Helper loaded: language_helper
INFO - 26.06.2025 11:49:14 --> Helper loaded: text_helper
INFO - 26.06.2025 11:49:14 --> Helper loaded: string_helper
INFO - 26.06.2025 11:49:14 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:49:14 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:49:14 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:49:15 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:49:15 --> Email Class Initialized
INFO - 26.06.2025 11:49:15 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:49:15 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:49:15 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:15 --> Helper loaded: date_helper
INFO - 26.06.2025 11:49:15 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:15 --> Helper loaded: form_helper
INFO - 26.06.2025 11:49:15 --> Form Validation Class Initialized
INFO - 26.06.2025 11:49:15 --> Upload Class Initialized
INFO - 26.06.2025 11:49:15 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:49:15 --> Pagination Class Initialized
INFO - 26.06.2025 11:49:15 --> Controller Class Initialized
INFO - 26.06.2025 11:49:15 --> Model "Article_model" initialized
INFO - 26.06.2025 11:49:15 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:49:15 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:49:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:49:15 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0_1750938549.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [1] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>klôjklôjklôjklôjklô</p>
            [image] => uploads/articles/sections/ueber-styx_section_1_1750938549.jpg
            [order] => 1
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [2] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>jklôjklôjklôjklôjklôjklô<br><br><img src="https://styx.styxnatur.at/uploads/articles/summernote/herr_styx_1750938488.jpg" style="font-family: Poppins; width: 676px;"><br></p>
            [image] => uploads/articles/sections/ueber-styx_section_2_1750938494.jpg
            [order] => 2
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [3] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>rurtzurtzurtzurbt zu</p>
            [image] => uploads/articles/sections/aroma_derm_folder_1.jpg
            [order] => 3
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

)

INFO - 26.06.2025 11:49:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:49:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:49:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:49:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:49:15 --> Final output sent to browser
DEBUG - 26.06.2025 11:49:15 --> Total execution time: 0.4799
INFO - 26.06.2025 11:49:15 --> Config Class Initialized
INFO - 26.06.2025 11:49:15 --> Hooks Class Initialized
INFO - 26.06.2025 11:49:15 --> Config Class Initialized
INFO - 26.06.2025 11:49:15 --> Hooks Class Initialized
INFO - 26.06.2025 11:49:15 --> Config Class Initialized
INFO - 26.06.2025 11:49:15 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:49:15 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:49:15 --> Utf8 Class Initialized
INFO - 26.06.2025 11:49:15 --> URI Class Initialized
DEBUG - 26.06.2025 11:49:15 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:49:15 --> Utf8 Class Initialized
DEBUG - 26.06.2025 11:49:15 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:49:15 --> Utf8 Class Initialized
INFO - 26.06.2025 11:49:15 --> URI Class Initialized
INFO - 26.06.2025 11:49:15 --> URI Class Initialized
INFO - 26.06.2025 11:49:15 --> Router Class Initialized
INFO - 26.06.2025 11:49:15 --> Output Class Initialized
INFO - 26.06.2025 11:49:15 --> Router Class Initialized
INFO - 26.06.2025 11:49:15 --> Router Class Initialized
INFO - 26.06.2025 11:49:15 --> Output Class Initialized
INFO - 26.06.2025 11:49:15 --> Security Class Initialized
INFO - 26.06.2025 11:49:15 --> Output Class Initialized
INFO - 26.06.2025 11:49:15 --> Security Class Initialized
DEBUG - 26.06.2025 11:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:49:15 --> Input Class Initialized
INFO - 26.06.2025 11:49:15 --> Security Class Initialized
DEBUG - 26.06.2025 11:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:49:15 --> Input Class Initialized
INFO - 26.06.2025 11:49:15 --> Language Class Initialized
DEBUG - 26.06.2025 11:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:49:15 --> Language Class Initialized
INFO - 26.06.2025 11:49:15 --> Input Class Initialized
INFO - 26.06.2025 11:49:15 --> Language Class Initialized
INFO - 26.06.2025 11:49:15 --> Loader Class Initialized
INFO - 26.06.2025 11:49:15 --> Loader Class Initialized
INFO - 26.06.2025 11:49:15 --> Helper loaded: app_helper
INFO - 26.06.2025 11:49:15 --> Loader Class Initialized
INFO - 26.06.2025 11:49:15 --> Helper loaded: language_helper
INFO - 26.06.2025 11:49:15 --> Helper loaded: app_helper
INFO - 26.06.2025 11:49:15 --> Helper loaded: language_helper
INFO - 26.06.2025 11:49:15 --> Helper loaded: text_helper
INFO - 26.06.2025 11:49:15 --> Helper loaded: app_helper
INFO - 26.06.2025 11:49:15 --> Helper loaded: text_helper
INFO - 26.06.2025 11:49:15 --> Helper loaded: language_helper
INFO - 26.06.2025 11:49:15 --> Helper loaded: string_helper
INFO - 26.06.2025 11:49:15 --> Helper loaded: string_helper
INFO - 26.06.2025 11:49:15 --> Helper loaded: text_helper
INFO - 26.06.2025 11:49:15 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:49:15 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:49:15 --> Helper loaded: string_helper
INFO - 26.06.2025 11:49:15 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:49:15 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:49:15 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:49:15 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:49:15 --> Email Class Initialized
INFO - 26.06.2025 11:49:15 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:49:15 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:49:15 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:15 --> Helper loaded: date_helper
INFO - 26.06.2025 11:49:15 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:49:15 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:15 --> Helper loaded: form_helper
INFO - 26.06.2025 11:49:15 --> Form Validation Class Initialized
INFO - 26.06.2025 11:49:15 --> Upload Class Initialized
INFO - 26.06.2025 11:49:15 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:49:15 --> Pagination Class Initialized
INFO - 26.06.2025 11:49:15 --> Controller Class Initialized
INFO - 26.06.2025 11:49:15 --> Model "App_model" initialized
INFO - 26.06.2025 11:49:15 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:49:15 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
ERROR - 26.06.2025 11:49:15 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:49:15 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:49:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:49:15 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:49:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:49:15 --> Final output sent to browser
DEBUG - 26.06.2025 11:49:15 --> Total execution time: 0.4720
INFO - 26.06.2025 11:49:15 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:49:15 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:49:16 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:49:16 --> Email Class Initialized
INFO - 26.06.2025 11:49:16 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:49:16 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:49:16 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:16 --> Helper loaded: date_helper
INFO - 26.06.2025 11:49:16 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:16 --> Helper loaded: form_helper
INFO - 26.06.2025 11:49:16 --> Form Validation Class Initialized
INFO - 26.06.2025 11:49:16 --> Upload Class Initialized
INFO - 26.06.2025 11:49:16 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:49:16 --> Pagination Class Initialized
INFO - 26.06.2025 11:49:16 --> Controller Class Initialized
INFO - 26.06.2025 11:49:16 --> Model "App_model" initialized
INFO - 26.06.2025 11:49:16 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:49:16 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/aroma_derm_folder_1.jpg
ERROR - 26.06.2025 11:49:16 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:49:16 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:49:16 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:49:16 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:49:16 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:49:16 --> Final output sent to browser
DEBUG - 26.06.2025 11:49:16 --> Total execution time: 0.9201
INFO - 26.06.2025 11:49:16 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:49:16 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:49:16 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:49:16 --> Email Class Initialized
INFO - 26.06.2025 11:49:16 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:49:16 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:49:16 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:16 --> Helper loaded: date_helper
INFO - 26.06.2025 11:49:16 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:49:16 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:49:16 --> Helper loaded: form_helper
INFO - 26.06.2025 11:49:16 --> Form Validation Class Initialized
INFO - 26.06.2025 11:49:16 --> Upload Class Initialized
INFO - 26.06.2025 11:49:16 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:49:16 --> Pagination Class Initialized
INFO - 26.06.2025 11:49:16 --> Controller Class Initialized
INFO - 26.06.2025 11:49:16 --> Model "App_model" initialized
INFO - 26.06.2025 11:49:16 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:49:16 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/ueber-styx_section_2_1750938494.jpg
ERROR - 26.06.2025 11:49:16 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:49:16 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:49:16 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:49:16 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:49:16 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:49:16 --> Final output sent to browser
DEBUG - 26.06.2025 11:49:16 --> Total execution time: 1.3735
INFO - 26.06.2025 11:51:11 --> Config Class Initialized
INFO - 26.06.2025 11:51:11 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:51:11 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:51:11 --> Utf8 Class Initialized
INFO - 26.06.2025 11:51:11 --> URI Class Initialized
INFO - 26.06.2025 11:51:11 --> Router Class Initialized
INFO - 26.06.2025 11:51:11 --> Output Class Initialized
INFO - 26.06.2025 11:51:11 --> Security Class Initialized
DEBUG - 26.06.2025 11:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:51:11 --> Input Class Initialized
INFO - 26.06.2025 11:51:11 --> Language Class Initialized
INFO - 26.06.2025 11:51:11 --> Loader Class Initialized
INFO - 26.06.2025 11:51:11 --> Helper loaded: app_helper
INFO - 26.06.2025 11:51:11 --> Helper loaded: language_helper
INFO - 26.06.2025 11:51:11 --> Helper loaded: text_helper
INFO - 26.06.2025 11:51:11 --> Helper loaded: string_helper
INFO - 26.06.2025 11:51:11 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:51:11 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:51:11 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:51:12 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:51:12 --> Email Class Initialized
INFO - 26.06.2025 11:51:12 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:51:12 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:12 --> Helper loaded: date_helper
INFO - 26.06.2025 11:51:12 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:12 --> Helper loaded: form_helper
INFO - 26.06.2025 11:51:12 --> Form Validation Class Initialized
INFO - 26.06.2025 11:51:12 --> Upload Class Initialized
INFO - 26.06.2025 11:51:12 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:51:12 --> Pagination Class Initialized
INFO - 26.06.2025 11:51:12 --> Controller Class Initialized
INFO - 26.06.2025 11:51:12 --> Model "Article_model" initialized
INFO - 26.06.2025 11:51:12 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:51:12 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:51:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:51:12 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0_1750938549.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [1] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>klôjklôjklôjklôjklô</p>
            [image] => uploads/articles/sections/ueber-styx_section_1_1750938549.jpg
            [order] => 1
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [2] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>jklôjklôjklôjklôjklôjklô<br><br><img src="https://styx.styxnatur.at/uploads/articles/summernote/herr_styx_1750938488.jpg" style="font-family: Poppins; width: 676px;"><br></p>
            [image] => uploads/articles/sections/ueber-styx_section_2_1750938494.jpg
            [order] => 2
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [3] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>rurtzurtzurtzurbt zu</p>
            [image] => uploads/articles/sections/aroma_derm_folder_1.jpg
            [order] => 3
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

)

INFO - 26.06.2025 11:51:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:51:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:51:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:51:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:51:12 --> Final output sent to browser
DEBUG - 26.06.2025 11:51:12 --> Total execution time: 0.8266
INFO - 26.06.2025 11:51:12 --> Config Class Initialized
INFO - 26.06.2025 11:51:12 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:51:12 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:51:12 --> Utf8 Class Initialized
INFO - 26.06.2025 11:51:12 --> URI Class Initialized
INFO - 26.06.2025 11:51:12 --> Router Class Initialized
INFO - 26.06.2025 11:51:12 --> Output Class Initialized
INFO - 26.06.2025 11:51:12 --> Security Class Initialized
DEBUG - 26.06.2025 11:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:51:12 --> Input Class Initialized
INFO - 26.06.2025 11:51:12 --> Language Class Initialized
INFO - 26.06.2025 11:51:12 --> Loader Class Initialized
INFO - 26.06.2025 11:51:12 --> Helper loaded: app_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: language_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: text_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: string_helper
INFO - 26.06.2025 11:51:12 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:51:12 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:51:12 --> Database Driver Class Initialized
INFO - 26.06.2025 11:51:12 --> Config Class Initialized
INFO - 26.06.2025 11:51:12 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:51:12 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:51:12 --> Utf8 Class Initialized
INFO - 26.06.2025 11:51:12 --> URI Class Initialized
INFO - 26.06.2025 11:51:12 --> Router Class Initialized
INFO - 26.06.2025 11:51:12 --> Output Class Initialized
INFO - 26.06.2025 11:51:12 --> Security Class Initialized
DEBUG - 26.06.2025 11:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:51:12 --> Input Class Initialized
INFO - 26.06.2025 11:51:12 --> Language Class Initialized
INFO - 26.06.2025 11:51:12 --> Loader Class Initialized
INFO - 26.06.2025 11:51:12 --> Helper loaded: app_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: language_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: text_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: string_helper
INFO - 26.06.2025 11:51:12 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:51:12 --> Config Class Initialized
INFO - 26.06.2025 11:51:12 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:51:12 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:51:12 --> Utf8 Class Initialized
INFO - 26.06.2025 11:51:12 --> URI Class Initialized
INFO - 26.06.2025 11:51:12 --> Router Class Initialized
INFO - 26.06.2025 11:51:12 --> Output Class Initialized
INFO - 26.06.2025 11:51:12 --> Security Class Initialized
DEBUG - 26.06.2025 11:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:51:12 --> Input Class Initialized
INFO - 26.06.2025 11:51:12 --> Language Class Initialized
INFO - 26.06.2025 11:51:12 --> Loader Class Initialized
INFO - 26.06.2025 11:51:12 --> Helper loaded: app_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: language_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: text_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: string_helper
INFO - 26.06.2025 11:51:12 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:51:12 --> Config Class Initialized
INFO - 26.06.2025 11:51:12 --> Config Class Initialized
INFO - 26.06.2025 11:51:12 --> Hooks Class Initialized
INFO - 26.06.2025 11:51:12 --> Hooks Class Initialized
INFO - 26.06.2025 11:51:12 --> Config Class Initialized
INFO - 26.06.2025 11:51:12 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:51:12 --> UTF-8 Support Enabled
DEBUG - 26.06.2025 11:51:12 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:51:12 --> Utf8 Class Initialized
INFO - 26.06.2025 11:51:12 --> Utf8 Class Initialized
DEBUG - 26.06.2025 11:51:12 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:51:12 --> Utf8 Class Initialized
INFO - 26.06.2025 11:51:12 --> URI Class Initialized
INFO - 26.06.2025 11:51:12 --> URI Class Initialized
INFO - 26.06.2025 11:51:12 --> URI Class Initialized
INFO - 26.06.2025 11:51:12 --> Router Class Initialized
INFO - 26.06.2025 11:51:12 --> Router Class Initialized
INFO - 26.06.2025 11:51:12 --> Router Class Initialized
INFO - 26.06.2025 11:51:12 --> Output Class Initialized
INFO - 26.06.2025 11:51:12 --> Output Class Initialized
INFO - 26.06.2025 11:51:12 --> Output Class Initialized
INFO - 26.06.2025 11:51:12 --> Security Class Initialized
INFO - 26.06.2025 11:51:12 --> Security Class Initialized
INFO - 26.06.2025 11:51:12 --> Security Class Initialized
DEBUG - 26.06.2025 11:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:51:12 --> Input Class Initialized
DEBUG - 26.06.2025 11:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:51:12 --> Input Class Initialized
INFO - 26.06.2025 11:51:12 --> Language Class Initialized
DEBUG - 26.06.2025 11:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:51:12 --> Language Class Initialized
INFO - 26.06.2025 11:51:12 --> Input Class Initialized
INFO - 26.06.2025 11:51:12 --> Language Class Initialized
INFO - 26.06.2025 11:51:12 --> Loader Class Initialized
INFO - 26.06.2025 11:51:12 --> Loader Class Initialized
INFO - 26.06.2025 11:51:12 --> Loader Class Initialized
INFO - 26.06.2025 11:51:12 --> Helper loaded: app_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: app_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: language_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: app_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: language_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: language_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: text_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: text_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: text_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: string_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: string_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: string_helper
INFO - 26.06.2025 11:51:12 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:51:12 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:51:12 --> Language file loaded: language/german/app_lang.php
DEBUG - 26.06.2025 11:51:12 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:51:12 --> Email Class Initialized
INFO - 26.06.2025 11:51:12 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:51:12 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:51:12 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:12 --> Helper loaded: date_helper
INFO - 26.06.2025 11:51:12 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:51:12 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:12 --> Helper loaded: form_helper
INFO - 26.06.2025 11:51:12 --> Form Validation Class Initialized
INFO - 26.06.2025 11:51:12 --> Upload Class Initialized
INFO - 26.06.2025 11:51:12 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:51:12 --> Pagination Class Initialized
INFO - 26.06.2025 11:51:12 --> Controller Class Initialized
INFO - 26.06.2025 11:51:12 --> Model "App_model" initialized
INFO - 26.06.2025 11:51:12 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:51:12 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/title_image/ueber-styx.jpg
ERROR - 26.06.2025 11:51:12 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:51:12 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:51:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:51:12 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:51:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:51:12 --> Final output sent to browser
DEBUG - 26.06.2025 11:51:12 --> Total execution time: 0.4815
INFO - 26.06.2025 11:51:12 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:51:12 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:51:13 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:51:13 --> Email Class Initialized
INFO - 26.06.2025 11:51:13 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:51:13 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:51:13 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:13 --> Helper loaded: date_helper
INFO - 26.06.2025 11:51:13 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:13 --> Helper loaded: form_helper
INFO - 26.06.2025 11:51:13 --> Form Validation Class Initialized
INFO - 26.06.2025 11:51:13 --> Upload Class Initialized
INFO - 26.06.2025 11:51:13 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:51:13 --> Pagination Class Initialized
INFO - 26.06.2025 11:51:13 --> Controller Class Initialized
INFO - 26.06.2025 11:51:13 --> Model "App_model" initialized
INFO - 26.06.2025 11:51:13 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:51:13 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/ueber-styx_section_0_1750938549.jpg
ERROR - 26.06.2025 11:51:13 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:51:13 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:51:13 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:51:13 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:51:13 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:51:13 --> Final output sent to browser
DEBUG - 26.06.2025 11:51:13 --> Total execution time: 0.8952
INFO - 26.06.2025 11:51:13 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:51:13 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:51:13 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:51:13 --> Email Class Initialized
INFO - 26.06.2025 11:51:13 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:51:13 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:51:13 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:13 --> Helper loaded: date_helper
INFO - 26.06.2025 11:51:13 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:51:13 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:13 --> Helper loaded: form_helper
INFO - 26.06.2025 11:51:13 --> Form Validation Class Initialized
INFO - 26.06.2025 11:51:13 --> Upload Class Initialized
INFO - 26.06.2025 11:51:13 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:51:13 --> Pagination Class Initialized
INFO - 26.06.2025 11:51:13 --> Controller Class Initialized
INFO - 26.06.2025 11:51:13 --> Model "App_model" initialized
INFO - 26.06.2025 11:51:13 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:51:13 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/ueber-styx_section_1_1750938549.jpg
ERROR - 26.06.2025 11:51:13 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:51:13 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:51:13 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:51:13 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:51:13 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:51:13 --> Final output sent to browser
DEBUG - 26.06.2025 11:51:13 --> Total execution time: 1.3229
INFO - 26.06.2025 11:51:13 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:51:13 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:51:14 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:51:14 --> Email Class Initialized
INFO - 26.06.2025 11:51:14 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:51:14 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:51:14 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:14 --> Helper loaded: date_helper
INFO - 26.06.2025 11:51:14 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:14 --> Helper loaded: form_helper
INFO - 26.06.2025 11:51:14 --> Form Validation Class Initialized
INFO - 26.06.2025 11:51:14 --> Upload Class Initialized
INFO - 26.06.2025 11:51:14 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:51:14 --> Pagination Class Initialized
INFO - 26.06.2025 11:51:14 --> Controller Class Initialized
INFO - 26.06.2025 11:51:14 --> Model "App_model" initialized
INFO - 26.06.2025 11:51:14 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:51:14 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
ERROR - 26.06.2025 11:51:14 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:51:14 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:51:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:51:14 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:51:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:51:14 --> Final output sent to browser
DEBUG - 26.06.2025 11:51:14 --> Total execution time: 1.7251
INFO - 26.06.2025 11:51:14 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:51:14 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:51:14 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:51:14 --> Email Class Initialized
INFO - 26.06.2025 11:51:14 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:51:14 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:51:14 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:14 --> Helper loaded: date_helper
INFO - 26.06.2025 11:51:14 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:14 --> Helper loaded: form_helper
INFO - 26.06.2025 11:51:14 --> Form Validation Class Initialized
INFO - 26.06.2025 11:51:14 --> Upload Class Initialized
INFO - 26.06.2025 11:51:14 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:51:14 --> Pagination Class Initialized
INFO - 26.06.2025 11:51:14 --> Controller Class Initialized
INFO - 26.06.2025 11:51:14 --> Model "App_model" initialized
INFO - 26.06.2025 11:51:14 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:51:14 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/aroma_derm_folder_1.jpg
ERROR - 26.06.2025 11:51:14 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:51:14 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:51:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:51:14 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:51:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:51:14 --> Final output sent to browser
DEBUG - 26.06.2025 11:51:14 --> Total execution time: 2.1830
INFO - 26.06.2025 11:51:14 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:51:14 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:51:14 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:51:14 --> Email Class Initialized
INFO - 26.06.2025 11:51:14 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:51:14 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:51:14 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:14 --> Helper loaded: date_helper
INFO - 26.06.2025 11:51:14 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:51:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:14 --> Helper loaded: form_helper
INFO - 26.06.2025 11:51:14 --> Form Validation Class Initialized
INFO - 26.06.2025 11:51:14 --> Upload Class Initialized
INFO - 26.06.2025 11:51:14 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:51:14 --> Pagination Class Initialized
INFO - 26.06.2025 11:51:14 --> Controller Class Initialized
INFO - 26.06.2025 11:51:14 --> Model "App_model" initialized
INFO - 26.06.2025 11:51:14 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:51:15 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/ueber-styx_section_2_1750938494.jpg
ERROR - 26.06.2025 11:51:15 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:51:15 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:51:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:51:15 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:51:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:51:15 --> Final output sent to browser
DEBUG - 26.06.2025 11:51:15 --> Total execution time: 2.6216
INFO - 26.06.2025 11:51:50 --> Config Class Initialized
INFO - 26.06.2025 11:51:50 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:51:50 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:51:50 --> Utf8 Class Initialized
INFO - 26.06.2025 11:51:50 --> URI Class Initialized
INFO - 26.06.2025 11:51:50 --> Router Class Initialized
INFO - 26.06.2025 11:51:50 --> Output Class Initialized
INFO - 26.06.2025 11:51:50 --> Security Class Initialized
DEBUG - 26.06.2025 11:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:51:50 --> Input Class Initialized
INFO - 26.06.2025 11:51:50 --> Language Class Initialized
INFO - 26.06.2025 11:51:50 --> Loader Class Initialized
INFO - 26.06.2025 11:51:50 --> Helper loaded: app_helper
INFO - 26.06.2025 11:51:50 --> Helper loaded: language_helper
INFO - 26.06.2025 11:51:50 --> Helper loaded: text_helper
INFO - 26.06.2025 11:51:50 --> Helper loaded: string_helper
INFO - 26.06.2025 11:51:50 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:51:50 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:51:50 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:51:51 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:51:51 --> Email Class Initialized
INFO - 26.06.2025 11:51:51 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:51:51 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:51:51 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:51:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:51 --> Helper loaded: date_helper
INFO - 26.06.2025 11:51:51 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:51:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:51 --> Helper loaded: form_helper
INFO - 26.06.2025 11:51:51 --> Form Validation Class Initialized
INFO - 26.06.2025 11:51:51 --> Upload Class Initialized
INFO - 26.06.2025 11:51:51 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:51:51 --> Pagination Class Initialized
INFO - 26.06.2025 11:51:51 --> Controller Class Initialized
INFO - 26.06.2025 11:51:51 --> Model "Article_model" initialized
INFO - 26.06.2025 11:51:51 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:51:51 --> Image Lib Class Initialized
INFO - 26.06.2025 11:51:51 --> Final output sent to browser
DEBUG - 26.06.2025 11:51:51 --> Total execution time: 0.2310
INFO - 26.06.2025 11:51:51 --> Config Class Initialized
INFO - 26.06.2025 11:51:51 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:51:51 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:51:51 --> Utf8 Class Initialized
INFO - 26.06.2025 11:51:51 --> URI Class Initialized
INFO - 26.06.2025 11:51:51 --> Router Class Initialized
INFO - 26.06.2025 11:51:51 --> Output Class Initialized
INFO - 26.06.2025 11:51:51 --> Security Class Initialized
DEBUG - 26.06.2025 11:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:51:51 --> Input Class Initialized
INFO - 26.06.2025 11:51:51 --> Language Class Initialized
INFO - 26.06.2025 11:51:51 --> Loader Class Initialized
INFO - 26.06.2025 11:51:51 --> Helper loaded: app_helper
INFO - 26.06.2025 11:51:51 --> Helper loaded: language_helper
INFO - 26.06.2025 11:51:51 --> Helper loaded: text_helper
INFO - 26.06.2025 11:51:51 --> Helper loaded: string_helper
INFO - 26.06.2025 11:51:51 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:51:51 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:51:51 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:51:52 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:51:52 --> Email Class Initialized
INFO - 26.06.2025 11:51:52 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:51:52 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:51:52 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:52 --> Helper loaded: date_helper
INFO - 26.06.2025 11:51:52 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:51:52 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:52 --> Helper loaded: form_helper
INFO - 26.06.2025 11:51:52 --> Form Validation Class Initialized
INFO - 26.06.2025 11:51:52 --> Upload Class Initialized
INFO - 26.06.2025 11:51:52 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:51:52 --> Pagination Class Initialized
INFO - 26.06.2025 11:51:52 --> Controller Class Initialized
INFO - 26.06.2025 11:51:52 --> Model "Ftpmanager_model" initialized
INFO - 26.06.2025 11:51:55 --> Final output sent to browser
DEBUG - 26.06.2025 11:51:55 --> Total execution time: 3.4594
INFO - 26.06.2025 11:51:58 --> Config Class Initialized
INFO - 26.06.2025 11:51:58 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:51:58 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:51:58 --> Utf8 Class Initialized
INFO - 26.06.2025 11:51:58 --> URI Class Initialized
INFO - 26.06.2025 11:51:58 --> Router Class Initialized
INFO - 26.06.2025 11:51:58 --> Output Class Initialized
INFO - 26.06.2025 11:51:58 --> Security Class Initialized
DEBUG - 26.06.2025 11:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:51:58 --> Input Class Initialized
INFO - 26.06.2025 11:51:58 --> Language Class Initialized
INFO - 26.06.2025 11:51:58 --> Loader Class Initialized
INFO - 26.06.2025 11:51:58 --> Helper loaded: app_helper
INFO - 26.06.2025 11:51:58 --> Helper loaded: language_helper
INFO - 26.06.2025 11:51:58 --> Helper loaded: text_helper
INFO - 26.06.2025 11:51:58 --> Helper loaded: string_helper
INFO - 26.06.2025 11:51:58 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:51:58 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:51:58 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:51:58 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:51:58 --> Email Class Initialized
INFO - 26.06.2025 11:51:58 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:51:58 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:51:58 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:58 --> Helper loaded: date_helper
INFO - 26.06.2025 11:51:58 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:51:58 --> Helper loaded: form_helper
INFO - 26.06.2025 11:51:58 --> Form Validation Class Initialized
INFO - 26.06.2025 11:51:58 --> Upload Class Initialized
INFO - 26.06.2025 11:51:58 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:51:58 --> Pagination Class Initialized
INFO - 26.06.2025 11:51:58 --> Controller Class Initialized
INFO - 26.06.2025 11:51:58 --> Model "Ftpmanager_model" initialized
INFO - 26.06.2025 11:52:00 --> Final output sent to browser
DEBUG - 26.06.2025 11:52:00 --> Total execution time: 2.8718
INFO - 26.06.2025 11:52:03 --> Config Class Initialized
INFO - 26.06.2025 11:52:03 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:52:03 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:52:03 --> Utf8 Class Initialized
INFO - 26.06.2025 11:52:03 --> URI Class Initialized
INFO - 26.06.2025 11:52:03 --> Router Class Initialized
INFO - 26.06.2025 11:52:03 --> Output Class Initialized
INFO - 26.06.2025 11:52:03 --> Security Class Initialized
DEBUG - 26.06.2025 11:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:52:03 --> Input Class Initialized
INFO - 26.06.2025 11:52:03 --> Language Class Initialized
INFO - 26.06.2025 11:52:03 --> Loader Class Initialized
INFO - 26.06.2025 11:52:03 --> Helper loaded: app_helper
INFO - 26.06.2025 11:52:03 --> Helper loaded: language_helper
INFO - 26.06.2025 11:52:03 --> Helper loaded: text_helper
INFO - 26.06.2025 11:52:03 --> Helper loaded: string_helper
INFO - 26.06.2025 11:52:03 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:52:03 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:52:03 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:52:03 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:52:03 --> Email Class Initialized
INFO - 26.06.2025 11:52:03 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:52:03 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:52:03 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:03 --> Helper loaded: date_helper
INFO - 26.06.2025 11:52:03 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:52:03 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:03 --> Helper loaded: form_helper
INFO - 26.06.2025 11:52:03 --> Form Validation Class Initialized
INFO - 26.06.2025 11:52:03 --> Upload Class Initialized
INFO - 26.06.2025 11:52:03 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:52:03 --> Pagination Class Initialized
INFO - 26.06.2025 11:52:03 --> Controller Class Initialized
INFO - 26.06.2025 11:52:03 --> Model "Ftpmanager_model" initialized
INFO - 26.06.2025 11:52:06 --> Final output sent to browser
DEBUG - 26.06.2025 11:52:06 --> Total execution time: 3.1710
INFO - 26.06.2025 11:52:10 --> Config Class Initialized
INFO - 26.06.2025 11:52:10 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:52:10 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:52:10 --> Utf8 Class Initialized
INFO - 26.06.2025 11:52:10 --> URI Class Initialized
INFO - 26.06.2025 11:52:10 --> Router Class Initialized
INFO - 26.06.2025 11:52:10 --> Output Class Initialized
INFO - 26.06.2025 11:52:10 --> Security Class Initialized
DEBUG - 26.06.2025 11:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:52:10 --> Input Class Initialized
INFO - 26.06.2025 11:52:10 --> Language Class Initialized
INFO - 26.06.2025 11:52:10 --> Loader Class Initialized
INFO - 26.06.2025 11:52:10 --> Helper loaded: app_helper
INFO - 26.06.2025 11:52:10 --> Helper loaded: language_helper
INFO - 26.06.2025 11:52:10 --> Helper loaded: text_helper
INFO - 26.06.2025 11:52:10 --> Helper loaded: string_helper
INFO - 26.06.2025 11:52:10 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:52:10 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:52:10 --> Database Driver Class Initialized
INFO - 26.06.2025 11:52:10 --> Config Class Initialized
INFO - 26.06.2025 11:52:10 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:52:10 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:52:10 --> Utf8 Class Initialized
INFO - 26.06.2025 11:52:10 --> URI Class Initialized
INFO - 26.06.2025 11:52:10 --> Router Class Initialized
INFO - 26.06.2025 11:52:10 --> Output Class Initialized
INFO - 26.06.2025 11:52:10 --> Security Class Initialized
DEBUG - 26.06.2025 11:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:52:10 --> Input Class Initialized
INFO - 26.06.2025 11:52:10 --> Language Class Initialized
INFO - 26.06.2025 11:52:10 --> Loader Class Initialized
INFO - 26.06.2025 11:52:10 --> Helper loaded: app_helper
INFO - 26.06.2025 11:52:10 --> Helper loaded: language_helper
INFO - 26.06.2025 11:52:10 --> Helper loaded: text_helper
INFO - 26.06.2025 11:52:10 --> Helper loaded: string_helper
INFO - 26.06.2025 11:52:10 --> Language file loaded: language/german/app_lang.php
DEBUG - 26.06.2025 11:52:10 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:52:10 --> Email Class Initialized
INFO - 26.06.2025 11:52:10 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:52:10 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:52:10 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:52:10 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:10 --> Helper loaded: date_helper
INFO - 26.06.2025 11:52:10 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:52:10 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:10 --> Helper loaded: form_helper
INFO - 26.06.2025 11:52:10 --> Form Validation Class Initialized
INFO - 26.06.2025 11:52:10 --> Upload Class Initialized
INFO - 26.06.2025 11:52:10 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:52:10 --> Pagination Class Initialized
INFO - 26.06.2025 11:52:10 --> Controller Class Initialized
INFO - 26.06.2025 11:52:10 --> Model "App_model" initialized
INFO - 26.06.2025 11:52:10 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:52:10 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
ERROR - 26.06.2025 11:52:10 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:52:10 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:52:10 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:52:10 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:52:11 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:52:11 --> Final output sent to browser
DEBUG - 26.06.2025 11:52:11 --> Total execution time: 0.4751
INFO - 26.06.2025 11:52:11 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:52:11 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:52:11 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:52:11 --> Email Class Initialized
INFO - 26.06.2025 11:52:11 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:52:11 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:52:11 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:52:11 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:11 --> Helper loaded: date_helper
INFO - 26.06.2025 11:52:11 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:52:11 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:11 --> Helper loaded: form_helper
INFO - 26.06.2025 11:52:11 --> Form Validation Class Initialized
INFO - 26.06.2025 11:52:11 --> Upload Class Initialized
INFO - 26.06.2025 11:52:11 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:52:11 --> Pagination Class Initialized
INFO - 26.06.2025 11:52:11 --> Controller Class Initialized
INFO - 26.06.2025 11:52:11 --> Model "Article_model" initialized
INFO - 26.06.2025 11:52:11 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:52:11 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:52:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:52:11 --> Received POST data in articlesSave: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => uploads/articles/title_image/ueber-styx.jpg
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [1] => <p>klôjklôjklôjklôjklô</p>
            [2] => <p>jklôjklôjklôjklôjklôjklô<br><br><br></p>
            [3] => <p>rurtzurtzurtzurbt zu<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/styx_gelaende_990x990_1750938711.jpg" style="font-family: Poppins; width: 990px;"><br></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
            [1] => 
            [2] => 
            [3] => 
        )

    [ftp_section_image] => Array
        (
            [0] => 
            [1] => 
            [2] => 
            [3] => https://styx.styxnatur.at/uploads/news/1b204f426ca7ef4bae070616b1f517e5.jpg
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0_1750938549.jpg
            [1] => uploads/articles/sections/ueber-styx_section_1_1750938549.jpg
            [2] => uploads/articles/sections/ueber-styx_section_2_1750938494.jpg
            [3] => uploads/articles/sections/aroma_derm_folder_1.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
            [1] => 
            [2] => 
            [3] => 
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
)

DEBUG - 26.06.2025 11:52:11 --> Processed sections: Array
(
    [0] => Array
        (
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => 
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [external_url] => 
        )

    [1] => Array
        (
            [content] => <p>klôjklôjklôjklôjklô</p>
            [image] => 
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

    [2] => Array
        (
            [content] => <p>jklôjklôjklôjklôjklôjklô<br><br><br></p>
            [image] => 
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

    [3] => Array
        (
            [content] => <p>rurtzurtzurtzurbt zu<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/styx_gelaende_990x990_1750938711.jpg" style="font-family: Poppins; width: 990px;"><br></p>
            [image] => https://styx.styxnatur.at/uploads/news/1b204f426ca7ef4bae070616b1f517e5.jpg
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [external_url] => 
        )

)

DEBUG - 26.06.2025 11:52:11 --> Starting saveArticle with post data: Array
(
    [id] => 46
    [category_id] => 89
    [lang] => de
    [title] => Über STYX
    [subtitle] => Traditionelles Familienunternehmen seit 1965 – im Herzen Niederösterreichs
    [category_name] => Über STYX
    [slug_display] => https://www.styx.at/de/Unternehmen/ueber-styx
    [slug] => de/Unternehmen/ueber-styx
    [is_main] => 1
    [image_title] => 
    [old_image] => uploads/articles/title_image/ueber-styx.jpg
    [ftp_image] => 
    [sections] => Array
        (
            [0] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [1] => <p>klôjklôjklôjklôjklô</p>
            [2] => <p>jklôjklôjklôjklôjklôjklô<br><br><br></p>
            [3] => <p>rurtzurtzurtzurbt zu<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/styx_gelaende_990x990_1750938711.jpg" style="font-family: Poppins; width: 990px;"><br></p>
        )

    [section_image_titles] => Array
        (
            [0] => Geschaeftsfuehrung_Wolfgang_Stix
            [1] => 
            [2] => 
            [3] => 
        )

    [ftp_section_image] => Array
        (
            [0] => 
            [1] => 
            [2] => 
            [3] => https://styx.styxnatur.at/uploads/news/1b204f426ca7ef4bae070616b1f517e5.jpg
        )

    [old_section_image] => Array
        (
            [0] => uploads/articles/sections/ueber-styx_section_0_1750938549.jpg
            [1] => uploads/articles/sections/ueber-styx_section_1_1750938549.jpg
            [2] => uploads/articles/sections/ueber-styx_section_2_1750938494.jpg
            [3] => uploads/articles/sections/aroma_derm_folder_1.jpg
        )

    [button_names] => Array
        (
            [0] => lokfff
            [1] => 
            [2] => 
            [3] => 
        )

    [subpages] => Array
        (
            [0] => 
        )

    [external_urls] => Array
        (
            [0] => 
        )

    [keywords] => Wolfgang Stix, STYX, Naturcosmetic, naturkosmetik, Ober-Grafendorf, Familienunternehmen
    [meta] => Traditionelles Familienunternehmen seit 1965 im Herzen Niederösterreichs
    [empfohlen_name1] => 
    [empfohlen_url1] => 
    [empfohlen_name2] => 
    [empfohlen_url2] => 
    [empfohlen_name3] => 
    [empfohlen_url3] => 
    [gallery_category_id] => 
    [gallery_id] => 
    [start_date_from] => 
    [end_date_to] => 
    [orderBy] => 0
    [active] => 1
    [image] => 
    [sections_data] => Array
        (
            [0] => Array
                (
                    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
                    [image] => 
                    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
                    [button_name] => lokfff
                    [subpage] => 
                    [external_url] => 
                )

            [1] => Array
                (
                    [content] => <p>klôjklôjklôjklôjklô</p>
                    [image] => 
                    [image_title] => 
                    [button_name] => 
                    [subpage] => 
                    [external_url] => 
                )

            [2] => Array
                (
                    [content] => <p>jklôjklôjklôjklôjklôjklô<br><br><br></p>
                    [image] => 
                    [image_title] => 
                    [button_name] => 
                    [subpage] => 
                    [external_url] => 
                )

            [3] => Array
                (
                    [content] => <p>rurtzurtzurtzurbt zu<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/styx_gelaende_990x990_1750938711.jpg" style="font-family: Poppins; width: 990px;"><br></p>
                    [image] => https://styx.styxnatur.at/uploads/news/1b204f426ca7ef4bae070616b1f517e5.jpg
                    [image_title] => 
                    [button_name] => 
                    [subpage] => 
                    [external_url] => 
                )

        )

)

INFO - 26.06.2025 11:52:11 --> Image Lib Class Initialized
DEBUG - 26.06.2025 11:52:11 --> Processing section image upload for index 0: herr_styx.jpg
DEBUG - 26.06.2025 11:52:11 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:52:11 --> Section image uploaded successfully for index 0: uploads/articles/sections/ueber-styx_section_0_1750938731.jpg
DEBUG - 26.06.2025 11:52:11 --> Inserting section 0: Array
(
    [article_id] => 46
    [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
    [image] => uploads/articles/sections/ueber-styx_section_0_1750938731.jpg
    [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
    [button_name] => lokfff
    [subpage] => 
    [external_url] => 
    [order] => 0
)

DEBUG - 26.06.2025 11:52:11 --> Processing section image upload for index 1: green_brands_2022_2023_styx_naturcosmetic_1750934029.jpg
DEBUG - 26.06.2025 11:52:11 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:52:11 --> Section image uploaded successfully for index 1: uploads/articles/sections/ueber-styx_section_1_1750938731.jpg
DEBUG - 26.06.2025 11:52:11 --> Inserting section 1: Array
(
    [article_id] => 46
    [content] => <p>klôjklôjklôjklôjklô</p>
    [image] => uploads/articles/sections/ueber-styx_section_1_1750938731.jpg
    [image_title] => 
    [button_name] => 
    [subpage] => 
    [external_url] => 
    [order] => 1
)

DEBUG - 26.06.2025 11:52:11 --> Processing section image upload for index 2: Aloe Vera Produkte.jpg
DEBUG - 26.06.2025 11:52:11 --> Image_lib class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:52:11 --> Section image uploaded successfully for index 2: uploads/articles/sections/ueber-styx_section_2_1750938731.jpg
DEBUG - 26.06.2025 11:52:11 --> Inserting section 2: Array
(
    [article_id] => 46
    [content] => <p>jklôjklôjklôjklôjklôjklô<br><br><br></p>
    [image] => uploads/articles/sections/ueber-styx_section_2_1750938731.jpg
    [image_title] => 
    [button_name] => 
    [subpage] => 
    [external_url] => 
    [order] => 2
)

DEBUG - 26.06.2025 11:52:11 --> Inserting section 3: Array
(
    [article_id] => 46
    [content] => <p>rurtzurtzurtzurbt zu<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/styx_gelaende_990x990_1750938711.jpg" style="font-family: Poppins; width: 990px;"><br></p>
    [image] => uploads/articles/sections/aroma_derm_folder_1.jpg
    [image_title] => 
    [button_name] => 
    [subpage] => 
    [external_url] => 
    [order] => 3
)

INFO - 26.06.2025 11:52:11 --> Config Class Initialized
INFO - 26.06.2025 11:52:11 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:52:11 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:52:11 --> Utf8 Class Initialized
INFO - 26.06.2025 11:52:11 --> URI Class Initialized
INFO - 26.06.2025 11:52:11 --> Router Class Initialized
INFO - 26.06.2025 11:52:11 --> Output Class Initialized
INFO - 26.06.2025 11:52:11 --> Security Class Initialized
DEBUG - 26.06.2025 11:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:52:11 --> Input Class Initialized
INFO - 26.06.2025 11:52:11 --> Language Class Initialized
INFO - 26.06.2025 11:52:11 --> Loader Class Initialized
INFO - 26.06.2025 11:52:11 --> Helper loaded: app_helper
INFO - 26.06.2025 11:52:11 --> Helper loaded: language_helper
INFO - 26.06.2025 11:52:11 --> Helper loaded: text_helper
INFO - 26.06.2025 11:52:11 --> Helper loaded: string_helper
INFO - 26.06.2025 11:52:11 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:52:11 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:52:11 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:52:12 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:52:12 --> Email Class Initialized
INFO - 26.06.2025 11:52:12 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:52:12 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:52:12 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:52:12 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:12 --> Helper loaded: date_helper
INFO - 26.06.2025 11:52:12 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:52:12 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:12 --> Helper loaded: form_helper
INFO - 26.06.2025 11:52:12 --> Form Validation Class Initialized
INFO - 26.06.2025 11:52:12 --> Upload Class Initialized
INFO - 26.06.2025 11:52:12 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:52:12 --> Pagination Class Initialized
INFO - 26.06.2025 11:52:12 --> Controller Class Initialized
INFO - 26.06.2025 11:52:12 --> Model "Article_model" initialized
INFO - 26.06.2025 11:52:12 --> Model "Admin_model" initialized
DEBUG - 26.06.2025 11:52:12 --> Pagination class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/articles.php
INFO - 26.06.2025 11:52:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:52:12 --> Final output sent to browser
DEBUG - 26.06.2025 11:52:12 --> Total execution time: 0.4094
INFO - 26.06.2025 11:52:13 --> Config Class Initialized
INFO - 26.06.2025 11:52:13 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:52:13 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:52:13 --> Utf8 Class Initialized
INFO - 26.06.2025 11:52:13 --> URI Class Initialized
INFO - 26.06.2025 11:52:13 --> Router Class Initialized
INFO - 26.06.2025 11:52:13 --> Output Class Initialized
INFO - 26.06.2025 11:52:13 --> Security Class Initialized
DEBUG - 26.06.2025 11:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:52:13 --> Input Class Initialized
INFO - 26.06.2025 11:52:13 --> Language Class Initialized
INFO - 26.06.2025 11:52:13 --> Loader Class Initialized
INFO - 26.06.2025 11:52:13 --> Helper loaded: app_helper
INFO - 26.06.2025 11:52:13 --> Helper loaded: language_helper
INFO - 26.06.2025 11:52:13 --> Helper loaded: text_helper
INFO - 26.06.2025 11:52:13 --> Helper loaded: string_helper
INFO - 26.06.2025 11:52:13 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:52:13 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:52:13 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:52:14 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:52:14 --> Email Class Initialized
INFO - 26.06.2025 11:52:14 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:52:14 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:52:14 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:14 --> Helper loaded: date_helper
INFO - 26.06.2025 11:52:14 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:14 --> Helper loaded: form_helper
INFO - 26.06.2025 11:52:14 --> Form Validation Class Initialized
INFO - 26.06.2025 11:52:14 --> Upload Class Initialized
INFO - 26.06.2025 11:52:14 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:52:14 --> Pagination Class Initialized
INFO - 26.06.2025 11:52:14 --> Controller Class Initialized
INFO - 26.06.2025 11:52:14 --> Model "Article_model" initialized
INFO - 26.06.2025 11:52:14 --> Model "Admin_model" initialized
INFO - 26.06.2025 11:52:14 --> Model "Gallery_model" initialized
DEBUG - 26.06.2025 11:52:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 26.06.2025 11:52:14 --> Fetched sections for article 46: Array
(
    [0] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <h2 style="font-family: Poppins; border-radius: 0px;" open="" sans",="" arial,="" sans-serif;="" line-height:="" 33px;="" color:="" rgb(26,="" 26,="" 26);="" margin-top:="" 5px;="" font-size:="" 24px;="" text-shadow:="" none;="" letter-spacing:="" normal;"=""><b>Hand in Hand mit der Natur</b></h2><p style="font-family: Poppins; border-radius: 0px; margin-bottom: 10px; color: rgb(26, 26, 26); font-size: 16px;" open="" sans",="" sans-serif;"="">Inmitten geschwungener Hügel und grüner Wiesen erstreckt sich das niederösterreichische Pielachtal. Ein ruhiger und beschaulicher Ort, der zum Verweilen und Träumen einlädt. Zugleich ein Ort, der die Herzen all derjenigen erfreut, die sich für naturkosmetische Pflege begeistern. Hier im Innern dieser einladenden Landschaft liegt Ober-Grafendorf und Kundige wissen, dort findet sich ein Platz ganz besonderer Art. Dort, wo sich Tradition und Moderne vereinen, liegt die Heimat von STYX Naturcosmetic.<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg" style="font-family: Poppins; width: 1089.22px;"><br><br><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">Seit 1965 und damit seit 60 Jahren widmet sich das österreichische Familienunternehmen mit mittlerweile rund 60 Mitarbeitern der Herstellung von&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/naturkosmetik" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Naturkosmetik</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">. Was sich nach erfahrungsreichem Handwerk anhört, ist bei STYX Naturcosmetic noch weit mehr. Für uns führt der Prozess, in dessen Verlauf Naturkosmetik entsteht über das Handwerkliche hinaus. Für den, der wahre Naturkosmetik erzeugen will, in der sich&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Philosophie</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"=""><a href="https://www.styx.at/de/Unternehmen/nachhaltigkeit-philosophie" target="_blank">,</a>&nbsp;</span><a href="https://www.styx.at/de/Unternehmen/zertifizierungen" style="font-family: Poppins; border-radius: 0px; color: rgb(114, 192, 44); text-decoration-line: underline;" open="" sans",="" sans-serif;="" outline-style:="" initial="" !important;="" outline-width:="" 0px="" !important;"="" target="_blank">Qualität</a><span style="font-family: Poppins;" open="" sans",="" sans-serif;"="">&nbsp;und Leidenschaft des Unternehmens spiegeln, bedeutet dieser Prozess nicht nur Handwerk, sondern Kunst. Die Kunst einer unvergleichlichen natürlichen Pflege.</span></p>
            [image] => uploads/articles/sections/ueber-styx_section_0_1750938731.jpg
            [order] => 0
            [image_title] => Geschaeftsfuehrung_Wolfgang_Stix
            [button_name] => lokfff
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [1] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>klôjklôjklôjklôjklô</p>
            [image] => uploads/articles/sections/ueber-styx_section_1_1750938731.jpg
            [order] => 1
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [2] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>jklôjklôjklôjklôjklôjklô<br><br><br></p>
            [image] => uploads/articles/sections/ueber-styx_section_2_1750938731.jpg
            [order] => 2
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

    [3] => stdClass Object
        (
            [id] => 0
            [article_id] => 46
            [content] => <p>rurtzurtzurtzurbt zu<br><br><img src="http://localhost/STYX_web/uploads/articles/summernote/styx_gelaende_990x990_1750938711.jpg" style="font-family: Poppins; width: 990px;"><br></p>
            [image] => uploads/articles/sections/aroma_derm_folder_1.jpg
            [order] => 3
            [image_title] => 
            [button_name] => 
            [subpage] => 
            [article_link] => 
            [external_url] => 
        )

)

INFO - 26.06.2025 11:52:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/ftp_modal.php
INFO - 26.06.2025 11:52:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_products_dynamic.php
INFO - 26.06.2025 11:52:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/settings/article_form.php
INFO - 26.06.2025 11:52:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 26.06.2025 11:52:14 --> Final output sent to browser
DEBUG - 26.06.2025 11:52:14 --> Total execution time: 0.5518
INFO - 26.06.2025 11:52:14 --> Config Class Initialized
INFO - 26.06.2025 11:52:14 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:52:14 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:52:14 --> Utf8 Class Initialized
INFO - 26.06.2025 11:52:14 --> URI Class Initialized
INFO - 26.06.2025 11:52:14 --> Config Class Initialized
INFO - 26.06.2025 11:52:14 --> Hooks Class Initialized
INFO - 26.06.2025 11:52:14 --> Router Class Initialized
DEBUG - 26.06.2025 11:52:14 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:52:14 --> Utf8 Class Initialized
INFO - 26.06.2025 11:52:14 --> Output Class Initialized
INFO - 26.06.2025 11:52:14 --> URI Class Initialized
INFO - 26.06.2025 11:52:14 --> Security Class Initialized
INFO - 26.06.2025 11:52:14 --> Router Class Initialized
DEBUG - 26.06.2025 11:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:52:14 --> Input Class Initialized
INFO - 26.06.2025 11:52:14 --> Language Class Initialized
INFO - 26.06.2025 11:52:14 --> Output Class Initialized
INFO - 26.06.2025 11:52:14 --> Security Class Initialized
DEBUG - 26.06.2025 11:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:52:14 --> Input Class Initialized
INFO - 26.06.2025 11:52:14 --> Language Class Initialized
INFO - 26.06.2025 11:52:14 --> Loader Class Initialized
INFO - 26.06.2025 11:52:14 --> Helper loaded: app_helper
INFO - 26.06.2025 11:52:14 --> Helper loaded: language_helper
INFO - 26.06.2025 11:52:14 --> Loader Class Initialized
INFO - 26.06.2025 11:52:14 --> Helper loaded: app_helper
INFO - 26.06.2025 11:52:14 --> Helper loaded: language_helper
INFO - 26.06.2025 11:52:14 --> Helper loaded: text_helper
INFO - 26.06.2025 11:52:14 --> Helper loaded: string_helper
INFO - 26.06.2025 11:52:14 --> Helper loaded: text_helper
INFO - 26.06.2025 11:52:14 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:52:14 --> Helper loaded: string_helper
INFO - 26.06.2025 11:52:14 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:52:14 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:52:14 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:52:14 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:52:14 --> Email Class Initialized
INFO - 26.06.2025 11:52:14 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:52:14 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:52:14 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:14 --> Helper loaded: date_helper
INFO - 26.06.2025 11:52:14 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:52:14 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:14 --> Helper loaded: form_helper
INFO - 26.06.2025 11:52:14 --> Form Validation Class Initialized
INFO - 26.06.2025 11:52:14 --> Upload Class Initialized
INFO - 26.06.2025 11:52:14 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:52:14 --> Pagination Class Initialized
INFO - 26.06.2025 11:52:14 --> Controller Class Initialized
INFO - 26.06.2025 11:52:14 --> Model "App_model" initialized
INFO - 26.06.2025 11:52:14 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:52:15 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/sections/aroma_derm_folder_1.jpg
ERROR - 26.06.2025 11:52:15 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:52:15 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:52:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:52:15 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:52:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:52:15 --> Final output sent to browser
DEBUG - 26.06.2025 11:52:15 --> Total execution time: 0.5759
INFO - 26.06.2025 11:52:15 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:52:15 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:52:15 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:52:15 --> Email Class Initialized
INFO - 26.06.2025 11:52:15 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:52:15 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:52:15 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:15 --> Helper loaded: date_helper
INFO - 26.06.2025 11:52:15 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:52:15 --> Helper loaded: form_helper
INFO - 26.06.2025 11:52:15 --> Form Validation Class Initialized
INFO - 26.06.2025 11:52:15 --> Upload Class Initialized
INFO - 26.06.2025 11:52:15 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:52:15 --> Pagination Class Initialized
INFO - 26.06.2025 11:52:15 --> Controller Class Initialized
INFO - 26.06.2025 11:52:15 --> Model "App_model" initialized
INFO - 26.06.2025 11:52:15 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:52:15 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
ERROR - 26.06.2025 11:52:15 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:52:15 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:52:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:52:15 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:52:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:52:15 --> Final output sent to browser
DEBUG - 26.06.2025 11:52:15 --> Total execution time: 1.0543
INFO - 26.06.2025 11:53:51 --> Config Class Initialized
INFO - 26.06.2025 11:53:51 --> Config Class Initialized
INFO - 26.06.2025 11:53:51 --> Hooks Class Initialized
INFO - 26.06.2025 11:53:51 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:53:51 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:53:51 --> Utf8 Class Initialized
DEBUG - 26.06.2025 11:53:51 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:53:51 --> Utf8 Class Initialized
INFO - 26.06.2025 11:53:51 --> URI Class Initialized
INFO - 26.06.2025 11:53:51 --> URI Class Initialized
INFO - 26.06.2025 11:53:51 --> Router Class Initialized
INFO - 26.06.2025 11:53:51 --> Router Class Initialized
INFO - 26.06.2025 11:53:51 --> Output Class Initialized
INFO - 26.06.2025 11:53:51 --> Output Class Initialized
INFO - 26.06.2025 11:53:51 --> Security Class Initialized
INFO - 26.06.2025 11:53:51 --> Security Class Initialized
DEBUG - 26.06.2025 11:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 26.06.2025 11:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:53:51 --> Input Class Initialized
INFO - 26.06.2025 11:53:51 --> Input Class Initialized
INFO - 26.06.2025 11:53:51 --> Language Class Initialized
INFO - 26.06.2025 11:53:51 --> Language Class Initialized
INFO - 26.06.2025 11:53:51 --> Loader Class Initialized
INFO - 26.06.2025 11:53:51 --> Loader Class Initialized
INFO - 26.06.2025 11:53:51 --> Helper loaded: app_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: language_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: app_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: language_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: text_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: text_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: string_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: string_helper
INFO - 26.06.2025 11:53:51 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:53:51 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:53:51 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:53:51 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:53:51 --> Database Driver Class Initialized
INFO - 26.06.2025 11:53:51 --> Database Driver Class Initialized
INFO - 26.06.2025 11:53:51 --> Config Class Initialized
INFO - 26.06.2025 11:53:51 --> Hooks Class Initialized
INFO - 26.06.2025 11:53:51 --> Config Class Initialized
INFO - 26.06.2025 11:53:51 --> Hooks Class Initialized
DEBUG - 26.06.2025 11:53:51 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:53:51 --> Utf8 Class Initialized
DEBUG - 26.06.2025 11:53:51 --> UTF-8 Support Enabled
INFO - 26.06.2025 11:53:51 --> Utf8 Class Initialized
INFO - 26.06.2025 11:53:51 --> URI Class Initialized
INFO - 26.06.2025 11:53:51 --> URI Class Initialized
INFO - 26.06.2025 11:53:51 --> Router Class Initialized
INFO - 26.06.2025 11:53:51 --> Router Class Initialized
INFO - 26.06.2025 11:53:51 --> Output Class Initialized
INFO - 26.06.2025 11:53:51 --> Output Class Initialized
INFO - 26.06.2025 11:53:51 --> Security Class Initialized
INFO - 26.06.2025 11:53:51 --> Security Class Initialized
DEBUG - 26.06.2025 11:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:53:51 --> Input Class Initialized
DEBUG - 26.06.2025 11:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 11:53:51 --> Input Class Initialized
INFO - 26.06.2025 11:53:51 --> Language Class Initialized
INFO - 26.06.2025 11:53:51 --> Language Class Initialized
INFO - 26.06.2025 11:53:51 --> Loader Class Initialized
INFO - 26.06.2025 11:53:51 --> Loader Class Initialized
INFO - 26.06.2025 11:53:51 --> Helper loaded: app_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: app_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: language_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: language_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: text_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: text_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: string_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: string_helper
INFO - 26.06.2025 11:53:51 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:53:51 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 11:53:51 --> Session: Class initialized using 'files' driver.
DEBUG - 26.06.2025 11:53:51 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:53:51 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 11:53:51 --> Email Class Initialized
INFO - 26.06.2025 11:53:51 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:53:51 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:53:51 --> Database Driver Class Initialized
INFO - 26.06.2025 11:53:51 --> Database Driver Class Initialized
DEBUG - 26.06.2025 11:53:51 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:53:51 --> Email Class Initialized
INFO - 26.06.2025 11:53:51 --> Helper loaded: date_helper
INFO - 26.06.2025 11:53:51 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:53:51 --> Model "Ion_auth_model" initialized
INFO - 26.06.2025 11:53:51 --> Helper loaded: cookie_helper
DEBUG - 26.06.2025 11:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:53:51 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:53:51 --> Helper loaded: form_helper
INFO - 26.06.2025 11:53:51 --> Form Validation Class Initialized
INFO - 26.06.2025 11:53:51 --> Upload Class Initialized
INFO - 26.06.2025 11:53:51 --> Helper loaded: date_helper
INFO - 26.06.2025 11:53:51 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:53:51 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:53:51 --> Pagination Class Initialized
INFO - 26.06.2025 11:53:51 --> Controller Class Initialized
INFO - 26.06.2025 11:53:51 --> Model "App_model" initialized
INFO - 26.06.2025 11:53:51 --> Model "Mail_model" initialized
INFO - 26.06.2025 11:53:51 --> Helper loaded: form_helper
INFO - 26.06.2025 11:53:51 --> Form Validation Class Initialized
INFO - 26.06.2025 11:53:51 --> Upload Class Initialized
INFO - 26.06.2025 11:53:51 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:53:51 --> Pagination Class Initialized
INFO - 26.06.2025 11:53:51 --> Controller Class Initialized
INFO - 26.06.2025 11:53:51 --> Model "App_model" initialized
INFO - 26.06.2025 11:53:51 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:53:51 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
ERROR - 26.06.2025 11:53:51 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/styx_gelaende_990x990_1750938711.jpg
ERROR - 26.06.2025 11:53:51 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:53:51 --> Could not find the language line "ERROR_404_DESCRIPTION"
ERROR - 26.06.2025 11:53:51 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:53:51 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:53:51 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:53:51 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:53:51 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:53:51 --> Could not find the language line "ABOUT_US"
DEBUG - 26.06.2025 11:53:51 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:53:51 --> Email Class Initialized
INFO - 26.06.2025 11:53:51 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:53:51 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:53:51 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:53:51 --> Helper loaded: date_helper
INFO - 26.06.2025 11:53:51 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:53:51 --> Helper loaded: form_helper
DEBUG - 26.06.2025 11:53:51 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 11:53:51 --> Form Validation Class Initialized
INFO - 26.06.2025 11:53:51 --> Upload Class Initialized
INFO - 26.06.2025 11:53:51 --> Email Class Initialized
INFO - 26.06.2025 11:53:51 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 11:53:51 --> Helper loaded: cookie_helper
INFO - 26.06.2025 11:53:51 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:53:51 --> Pagination Class Initialized
INFO - 26.06.2025 11:53:51 --> Controller Class Initialized
INFO - 26.06.2025 11:53:51 --> Helper loaded: url_helper
DEBUG - 26.06.2025 11:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:53:51 --> Model "App_model" initialized
INFO - 26.06.2025 11:53:51 --> Model "Mail_model" initialized
INFO - 26.06.2025 11:53:51 --> Helper loaded: date_helper
INFO - 26.06.2025 11:53:51 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 11:53:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 11:53:51 --> Helper loaded: form_helper
INFO - 26.06.2025 11:53:51 --> Form Validation Class Initialized
INFO - 26.06.2025 11:53:51 --> Upload Class Initialized
INFO - 26.06.2025 11:53:51 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 11:53:51 --> Pagination Class Initialized
INFO - 26.06.2025 11:53:51 --> Controller Class Initialized
INFO - 26.06.2025 11:53:51 --> Model "App_model" initialized
INFO - 26.06.2025 11:53:51 --> Model "Mail_model" initialized
ERROR - 26.06.2025 11:53:51 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/styx_gelaende_990x990_1750938711.jpg
INFO - 26.06.2025 11:53:51 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:53:51 --> Final output sent to browser
DEBUG - 26.06.2025 11:53:51 --> Total execution time: 0.4781
ERROR - 26.06.2025 11:53:51 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/aloe-vera-produkte_1750938165.jpg
INFO - 26.06.2025 11:53:51 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:53:51 --> Final output sent to browser
DEBUG - 26.06.2025 11:53:51 --> Total execution time: 0.4934
ERROR - 26.06.2025 11:53:51 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:53:51 --> Could not find the language line "ERROR_404_DESCRIPTION"
ERROR - 26.06.2025 11:53:51 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 11:53:51 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 11:53:51 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:53:51 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:53:51 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 11:53:51 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 11:53:51 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:53:51 --> Final output sent to browser
DEBUG - 26.06.2025 11:53:51 --> Total execution time: 0.4630
INFO - 26.06.2025 11:53:52 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 11:53:52 --> Final output sent to browser
DEBUG - 26.06.2025 11:53:52 --> Total execution time: 0.4872
INFO - 26.06.2025 12:48:50 --> Config Class Initialized
INFO - 26.06.2025 12:48:50 --> Hooks Class Initialized
DEBUG - 26.06.2025 12:48:50 --> UTF-8 Support Enabled
INFO - 26.06.2025 12:48:50 --> Utf8 Class Initialized
INFO - 26.06.2025 12:48:50 --> URI Class Initialized
INFO - 26.06.2025 12:48:50 --> Router Class Initialized
INFO - 26.06.2025 12:48:50 --> Output Class Initialized
INFO - 26.06.2025 12:48:50 --> Security Class Initialized
DEBUG - 26.06.2025 12:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 12:48:50 --> Input Class Initialized
INFO - 26.06.2025 12:48:50 --> Language Class Initialized
INFO - 26.06.2025 12:48:50 --> Loader Class Initialized
INFO - 26.06.2025 12:48:50 --> Helper loaded: app_helper
INFO - 26.06.2025 12:48:50 --> Helper loaded: language_helper
INFO - 26.06.2025 12:48:50 --> Helper loaded: text_helper
INFO - 26.06.2025 12:48:50 --> Helper loaded: string_helper
INFO - 26.06.2025 12:48:50 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 12:48:50 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 12:48:50 --> Database Driver Class Initialized
INFO - 26.06.2025 12:48:50 --> Config Class Initialized
INFO - 26.06.2025 12:48:50 --> Hooks Class Initialized
DEBUG - 26.06.2025 12:48:51 --> UTF-8 Support Enabled
INFO - 26.06.2025 12:48:51 --> Utf8 Class Initialized
INFO - 26.06.2025 12:48:51 --> URI Class Initialized
INFO - 26.06.2025 12:48:51 --> Router Class Initialized
INFO - 26.06.2025 12:48:51 --> Output Class Initialized
INFO - 26.06.2025 12:48:51 --> Security Class Initialized
DEBUG - 26.06.2025 12:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 12:48:51 --> Input Class Initialized
INFO - 26.06.2025 12:48:51 --> Language Class Initialized
DEBUG - 26.06.2025 12:48:51 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 12:48:51 --> Loader Class Initialized
INFO - 26.06.2025 12:48:51 --> Email Class Initialized
INFO - 26.06.2025 12:48:51 --> Helper loaded: app_helper
INFO - 26.06.2025 12:48:51 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 12:48:51 --> Helper loaded: language_helper
INFO - 26.06.2025 12:48:51 --> Helper loaded: cookie_helper
INFO - 26.06.2025 12:48:51 --> Helper loaded: text_helper
INFO - 26.06.2025 12:48:51 --> Helper loaded: url_helper
INFO - 26.06.2025 12:48:51 --> Helper loaded: string_helper
DEBUG - 26.06.2025 12:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 12:48:51 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 12:48:51 --> Helper loaded: date_helper
INFO - 26.06.2025 12:48:51 --> Model "Ion_auth_model" initialized
INFO - 26.06.2025 12:48:51 --> Session: Class initialized using 'files' driver.
DEBUG - 26.06.2025 12:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 12:48:51 --> Helper loaded: form_helper
INFO - 26.06.2025 12:48:51 --> Form Validation Class Initialized
INFO - 26.06.2025 12:48:51 --> Upload Class Initialized
INFO - 26.06.2025 12:48:51 --> Database Driver Class Initialized
INFO - 26.06.2025 12:48:51 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 12:48:51 --> Pagination Class Initialized
INFO - 26.06.2025 12:48:51 --> Controller Class Initialized
INFO - 26.06.2025 12:48:51 --> Model "App_model" initialized
INFO - 26.06.2025 12:48:51 --> Model "Mail_model" initialized
ERROR - 26.06.2025 12:48:51 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/styx_stelle_vertriebsinnendienst_2025_ohne_1749627800.jpg
ERROR - 26.06.2025 12:48:51 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 12:48:51 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 12:48:51 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 12:48:51 --> Could not find the language line "ABOUT_US"
DEBUG - 26.06.2025 12:48:51 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 12:48:51 --> Email Class Initialized
INFO - 26.06.2025 12:48:51 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 12:48:51 --> Helper loaded: cookie_helper
INFO - 26.06.2025 12:48:51 --> Helper loaded: url_helper
DEBUG - 26.06.2025 12:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 12:48:51 --> Helper loaded: date_helper
INFO - 26.06.2025 12:48:51 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 12:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 12:48:51 --> Helper loaded: form_helper
INFO - 26.06.2025 12:48:51 --> Form Validation Class Initialized
INFO - 26.06.2025 12:48:51 --> Upload Class Initialized
INFO - 26.06.2025 12:48:51 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 12:48:51 --> Pagination Class Initialized
INFO - 26.06.2025 12:48:51 --> Controller Class Initialized
INFO - 26.06.2025 12:48:51 --> Model "App_model" initialized
INFO - 26.06.2025 12:48:51 --> Model "Mail_model" initialized
INFO - 26.06.2025 12:48:51 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 12:48:51 --> Final output sent to browser
DEBUG - 26.06.2025 12:48:51 --> Total execution time: 0.4788
ERROR - 26.06.2025 12:48:51 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/styx_stelle_vertriebsinnendienst_2025_ohne_1749627800.jpg
ERROR - 26.06.2025 12:48:51 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 12:48:51 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 12:48:51 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 12:48:51 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 12:48:51 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 12:48:51 --> Final output sent to browser
DEBUG - 26.06.2025 12:48:51 --> Total execution time: 0.4729
INFO - 26.06.2025 12:49:00 --> Config Class Initialized
INFO - 26.06.2025 12:49:00 --> Hooks Class Initialized
DEBUG - 26.06.2025 12:49:00 --> UTF-8 Support Enabled
INFO - 26.06.2025 12:49:00 --> Utf8 Class Initialized
INFO - 26.06.2025 12:49:00 --> URI Class Initialized
INFO - 26.06.2025 12:49:00 --> Router Class Initialized
INFO - 26.06.2025 12:49:00 --> Output Class Initialized
INFO - 26.06.2025 12:49:00 --> Security Class Initialized
DEBUG - 26.06.2025 12:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 12:49:00 --> Input Class Initialized
INFO - 26.06.2025 12:49:00 --> Language Class Initialized
INFO - 26.06.2025 12:49:00 --> Loader Class Initialized
INFO - 26.06.2025 12:49:00 --> Helper loaded: app_helper
INFO - 26.06.2025 12:49:00 --> Helper loaded: language_helper
INFO - 26.06.2025 12:49:00 --> Helper loaded: text_helper
INFO - 26.06.2025 12:49:00 --> Helper loaded: string_helper
INFO - 26.06.2025 12:49:00 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 12:49:00 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 12:49:00 --> Database Driver Class Initialized
INFO - 26.06.2025 12:49:00 --> Config Class Initialized
INFO - 26.06.2025 12:49:00 --> Hooks Class Initialized
DEBUG - 26.06.2025 12:49:00 --> UTF-8 Support Enabled
INFO - 26.06.2025 12:49:00 --> Utf8 Class Initialized
INFO - 26.06.2025 12:49:00 --> URI Class Initialized
INFO - 26.06.2025 12:49:00 --> Router Class Initialized
INFO - 26.06.2025 12:49:00 --> Output Class Initialized
INFO - 26.06.2025 12:49:00 --> Security Class Initialized
DEBUG - 26.06.2025 12:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 12:49:00 --> Input Class Initialized
INFO - 26.06.2025 12:49:00 --> Language Class Initialized
INFO - 26.06.2025 12:49:00 --> Loader Class Initialized
INFO - 26.06.2025 12:49:00 --> Helper loaded: app_helper
INFO - 26.06.2025 12:49:00 --> Helper loaded: language_helper
INFO - 26.06.2025 12:49:00 --> Helper loaded: text_helper
INFO - 26.06.2025 12:49:00 --> Helper loaded: string_helper
INFO - 26.06.2025 12:49:00 --> Language file loaded: language/german/app_lang.php
DEBUG - 26.06.2025 12:49:00 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 12:49:00 --> Email Class Initialized
INFO - 26.06.2025 12:49:00 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 12:49:00 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 12:49:00 --> Helper loaded: cookie_helper
INFO - 26.06.2025 12:49:00 --> Helper loaded: url_helper
DEBUG - 26.06.2025 12:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 12:49:00 --> Database Driver Class Initialized
INFO - 26.06.2025 12:49:00 --> Helper loaded: date_helper
INFO - 26.06.2025 12:49:00 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 12:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 12:49:00 --> Helper loaded: form_helper
INFO - 26.06.2025 12:49:00 --> Form Validation Class Initialized
INFO - 26.06.2025 12:49:00 --> Upload Class Initialized
INFO - 26.06.2025 12:49:00 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 12:49:00 --> Pagination Class Initialized
INFO - 26.06.2025 12:49:00 --> Controller Class Initialized
INFO - 26.06.2025 12:49:00 --> Model "App_model" initialized
INFO - 26.06.2025 12:49:00 --> Model "Mail_model" initialized
ERROR - 26.06.2025 12:49:00 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/styx_stelle_vertriebsinnendienst_2025_ohne_1749627800.jpg
ERROR - 26.06.2025 12:49:00 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 12:49:00 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 12:49:00 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 12:49:00 --> Could not find the language line "ABOUT_US"
DEBUG - 26.06.2025 12:49:00 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 12:49:00 --> Email Class Initialized
INFO - 26.06.2025 12:49:00 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 12:49:00 --> Helper loaded: cookie_helper
INFO - 26.06.2025 12:49:00 --> Helper loaded: url_helper
DEBUG - 26.06.2025 12:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 12:49:00 --> Helper loaded: date_helper
INFO - 26.06.2025 12:49:00 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 12:49:00 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 12:49:00 --> Helper loaded: form_helper
INFO - 26.06.2025 12:49:00 --> Form Validation Class Initialized
INFO - 26.06.2025 12:49:00 --> Upload Class Initialized
INFO - 26.06.2025 12:49:00 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 12:49:00 --> Pagination Class Initialized
INFO - 26.06.2025 12:49:00 --> Controller Class Initialized
INFO - 26.06.2025 12:49:00 --> Model "App_model" initialized
INFO - 26.06.2025 12:49:00 --> Model "Mail_model" initialized
ERROR - 26.06.2025 12:49:00 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/styx_stelle_vertriebsinnendienst_2025_ohne_1749627800.jpg
INFO - 26.06.2025 12:49:00 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 12:49:00 --> Final output sent to browser
DEBUG - 26.06.2025 12:49:00 --> Total execution time: 0.4786
ERROR - 26.06.2025 12:49:00 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 12:49:00 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 12:49:00 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 12:49:00 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 12:49:00 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 12:49:00 --> Final output sent to browser
DEBUG - 26.06.2025 12:49:00 --> Total execution time: 0.4716
INFO - 26.06.2025 12:49:03 --> Config Class Initialized
INFO - 26.06.2025 12:49:03 --> Hooks Class Initialized
DEBUG - 26.06.2025 12:49:03 --> UTF-8 Support Enabled
INFO - 26.06.2025 12:49:03 --> Utf8 Class Initialized
INFO - 26.06.2025 12:49:03 --> URI Class Initialized
INFO - 26.06.2025 12:49:03 --> Router Class Initialized
INFO - 26.06.2025 12:49:03 --> Output Class Initialized
INFO - 26.06.2025 12:49:03 --> Security Class Initialized
DEBUG - 26.06.2025 12:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 12:49:03 --> Input Class Initialized
INFO - 26.06.2025 12:49:03 --> Language Class Initialized
INFO - 26.06.2025 12:49:03 --> Loader Class Initialized
INFO - 26.06.2025 12:49:03 --> Helper loaded: app_helper
INFO - 26.06.2025 12:49:03 --> Helper loaded: language_helper
INFO - 26.06.2025 12:49:03 --> Helper loaded: text_helper
INFO - 26.06.2025 12:49:03 --> Helper loaded: string_helper
INFO - 26.06.2025 12:49:03 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 12:49:03 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 12:49:03 --> Database Driver Class Initialized
INFO - 26.06.2025 12:49:03 --> Config Class Initialized
INFO - 26.06.2025 12:49:03 --> Hooks Class Initialized
DEBUG - 26.06.2025 12:49:03 --> UTF-8 Support Enabled
INFO - 26.06.2025 12:49:03 --> Utf8 Class Initialized
INFO - 26.06.2025 12:49:03 --> URI Class Initialized
INFO - 26.06.2025 12:49:03 --> Router Class Initialized
INFO - 26.06.2025 12:49:03 --> Output Class Initialized
INFO - 26.06.2025 12:49:03 --> Security Class Initialized
DEBUG - 26.06.2025 12:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 26.06.2025 12:49:03 --> Input Class Initialized
INFO - 26.06.2025 12:49:03 --> Language Class Initialized
INFO - 26.06.2025 12:49:03 --> Loader Class Initialized
INFO - 26.06.2025 12:49:03 --> Helper loaded: app_helper
INFO - 26.06.2025 12:49:03 --> Helper loaded: language_helper
INFO - 26.06.2025 12:49:03 --> Helper loaded: text_helper
INFO - 26.06.2025 12:49:03 --> Helper loaded: string_helper
INFO - 26.06.2025 12:49:03 --> Language file loaded: language/german/app_lang.php
INFO - 26.06.2025 12:49:03 --> Session: Class initialized using 'files' driver.
INFO - 26.06.2025 12:49:03 --> Database Driver Class Initialized
DEBUG - 26.06.2025 12:49:03 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 12:49:03 --> Email Class Initialized
INFO - 26.06.2025 12:49:03 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 12:49:03 --> Helper loaded: cookie_helper
INFO - 26.06.2025 12:49:03 --> Helper loaded: url_helper
DEBUG - 26.06.2025 12:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 12:49:03 --> Helper loaded: date_helper
INFO - 26.06.2025 12:49:03 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 12:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 12:49:03 --> Helper loaded: form_helper
INFO - 26.06.2025 12:49:03 --> Form Validation Class Initialized
INFO - 26.06.2025 12:49:03 --> Upload Class Initialized
INFO - 26.06.2025 12:49:03 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 12:49:03 --> Pagination Class Initialized
INFO - 26.06.2025 12:49:03 --> Controller Class Initialized
INFO - 26.06.2025 12:49:03 --> Model "App_model" initialized
INFO - 26.06.2025 12:49:03 --> Model "Mail_model" initialized
ERROR - 26.06.2025 12:49:03 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/styx_stelle_vertriebsinnendienst_2025_ohne_1749627800.jpg
ERROR - 26.06.2025 12:49:03 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 12:49:03 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 12:49:03 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 12:49:03 --> Could not find the language line "ABOUT_US"
DEBUG - 26.06.2025 12:49:03 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 26.06.2025 12:49:03 --> Email Class Initialized
INFO - 26.06.2025 12:49:03 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 26.06.2025 12:49:03 --> Helper loaded: cookie_helper
INFO - 26.06.2025 12:49:03 --> Helper loaded: url_helper
DEBUG - 26.06.2025 12:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 12:49:03 --> Helper loaded: date_helper
INFO - 26.06.2025 12:49:03 --> Model "Ion_auth_model" initialized
DEBUG - 26.06.2025 12:49:03 --> Session class already loaded. Second attempt ignored.
INFO - 26.06.2025 12:49:03 --> Helper loaded: form_helper
INFO - 26.06.2025 12:49:03 --> Form Validation Class Initialized
INFO - 26.06.2025 12:49:03 --> Upload Class Initialized
INFO - 26.06.2025 12:49:03 --> Language file loaded: language/german/pagination_lang.php
INFO - 26.06.2025 12:49:03 --> Pagination Class Initialized
INFO - 26.06.2025 12:49:03 --> Controller Class Initialized
INFO - 26.06.2025 12:49:03 --> Model "App_model" initialized
INFO - 26.06.2025 12:49:03 --> Model "Mail_model" initialized
ERROR - 26.06.2025 12:49:03 --> 404 Page Not Found: http://localhost/STYX_web/uploads/articles/summernote/styx_stelle_vertriebsinnendienst_2025_ohne_1749627800.jpg
INFO - 26.06.2025 12:49:03 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 12:49:03 --> Final output sent to browser
DEBUG - 26.06.2025 12:49:03 --> Total execution time: 0.5115
ERROR - 26.06.2025 12:49:03 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 26.06.2025 12:49:03 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 26.06.2025 12:49:03 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 26.06.2025 12:49:03 --> Could not find the language line "ABOUT_US"
INFO - 26.06.2025 12:49:03 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 26.06.2025 12:49:03 --> Final output sent to browser
DEBUG - 26.06.2025 12:49:03 --> Total execution time: 0.5007
