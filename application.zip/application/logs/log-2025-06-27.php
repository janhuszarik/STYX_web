<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 27.06.2025 06:41:10 --> Config Class Initialized
INFO - 27.06.2025 06:41:10 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:10 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:10 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:10 --> URI Class Initialized
DEBUG - 27.06.2025 06:41:10 --> No URI present. Default controller set.
INFO - 27.06.2025 06:41:10 --> Router Class Initialized
INFO - 27.06.2025 06:41:10 --> Output Class Initialized
INFO - 27.06.2025 06:41:10 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:10 --> Input Class Initialized
INFO - 27.06.2025 06:41:10 --> Language Class Initialized
INFO - 27.06.2025 06:41:10 --> Loader Class Initialized
INFO - 27.06.2025 06:41:10 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:10 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:10 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:10 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:10 --> Language file loaded: language/german/app_lang.php
INFO - 27.06.2025 06:41:10 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:10 --> Database Driver Class Initialized
DEBUG - 27.06.2025 06:41:11 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:11 --> Email Class Initialized
INFO - 27.06.2025 06:41:11 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:11 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:11 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:11 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:11 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:11 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:11 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:11 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:11 --> Upload Class Initialized
INFO - 27.06.2025 06:41:11 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:11 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:11 --> Controller Class Initialized
INFO - 27.06.2025 06:41:11 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:11 --> Model "Mail_model" initialized
INFO - 27.06.2025 06:41:11 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\home.php
ERROR - 27.06.2025 06:41:11 --> Could not find the language line "ABOUT_US"
INFO - 27.06.2025 06:41:11 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 27.06.2025 06:41:11 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:11 --> Total execution time: 1.1770
INFO - 27.06.2025 06:41:11 --> Config Class Initialized
INFO - 27.06.2025 06:41:11 --> Config Class Initialized
INFO - 27.06.2025 06:41:11 --> Config Class Initialized
INFO - 27.06.2025 06:41:11 --> Hooks Class Initialized
INFO - 27.06.2025 06:41:11 --> Hooks Class Initialized
INFO - 27.06.2025 06:41:11 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:11 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:11 --> Utf8 Class Initialized
DEBUG - 27.06.2025 06:41:11 --> UTF-8 Support Enabled
DEBUG - 27.06.2025 06:41:11 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:11 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:11 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:11 --> URI Class Initialized
INFO - 27.06.2025 06:41:11 --> URI Class Initialized
INFO - 27.06.2025 06:41:11 --> URI Class Initialized
INFO - 27.06.2025 06:41:11 --> Router Class Initialized
INFO - 27.06.2025 06:41:11 --> Router Class Initialized
INFO - 27.06.2025 06:41:11 --> Router Class Initialized
INFO - 27.06.2025 06:41:11 --> Output Class Initialized
INFO - 27.06.2025 06:41:11 --> Output Class Initialized
INFO - 27.06.2025 06:41:11 --> Output Class Initialized
INFO - 27.06.2025 06:41:11 --> Security Class Initialized
INFO - 27.06.2025 06:41:11 --> Security Class Initialized
INFO - 27.06.2025 06:41:11 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:11 --> Input Class Initialized
DEBUG - 27.06.2025 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:11 --> Input Class Initialized
DEBUG - 27.06.2025 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:11 --> Language Class Initialized
INFO - 27.06.2025 06:41:11 --> Input Class Initialized
INFO - 27.06.2025 06:41:11 --> Language Class Initialized
INFO - 27.06.2025 06:41:11 --> Language Class Initialized
INFO - 27.06.2025 06:41:11 --> Config Class Initialized
INFO - 27.06.2025 06:41:11 --> Hooks Class Initialized
INFO - 27.06.2025 06:41:11 --> Loader Class Initialized
INFO - 27.06.2025 06:41:11 --> Loader Class Initialized
INFO - 27.06.2025 06:41:11 --> Loader Class Initialized
INFO - 27.06.2025 06:41:11 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: app_helper
DEBUG - 27.06.2025 06:41:11 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:11 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:11 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:11 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:11 --> URI Class Initialized
INFO - 27.06.2025 06:41:11 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:11 --> Language file loaded: language/german/app_lang.php
INFO - 27.06.2025 06:41:11 --> Router Class Initialized
INFO - 27.06.2025 06:41:11 --> Language file loaded: language/german/app_lang.php
INFO - 27.06.2025 06:41:11 --> Language file loaded: language/german/app_lang.php
INFO - 27.06.2025 06:41:11 --> Output Class Initialized
INFO - 27.06.2025 06:41:11 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:11 --> Input Class Initialized
INFO - 27.06.2025 06:41:11 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:11 --> Language Class Initialized
INFO - 27.06.2025 06:41:11 --> Loader Class Initialized
INFO - 27.06.2025 06:41:11 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:11 --> Database Driver Class Initialized
INFO - 27.06.2025 06:41:11 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:11 --> Language file loaded: language/german/app_lang.php
INFO - 27.06.2025 06:41:11 --> Config Class Initialized
INFO - 27.06.2025 06:41:11 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:11 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:11 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:11 --> URI Class Initialized
INFO - 27.06.2025 06:41:11 --> Router Class Initialized
INFO - 27.06.2025 06:41:11 --> Output Class Initialized
INFO - 27.06.2025 06:41:11 --> Security Class Initialized
INFO - 27.06.2025 06:41:11 --> Config Class Initialized
INFO - 27.06.2025 06:41:11 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:11 --> Input Class Initialized
INFO - 27.06.2025 06:41:11 --> Language Class Initialized
DEBUG - 27.06.2025 06:41:11 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:11 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:11 --> URI Class Initialized
INFO - 27.06.2025 06:41:11 --> Loader Class Initialized
INFO - 27.06.2025 06:41:11 --> Router Class Initialized
INFO - 27.06.2025 06:41:11 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:11 --> Output Class Initialized
INFO - 27.06.2025 06:41:11 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:11 --> Security Class Initialized
INFO - 27.06.2025 06:41:11 --> Helper loaded: string_helper
DEBUG - 27.06.2025 06:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:11 --> Input Class Initialized
INFO - 27.06.2025 06:41:11 --> Language file loaded: language/german/app_lang.php
INFO - 27.06.2025 06:41:11 --> Language Class Initialized
INFO - 27.06.2025 06:41:11 --> Loader Class Initialized
INFO - 27.06.2025 06:41:11 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:11 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:11 --> Language file loaded: language/german/app_lang.php
DEBUG - 27.06.2025 06:41:12 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:12 --> Email Class Initialized
INFO - 27.06.2025 06:41:12 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:12 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:12 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:12 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:12 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:12 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:12 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:12 --> Upload Class Initialized
INFO - 27.06.2025 06:41:12 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:12 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:12 --> Controller Class Initialized
INFO - 27.06.2025 06:41:12 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:12 --> Model "Mail_model" initialized
ERROR - 27.06.2025 06:41:12 --> 404 Page Not Found: http://localhost/STYX_web/uploads/news/c989c57157662de2de5eb5a71999e62b.jpg
ERROR - 27.06.2025 06:41:12 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 27.06.2025 06:41:12 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 27.06.2025 06:41:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 27.06.2025 06:41:12 --> Could not find the language line "ABOUT_US"
INFO - 27.06.2025 06:41:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 27.06.2025 06:41:12 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:12 --> Total execution time: 0.5137
INFO - 27.06.2025 06:41:12 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:12 --> Database Driver Class Initialized
INFO - 27.06.2025 06:41:12 --> Config Class Initialized
INFO - 27.06.2025 06:41:12 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:12 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:12 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:12 --> URI Class Initialized
INFO - 27.06.2025 06:41:12 --> Router Class Initialized
INFO - 27.06.2025 06:41:12 --> Output Class Initialized
INFO - 27.06.2025 06:41:12 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:12 --> Input Class Initialized
INFO - 27.06.2025 06:41:12 --> Language Class Initialized
INFO - 27.06.2025 06:41:12 --> Loader Class Initialized
INFO - 27.06.2025 06:41:12 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:12 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:12 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:12 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:12 --> Language file loaded: language/german/app_lang.php
DEBUG - 27.06.2025 06:41:12 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:12 --> Email Class Initialized
INFO - 27.06.2025 06:41:12 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:12 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:12 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:12 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:12 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:12 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:12 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:12 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:12 --> Upload Class Initialized
INFO - 27.06.2025 06:41:12 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:12 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:12 --> Controller Class Initialized
INFO - 27.06.2025 06:41:12 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:12 --> Model "Mail_model" initialized
ERROR - 27.06.2025 06:41:12 --> 404 Page Not Found: http://localhost/STYX_web/uploads/news/83dad5219e44fda9ca85eff25c67e4b5.jpg
ERROR - 27.06.2025 06:41:12 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 27.06.2025 06:41:12 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 27.06.2025 06:41:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 27.06.2025 06:41:12 --> Could not find the language line "ABOUT_US"
INFO - 27.06.2025 06:41:12 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 27.06.2025 06:41:12 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:12 --> Total execution time: 0.9899
INFO - 27.06.2025 06:41:12 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:12 --> Database Driver Class Initialized
INFO - 27.06.2025 06:41:12 --> Config Class Initialized
INFO - 27.06.2025 06:41:12 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:12 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:12 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:12 --> URI Class Initialized
INFO - 27.06.2025 06:41:12 --> Router Class Initialized
INFO - 27.06.2025 06:41:12 --> Output Class Initialized
INFO - 27.06.2025 06:41:12 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:12 --> Input Class Initialized
INFO - 27.06.2025 06:41:12 --> Language Class Initialized
INFO - 27.06.2025 06:41:12 --> Loader Class Initialized
INFO - 27.06.2025 06:41:12 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:12 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:12 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:12 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:12 --> Language file loaded: language/german/app_lang.php
DEBUG - 27.06.2025 06:41:13 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:13 --> Email Class Initialized
INFO - 27.06.2025 06:41:13 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:13 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:13 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:13 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:13 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:13 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:13 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:13 --> Upload Class Initialized
INFO - 27.06.2025 06:41:13 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:13 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:13 --> Controller Class Initialized
INFO - 27.06.2025 06:41:13 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:13 --> Model "Mail_model" initialized
ERROR - 27.06.2025 06:41:13 --> 404 Page Not Found: http://localhost/STYX_web/uploads/news/20ded9fe20968bffa6ade0dc8186d1c0.jpg
ERROR - 27.06.2025 06:41:13 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 27.06.2025 06:41:13 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 27.06.2025 06:41:13 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 27.06.2025 06:41:13 --> Could not find the language line "ABOUT_US"
INFO - 27.06.2025 06:41:13 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 27.06.2025 06:41:13 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:13 --> Total execution time: 1.4449
INFO - 27.06.2025 06:41:13 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:13 --> Database Driver Class Initialized
INFO - 27.06.2025 06:41:13 --> Config Class Initialized
INFO - 27.06.2025 06:41:13 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:13 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:13 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:13 --> URI Class Initialized
INFO - 27.06.2025 06:41:13 --> Router Class Initialized
INFO - 27.06.2025 06:41:13 --> Output Class Initialized
INFO - 27.06.2025 06:41:13 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:13 --> Input Class Initialized
INFO - 27.06.2025 06:41:13 --> Language Class Initialized
INFO - 27.06.2025 06:41:13 --> Loader Class Initialized
INFO - 27.06.2025 06:41:13 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:13 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:13 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:13 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:13 --> Language file loaded: language/german/app_lang.php
DEBUG - 27.06.2025 06:41:13 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:13 --> Email Class Initialized
INFO - 27.06.2025 06:41:13 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:13 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:13 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:13 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:13 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:13 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:13 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:13 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:13 --> Upload Class Initialized
INFO - 27.06.2025 06:41:13 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:13 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:13 --> Controller Class Initialized
INFO - 27.06.2025 06:41:13 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:13 --> Model "Mail_model" initialized
ERROR - 27.06.2025 06:41:13 --> 404 Page Not Found: http://localhost/STYX_web/uploads/sliders/slider_1748957219.jpg
ERROR - 27.06.2025 06:41:13 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 27.06.2025 06:41:13 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 27.06.2025 06:41:13 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 27.06.2025 06:41:13 --> Could not find the language line "ABOUT_US"
INFO - 27.06.2025 06:41:13 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 27.06.2025 06:41:13 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:13 --> Total execution time: 1.8850
INFO - 27.06.2025 06:41:13 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:13 --> Database Driver Class Initialized
INFO - 27.06.2025 06:41:13 --> Config Class Initialized
INFO - 27.06.2025 06:41:13 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:13 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:13 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:13 --> URI Class Initialized
INFO - 27.06.2025 06:41:13 --> Router Class Initialized
INFO - 27.06.2025 06:41:13 --> Output Class Initialized
INFO - 27.06.2025 06:41:13 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:13 --> Input Class Initialized
INFO - 27.06.2025 06:41:13 --> Language Class Initialized
INFO - 27.06.2025 06:41:13 --> Loader Class Initialized
INFO - 27.06.2025 06:41:13 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:13 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:13 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:13 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:13 --> Language file loaded: language/german/app_lang.php
DEBUG - 27.06.2025 06:41:14 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:14 --> Email Class Initialized
INFO - 27.06.2025 06:41:14 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:14 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:14 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:14 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:14 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:14 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:14 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:14 --> Upload Class Initialized
INFO - 27.06.2025 06:41:14 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:14 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:14 --> Controller Class Initialized
INFO - 27.06.2025 06:41:14 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:14 --> Model "Mail_model" initialized
ERROR - 27.06.2025 06:41:14 --> 404 Page Not Found: http://localhost/STYX_web/uploads/product/b0ed84d6dbdb92fff1e7e614009f13b9.jpg
ERROR - 27.06.2025 06:41:14 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 27.06.2025 06:41:14 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 27.06.2025 06:41:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 27.06.2025 06:41:14 --> Could not find the language line "ABOUT_US"
INFO - 27.06.2025 06:41:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 27.06.2025 06:41:14 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:14 --> Total execution time: 2.2926
INFO - 27.06.2025 06:41:14 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:14 --> Database Driver Class Initialized
INFO - 27.06.2025 06:41:14 --> Config Class Initialized
INFO - 27.06.2025 06:41:14 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:14 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:14 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:14 --> URI Class Initialized
INFO - 27.06.2025 06:41:14 --> Router Class Initialized
INFO - 27.06.2025 06:41:14 --> Output Class Initialized
INFO - 27.06.2025 06:41:14 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:14 --> Input Class Initialized
INFO - 27.06.2025 06:41:14 --> Language Class Initialized
DEBUG - 27.06.2025 06:41:14 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:14 --> Email Class Initialized
INFO - 27.06.2025 06:41:14 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:14 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:14 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:14 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:14 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:14 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:14 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:14 --> Upload Class Initialized
INFO - 27.06.2025 06:41:14 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:14 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:14 --> Controller Class Initialized
INFO - 27.06.2025 06:41:14 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:14 --> Model "Mail_model" initialized
ERROR - 27.06.2025 06:41:14 --> 404 Page Not Found: http://localhost/STYX_web/uploads/product/35439aec5614c0814abddb8140c1e660.jpg
ERROR - 27.06.2025 06:41:14 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 27.06.2025 06:41:14 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 27.06.2025 06:41:14 --> Loader Class Initialized
INFO - 27.06.2025 06:41:14 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:14 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:14 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:14 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:14 --> Language file loaded: language/german/app_lang.php
INFO - 27.06.2025 06:41:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 27.06.2025 06:41:14 --> Could not find the language line "ABOUT_US"
INFO - 27.06.2025 06:41:14 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 27.06.2025 06:41:14 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:14 --> Total execution time: 2.7777
INFO - 27.06.2025 06:41:14 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:14 --> Database Driver Class Initialized
INFO - 27.06.2025 06:41:14 --> Config Class Initialized
INFO - 27.06.2025 06:41:14 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:14 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:14 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:14 --> URI Class Initialized
INFO - 27.06.2025 06:41:14 --> Router Class Initialized
INFO - 27.06.2025 06:41:14 --> Output Class Initialized
INFO - 27.06.2025 06:41:14 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:14 --> Input Class Initialized
INFO - 27.06.2025 06:41:14 --> Language Class Initialized
INFO - 27.06.2025 06:41:14 --> Loader Class Initialized
INFO - 27.06.2025 06:41:14 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:14 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:14 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:14 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:14 --> Language file loaded: language/german/app_lang.php
DEBUG - 27.06.2025 06:41:14 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:14 --> Email Class Initialized
INFO - 27.06.2025 06:41:14 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:14 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:14 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:14 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:14 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:14 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:14 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:14 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:14 --> Upload Class Initialized
INFO - 27.06.2025 06:41:14 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:14 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:14 --> Controller Class Initialized
INFO - 27.06.2025 06:41:14 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:14 --> Model "Mail_model" initialized
ERROR - 27.06.2025 06:41:14 --> 404 Page Not Found: http://localhost/STYX_web/uploads/product/52bfc6b3e4a97de4a8c55b667d7b2ebd.jpg
ERROR - 27.06.2025 06:41:15 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 27.06.2025 06:41:15 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 27.06.2025 06:41:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 27.06.2025 06:41:15 --> Could not find the language line "ABOUT_US"
INFO - 27.06.2025 06:41:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 27.06.2025 06:41:15 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:15 --> Total execution time: 2.7762
INFO - 27.06.2025 06:41:15 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:15 --> Database Driver Class Initialized
DEBUG - 27.06.2025 06:41:15 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:15 --> Email Class Initialized
INFO - 27.06.2025 06:41:15 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:15 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:15 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:15 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:15 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:15 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:15 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:15 --> Upload Class Initialized
INFO - 27.06.2025 06:41:15 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:15 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:15 --> Controller Class Initialized
INFO - 27.06.2025 06:41:15 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:15 --> Model "Mail_model" initialized
ERROR - 27.06.2025 06:41:15 --> 404 Page Not Found: http://localhost/STYX_web/uploads/product/57f29e2c30ce140579619320939233aa.jpg
ERROR - 27.06.2025 06:41:15 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 27.06.2025 06:41:15 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 27.06.2025 06:41:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 27.06.2025 06:41:15 --> Could not find the language line "ABOUT_US"
INFO - 27.06.2025 06:41:15 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 27.06.2025 06:41:15 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:15 --> Total execution time: 2.7476
INFO - 27.06.2025 06:41:15 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:15 --> Database Driver Class Initialized
DEBUG - 27.06.2025 06:41:15 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:15 --> Email Class Initialized
INFO - 27.06.2025 06:41:15 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:15 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:15 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:15 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:15 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:15 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:15 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:15 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:15 --> Upload Class Initialized
INFO - 27.06.2025 06:41:15 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:15 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:15 --> Controller Class Initialized
INFO - 27.06.2025 06:41:15 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:15 --> Model "Mail_model" initialized
ERROR - 27.06.2025 06:41:15 --> 404 Page Not Found: http://localhost/STYX_web/uploads/product/85046c855211d4c65b56d841460b6ebd.jpg
ERROR - 27.06.2025 06:41:15 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 27.06.2025 06:41:15 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 27.06.2025 06:41:16 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 27.06.2025 06:41:16 --> Could not find the language line "ABOUT_US"
INFO - 27.06.2025 06:41:16 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 27.06.2025 06:41:16 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:16 --> Total execution time: 2.7742
INFO - 27.06.2025 06:41:16 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:16 --> Database Driver Class Initialized
DEBUG - 27.06.2025 06:41:16 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:16 --> Email Class Initialized
INFO - 27.06.2025 06:41:16 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:16 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:16 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:16 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:16 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:16 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:16 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:16 --> Upload Class Initialized
INFO - 27.06.2025 06:41:16 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:16 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:16 --> Controller Class Initialized
INFO - 27.06.2025 06:41:16 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:16 --> Model "Mail_model" initialized
ERROR - 27.06.2025 06:41:16 --> 404 Page Not Found: http://localhost/STYX_web/uploads/product/5fc4a26f3bf0636d81b5130bc438701c.JPG
ERROR - 27.06.2025 06:41:16 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 27.06.2025 06:41:16 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 27.06.2025 06:41:16 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 27.06.2025 06:41:16 --> Could not find the language line "ABOUT_US"
INFO - 27.06.2025 06:41:16 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 27.06.2025 06:41:16 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:16 --> Total execution time: 2.7795
INFO - 27.06.2025 06:41:16 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:16 --> Database Driver Class Initialized
DEBUG - 27.06.2025 06:41:16 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:16 --> Email Class Initialized
INFO - 27.06.2025 06:41:16 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:16 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:16 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:16 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:16 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:16 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:16 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:16 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:16 --> Upload Class Initialized
INFO - 27.06.2025 06:41:16 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:16 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:16 --> Controller Class Initialized
DEBUG - 27.06.2025 06:41:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 27.06.2025 06:41:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 27.06.2025 06:41:16 --> Bcrypt class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:16 --> Model "Ion_auth_model" initialized
INFO - 27.06.2025 06:41:16 --> Language file loaded: language/german/auth_lang.php
INFO - 27.06.2025 06:41:16 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\auth\login.php
INFO - 27.06.2025 06:41:16 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:16 --> Total execution time: 2.5126
INFO - 27.06.2025 06:41:16 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:16 --> Database Driver Class Initialized
DEBUG - 27.06.2025 06:41:17 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:17 --> Email Class Initialized
INFO - 27.06.2025 06:41:17 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:17 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:17 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:17 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:17 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:17 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:17 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:17 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:17 --> Upload Class Initialized
INFO - 27.06.2025 06:41:17 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:17 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:17 --> Controller Class Initialized
INFO - 27.06.2025 06:41:17 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:17 --> Model "Mail_model" initialized
ERROR - 27.06.2025 06:41:17 --> 404 Page Not Found: http://localhost/STYX_web/uploads/product/4661f87c19b0c0f3b94db601070f75aa.jpg
ERROR - 27.06.2025 06:41:17 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 27.06.2025 06:41:17 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 27.06.2025 06:41:17 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 27.06.2025 06:41:17 --> Could not find the language line "ABOUT_US"
INFO - 27.06.2025 06:41:17 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 27.06.2025 06:41:17 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:17 --> Total execution time: 2.5141
INFO - 27.06.2025 06:41:17 --> Config Class Initialized
INFO - 27.06.2025 06:41:17 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:17 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:17 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:17 --> URI Class Initialized
INFO - 27.06.2025 06:41:17 --> Router Class Initialized
INFO - 27.06.2025 06:41:17 --> Output Class Initialized
INFO - 27.06.2025 06:41:17 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:17 --> Input Class Initialized
INFO - 27.06.2025 06:41:17 --> Language Class Initialized
INFO - 27.06.2025 06:41:17 --> Loader Class Initialized
INFO - 27.06.2025 06:41:17 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:17 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:17 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:17 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:17 --> Language file loaded: language/german/app_lang.php
INFO - 27.06.2025 06:41:17 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:17 --> Database Driver Class Initialized
DEBUG - 27.06.2025 06:41:18 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:18 --> Email Class Initialized
INFO - 27.06.2025 06:41:18 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:18 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:18 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:18 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:18 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:18 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:18 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:18 --> Upload Class Initialized
INFO - 27.06.2025 06:41:18 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:18 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:18 --> Controller Class Initialized
DEBUG - 27.06.2025 06:41:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 27.06.2025 06:41:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 27.06.2025 06:41:18 --> Bcrypt class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:18 --> Model "Ion_auth_model" initialized
INFO - 27.06.2025 06:41:18 --> Language file loaded: language/german/auth_lang.php
INFO - 27.06.2025 06:41:18 --> Language file loaded: language/german/form_validation_lang.php
INFO - 27.06.2025 06:41:18 --> Config Class Initialized
INFO - 27.06.2025 06:41:18 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:18 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:18 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:18 --> URI Class Initialized
INFO - 27.06.2025 06:41:18 --> Router Class Initialized
INFO - 27.06.2025 06:41:18 --> Output Class Initialized
INFO - 27.06.2025 06:41:18 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:18 --> Input Class Initialized
INFO - 27.06.2025 06:41:18 --> Language Class Initialized
INFO - 27.06.2025 06:41:18 --> Loader Class Initialized
INFO - 27.06.2025 06:41:18 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:18 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:18 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:18 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:18 --> Language file loaded: language/german/app_lang.php
INFO - 27.06.2025 06:41:18 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:18 --> Database Driver Class Initialized
DEBUG - 27.06.2025 06:41:18 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:18 --> Email Class Initialized
INFO - 27.06.2025 06:41:18 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:18 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:18 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:18 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:18 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:18 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:18 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:18 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:18 --> Upload Class Initialized
INFO - 27.06.2025 06:41:18 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:18 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:18 --> Controller Class Initialized
INFO - 27.06.2025 06:41:18 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:18 --> Model "Admin_model" initialized
DEBUG - 27.06.2025 06:41:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 27.06.2025 06:41:19 --> Severity: error --> Exception: Call to undefined function activeCss() C:\Users\assist15\Desktop\project\STYX_web\application\views\admin\layout\menu.php 125
INFO - 27.06.2025 06:41:41 --> Config Class Initialized
INFO - 27.06.2025 06:41:41 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:41 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:41 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:41 --> URI Class Initialized
INFO - 27.06.2025 06:41:41 --> Router Class Initialized
INFO - 27.06.2025 06:41:41 --> Output Class Initialized
INFO - 27.06.2025 06:41:41 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:41 --> Input Class Initialized
INFO - 27.06.2025 06:41:41 --> Language Class Initialized
INFO - 27.06.2025 06:41:41 --> Loader Class Initialized
INFO - 27.06.2025 06:41:41 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:41 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:41 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:41 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:41 --> Language file loaded: language/german/app_lang.php
INFO - 27.06.2025 06:41:41 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:41 --> Database Driver Class Initialized
DEBUG - 27.06.2025 06:41:41 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:41 --> Email Class Initialized
INFO - 27.06.2025 06:41:41 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:41 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:41 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:41 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:41 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:41 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:41 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:41 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:41 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:41 --> Upload Class Initialized
INFO - 27.06.2025 06:41:41 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:41 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:41 --> Controller Class Initialized
INFO - 27.06.2025 06:41:41 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:41 --> Model "Admin_model" initialized
DEBUG - 27.06.2025 06:41:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:42 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/dashboard.php
INFO - 27.06.2025 06:41:42 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 27.06.2025 06:41:42 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:42 --> Total execution time: 1.2872
INFO - 27.06.2025 06:41:44 --> Config Class Initialized
INFO - 27.06.2025 06:41:44 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:44 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:44 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:44 --> URI Class Initialized
INFO - 27.06.2025 06:41:44 --> Router Class Initialized
INFO - 27.06.2025 06:41:44 --> Output Class Initialized
INFO - 27.06.2025 06:41:44 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:44 --> Input Class Initialized
INFO - 27.06.2025 06:41:44 --> Language Class Initialized
INFO - 27.06.2025 06:41:44 --> Loader Class Initialized
INFO - 27.06.2025 06:41:44 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:44 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:44 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:44 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:44 --> Language file loaded: language/german/app_lang.php
INFO - 27.06.2025 06:41:44 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:44 --> Database Driver Class Initialized
DEBUG - 27.06.2025 06:41:44 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:44 --> Email Class Initialized
INFO - 27.06.2025 06:41:44 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:44 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:44 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:44 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:44 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:44 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:44 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:44 --> Upload Class Initialized
INFO - 27.06.2025 06:41:44 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:44 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:44 --> Controller Class Initialized
INFO - 27.06.2025 06:41:44 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:44 --> Model "Admin_model" initialized
DEBUG - 27.06.2025 06:41:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:44 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/documentation.php
INFO - 27.06.2025 06:41:44 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\admin/layout/normal.php
INFO - 27.06.2025 06:41:44 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:44 --> Total execution time: 0.3094
INFO - 27.06.2025 06:41:44 --> Config Class Initialized
INFO - 27.06.2025 06:41:44 --> Hooks Class Initialized
DEBUG - 27.06.2025 06:41:44 --> UTF-8 Support Enabled
INFO - 27.06.2025 06:41:44 --> Utf8 Class Initialized
INFO - 27.06.2025 06:41:44 --> URI Class Initialized
INFO - 27.06.2025 06:41:44 --> Router Class Initialized
INFO - 27.06.2025 06:41:44 --> Output Class Initialized
INFO - 27.06.2025 06:41:44 --> Security Class Initialized
DEBUG - 27.06.2025 06:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 27.06.2025 06:41:44 --> Input Class Initialized
INFO - 27.06.2025 06:41:44 --> Language Class Initialized
INFO - 27.06.2025 06:41:44 --> Loader Class Initialized
INFO - 27.06.2025 06:41:44 --> Helper loaded: app_helper
INFO - 27.06.2025 06:41:44 --> Helper loaded: language_helper
INFO - 27.06.2025 06:41:44 --> Helper loaded: text_helper
INFO - 27.06.2025 06:41:44 --> Helper loaded: string_helper
INFO - 27.06.2025 06:41:44 --> Language file loaded: language/german/app_lang.php
INFO - 27.06.2025 06:41:44 --> Session: Class initialized using 'files' driver.
INFO - 27.06.2025 06:41:44 --> Database Driver Class Initialized
DEBUG - 27.06.2025 06:41:44 --> Config file loaded: C:\Users\assist15\Desktop\project\STYX_web\application\config/ion_auth.php
INFO - 27.06.2025 06:41:44 --> Email Class Initialized
INFO - 27.06.2025 06:41:44 --> Language file loaded: language/german/ion_auth_lang.php
INFO - 27.06.2025 06:41:44 --> Helper loaded: cookie_helper
INFO - 27.06.2025 06:41:44 --> Helper loaded: url_helper
DEBUG - 27.06.2025 06:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:44 --> Helper loaded: date_helper
INFO - 27.06.2025 06:41:44 --> Model "Ion_auth_model" initialized
DEBUG - 27.06.2025 06:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 27.06.2025 06:41:44 --> Helper loaded: form_helper
INFO - 27.06.2025 06:41:44 --> Form Validation Class Initialized
INFO - 27.06.2025 06:41:44 --> Upload Class Initialized
INFO - 27.06.2025 06:41:44 --> Language file loaded: language/german/pagination_lang.php
INFO - 27.06.2025 06:41:44 --> Pagination Class Initialized
INFO - 27.06.2025 06:41:44 --> Controller Class Initialized
INFO - 27.06.2025 06:41:44 --> Model "App_model" initialized
INFO - 27.06.2025 06:41:44 --> Model "Mail_model" initialized
ERROR - 27.06.2025 06:41:44 --> 404 Page Not Found: http://localhost/STYX_web/adm/dist/js/pages/documentation.js
ERROR - 27.06.2025 06:41:44 --> Could not find the language line "ERROR_404_TITLE"
ERROR - 27.06.2025 06:41:44 --> Could not find the language line "ERROR_404_DESCRIPTION"
INFO - 27.06.2025 06:41:44 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\error404.php
ERROR - 27.06.2025 06:41:44 --> Could not find the language line "ABOUT_US"
INFO - 27.06.2025 06:41:45 --> File loaded: C:\Users\assist15\Desktop\project\STYX_web\application\views\layout/normal.php
INFO - 27.06.2025 06:41:45 --> Final output sent to browser
DEBUG - 27.06.2025 06:41:45 --> Total execution time: 0.4314
