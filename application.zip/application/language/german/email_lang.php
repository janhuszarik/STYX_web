<?php
$lang['email_smtp_error'] = "SMTP Error: %s";
$lang['email_send_failure_smtp'] = "Failed to send email using SMTP: %s";
?>
