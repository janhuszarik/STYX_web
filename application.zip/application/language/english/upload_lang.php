<?php
$lang['upload_no_filepath'] = 'Der Upload-Pfad scheint nicht gültig zu sein.';
