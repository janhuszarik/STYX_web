<?php
$lang['pagination_first_link'] = 'Erste';
$lang['pagination_next_link'] = 'Nächste';
$lang['pagination_prev_link'] = 'Vorherige';
$lang['pagination_last_link'] = 'Letzte';
